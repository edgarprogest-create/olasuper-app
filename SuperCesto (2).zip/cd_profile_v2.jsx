// cd_profile_v2.jsx — ProfileScreen
function ProfileScreen({ plan, onWallet, onJoin, onManage }) {
  const T = CESTO_STRINGS.pt;
  const W = CESTO_WALLET;
  const totalSaved = W.periods.ano.saved;
  const monthSaved = W.periods.mes.saved;
  const fee = cestoFee();
  const recent = W.history.slice(0, 4);

  return (
    <div className="screen screen-enter" style={{ paddingLeft: 0, paddingRight: 0 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '0 24px', marginBottom: 6 }}>
        <h2 className="h2" style={{ flex: 1 }}>{T.profile_title}</h2>
        <button className="iconbtn" style={{ fontSize: 16 }} aria-label="definições">⚙</button>
      </div>

      <div className="screen__scroll" style={{ padding: '0 24px' }}>
        {/* profile head */}
        <div className="pf-head">
          <div className="pf-avatar">SA</div>
          <div style={{ minWidth: 0 }}>
            <div className="pf-name">{T.profile_name}</div>
            <div className="pf-email">{T.profile_email}</div>
            <div className={'pf-since' + (plan === 'member' ? ' pf-since--m' : '')}>
              {plan === 'member' ? '★ ' + T.profile_member_since : T.profile_free_since}
            </div>
          </div>
        </div>

        {/* plan */}
        <div className="pf-label">{T.profile_sec_plan}</div>
        <div className="pf-row pf-row--tap" onClick={plan === 'member' ? onManage : onJoin}>
          <div className={'pf-icon' + (plan === 'member' ? ' pf-icon--m' : '')}>
            {plan === 'member' ? '★' : '○'}
          </div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div className="pf-row__title">
              {plan === 'member' ? T.profile_plan_member : T.profile_plan_free}
            </div>
            <div className="pf-row__sub">
              {plan === 'member' ? T.profile_plan_fee_member(eur(fee)) : T.profile_plan_fee_free}
            </div>
          </div>
          <span className={'pf-action' + (plan !== 'member' ? ' pf-action--cta' : '')}>
            {plan === 'member' ? T.profile_manage : T.profile_join}
          </span>
        </div>

        {/* wallet card */}
        <div className="pf-label">{T.profile_sec_wallet}</div>
        <div className="pf-wallet" onClick={onWallet}>
          <div className="pf-wallet__glow" />
          <div style={{ position: 'relative' }}>
            <div className="pf-wallet__label">{T.profile_saved_total}</div>
            <div className="pf-wallet__num mono">{eur(totalSaved)}</div>
            <div className="pf-wallet__foot">
              <span>+{eur(monthSaved)} {T.profile_this_month}</span>
              <span className="pf-wallet__link">{T.wallet_title} ›</span>
            </div>
          </div>
        </div>

        {/* history */}
        <div className="pf-label pf-label--row">
          <span>{T.profile_sec_history}</span>
          <button className="pf-seeall" onClick={onWallet}>{T.profile_see_all}</button>
        </div>
        <div className="pf-list">
          {recent.map((h, i) => (
            <div key={i} className="pf-hist">
              <StoreTile store={h.store} size={36} />
              <div style={{ flex: 1, minWidth: 0 }}>
                <div className="pf-row__title" style={{ fontSize: 14.5 }}>{CESTO_STORES[h.store].name}</div>
                <div className="pf-row__sub">{h.date_pt}</div>
              </div>
              <span className="pf-saved mono">+{eur(h.saved)}</span>
            </div>
          ))}
        </div>

        {/* footer */}
        <div className="pf-foot">
          <button className="pf-foot__btn">{T.profile_settings}</button>
          <button className="pf-foot__btn pf-foot__btn--out">{T.profile_signout}</button>
        </div>
        <div style={{ height: 14 }} />
      </div>
    </div>
  );
}

Object.assign(window, { ProfileScreen });
