// CestoDoce_screens_v2.jsx — Home (stock market), Cart, Analyzing, Analysis, Paywall, Profile
(function() {
const { useState, useEffect, useMemo, useRef, useCallback } = React;
const D = window.CestoDoceData;

// ---- Generate sparkline history for each supermarket ----
// Simulate 7-day price index (relative to the average basket)
function buildSparklines() {
  const stores = D.SUPERMARKETS;
  const prods = D.PRODUCTS;
  // base: real prices today (day 7)
  const baseAvg = {};
  stores.forEach(sm => {
    baseAvg[sm.id] = prods.reduce((s, p) => s + (p.prices[sm.id] || 0), 0) / prods.length;
  });
  // generate 8 synthetic days with ±3% noise per store, day 8 = real
  const SEED = [0.98, 1.02, 0.99, 1.01, 0.97, 1.03, 1.00, 1.00];
  const noise = {
    continente:  [1.01, 1.02, 1.00, 1.01, 1.02, 1.01, 1.00, 1.00],
    pingodoce:   [1.04, 0.99, 0.97, 0.94, 0.93, 0.95, 0.94, 0.94],
    lidl:        [0.92, 0.91, 0.93, 0.90, 0.91, 0.89, 0.90, 0.90],
    aldi:        [0.91, 0.92, 0.90, 0.89, 0.90, 0.88, 0.89, 0.89],
    mercadona:   [0.97, 0.98, 0.96, 0.97, 0.97, 0.96, 0.96, 0.96],
    intermarche: [0.99, 1.00, 1.01, 1.00, 1.01, 1.00, 1.00, 1.00],
  };
  // "savings score" = how much cheaper vs most expensive, expressed as €/product
  return stores.map(sm => {
    const hist = (noise[sm.id] || SEED).map(f => baseAvg[sm.id] * f);
    const maxHist = hist.map((v, i) => {
      const maxAtI = Math.max(...stores.map(s => baseAvg[s.id] * (noise[s.id]||SEED)[i]));
      return maxAtI - v; // savings vs worst
    });
    const today = maxHist[maxHist.length - 1];
    const prev  = maxHist[maxHist.length - 2];
    const delta = today - prev;
    return { id: sm.id, name: sm.name, values: maxHist, today, delta };
  }).sort((a, b) => b.today - a.today);
}

// ---- Category winners ----
function buildCatWinners() {
  return D.CATEGORIES.map(cat => {
    const prods = D.PRODUCTS.filter(p => p.category === cat.id);
    if (!prods.length) return null;
    const totals = D.SUPERMARKETS.map(sm => ({
      sm, total: prods.reduce((s, p) => s + (p.prices[sm.id] || 0), 0)
    })).sort((a, b) => a.total - b.total);
    const winner = totals[0];
    const loser  = totals[totals.length - 1];
    const saving = loser.total - winner.total;
    const promoCount = prods.filter(p => p.promo && p.promo[winner.sm.id]).length;
    return { category: cat, winner: winner.sm, loser: loser.sm, saving, promoCount };
  }).filter(Boolean);
}

const SPARK_DATA = buildSparklines();
const CAT_WINNERS = buildCatWinners();

// ---- FREE plan: first 100 products only (simulated as first 20 of our 30) ----
const FREE_PRODUCT_LIMIT = 20;
const FREE_PRODUCTS = D.PRODUCTS.slice(0, FREE_PRODUCT_LIMIT);

// ---- Savings simulator ----
const MEDIAN_SAVE_PCT = 0.14; // 14% avg saving on split
const PREMIUM_UPLIFT  = 1.42; // full catalogue = 42% more savings unlocked

// ============ HOME SCREEN ============
function HomeScreenV2({ theme, onNewCart, cartCount, plan, totalMonthlySaved }) {
  const [simBudget, setSimBudget] = useState(120);
  const [simExpanded, setSimExpanded] = useState(false);

  const freeSaving    = Math.round(simBudget * MEDIAN_SAVE_PCT * 100) / 100;
  const premiumSaving = Math.round(simBudget * MEDIAN_SAVE_PCT * PREMIUM_UPLIFT * 100) / 100;
  const uplift        = Math.round((premiumSaving - freeSaving) * 100) / 100;
  const sliderPct     = ((simBudget - 20) / (500 - 20)) * 100;

  const topStore  = SPARK_DATA[0];
  const weekLabel = '5–11 jun';

  const stockColor = (delta) => delta > 0.005
    ? 'oklch(46% 0.17 150)'
    : delta < -0.005
      ? 'oklch(52% 0.18 25)'
      : CD.ink3;

  return (
    <div data-screen-label="Início — stock market" style={{ paddingTop: 54 }}>
      {/* ---- Header ---- */}
      <div style={{ padding: '10px 20px 0', display: 'flex', alignItems: 'center', gap: 10 }}>
        <div style={{ flex: 1 }}>
          <p style={{ margin: 0, fontSize: 12, fontWeight: 700, color: CD.ink3, textTransform: 'uppercase', letterSpacing: '0.08em' }}>{weekLabel}</p>
          <h1 style={{ margin: '2px 0 0', fontSize: 24, fontWeight: 800, color: CD.ink, letterSpacing: '-0.025em', lineHeight: 1.1 }}>Mercado de<br/>Poupança</h1>
        </div>
        <div style={{ textAlign: 'right' }}>
          <p style={{ margin: 0, fontSize: 11.5, color: CD.ink3 }}>Poupado este mês</p>
          <p style={{ margin: 0, fontSize: 19, fontWeight: 800, color: theme.savings, letterSpacing: '-0.02em', fontVariantNumeric: 'tabular-nums' }}>{euro(totalMonthlySaved)}</p>
        </div>
      </div>

      <div style={{ overflowY: 'auto', overflowX: 'hidden', height: 'calc(100% - 54px)', paddingBottom: 130 }}>
        {/* ---- Stock list: poupança por loja ---- */}
        <section style={{ padding: '16px 20px 0' }}>
          <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 10 }}>
            <h2 style={{ margin: 0, fontSize: 14, fontWeight: 800, color: CD.ink, letterSpacing: '-0.01em' }}>Performance de Poupança</h2>
            <span style={{ fontSize: 11.5, color: CD.ink3, fontWeight: 600 }}>€/produto vs pior loja</span>
          </div>
          <Card style={{ padding: '4px 0', overflow: 'hidden' }}>
            {SPARK_DATA.map((sm, i) => {
              const col = stockColor(sm.delta);
              const isWin = i === 0;
              return (
                <div key={sm.id} style={{
                  display: 'flex', alignItems: 'center', gap: 12,
                  padding: '11px 16px',
                  borderBottom: i < SPARK_DATA.length - 1 ? `1px solid ${CD.lineSoft}` : 'none',
                  background: isWin ? `${theme.primarySoft}` : 'transparent',
                }}>
                  {/* rank */}
                  <span style={{ width: 20, fontSize: 12, fontWeight: 800,
                    color: isWin ? theme.savings : CD.ink3, textAlign: 'center', flexShrink: 0 }}>
                    {i + 1}
                  </span>
                  <SuperBadge id={sm.id} name={sm.name} size={34} />
                  {/* name + delta */}
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: 14.5, fontWeight: isWin ? 800 : 600, color: CD.ink,
                      display: 'flex', alignItems: 'center', gap: 6 }}>
                      {sm.name}
                      {isWin && <Pill bg={theme.primarySoft} color={theme.savings} style={{ fontSize: 10 }}>★ líder</Pill>}
                    </div>
                    <div style={{ fontSize: 12, color: col, fontWeight: 700, marginTop: 1,
                      display: 'flex', alignItems: 'center', gap: 3 }}>
                      {sm.delta > 0.005
                        ? <><TrendUpIcon size={12} color={col}/>+{euro(sm.delta)}</>
                        : sm.delta < -0.005
                          ? <><TrendDownIcon size={12} color={col}/>{euro(sm.delta)}</>
                          : <span style={{ color: CD.ink3 }}>→ estável</span>}
                    </div>
                  </div>
                  {/* sparkline */}
                  <Sparkline values={sm.values} color={col} width={68} height={32} />
                  {/* today value */}
                  <span style={{ fontSize: 14.5, fontWeight: 800, color: col,
                    fontVariantNumeric: 'tabular-nums', minWidth: 42, textAlign: 'right' }}>
                    {euro(sm.today)}
                  </span>
                </div>
              );
            })}
          </Card>
          <p style={{ margin: '7px 4px 0', fontSize: 11, color: CD.ink3, lineHeight: 1.5 }}>
            Poupança média por produto vs loja mais cara. 7 dias de histórico.
          </p>
        </section>

        {/* ---- Vencedores por categoria ---- */}
        <section style={{ padding: '22px 20px 0' }}>
          <h2 style={{ margin: '0 0 10px', fontSize: 14, fontWeight: 800, color: CD.ink, letterSpacing: '-0.01em' }}>
            Quem ganha por categoria
          </h2>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
            {CAT_WINNERS.map(({ category, winner, saving, promoCount }) => (
              <Card key={category.id} style={{ padding: '12px 14px', boxShadow: 'none', border: `1.5px solid ${CD.lineSoft}` }}>
                <p style={{ margin: '0 0 8px', fontSize: 11.5, fontWeight: 700, color: CD.ink3,
                  textTransform: 'uppercase', letterSpacing: '0.06em' }}>{category.name}</p>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <SuperBadge id={winner.id} name={winner.name} size={30} />
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: 13, fontWeight: 800, color: CD.ink, whiteSpace: 'nowrap',
                      overflow: 'hidden', textOverflow: 'ellipsis' }}>{winner.name}</div>
                    <div style={{ fontSize: 11.5, color: theme.savings, fontWeight: 700 }}>−{euro(saving)}</div>
                  </div>
                </div>
                {promoCount > 0 && (
                  <Pill bg={`oklch(96.5% 0.03 70)`} color={`oklch(56% 0.16 45)`}
                    style={{ marginTop: 7, fontSize: 10.5 }}>
                    <TagIcon size={10} color={`oklch(56% 0.16 45)`}/> {promoCount} promo{promoCount > 1 ? 's' : ''}
                  </Pill>
                )}
              </Card>
            ))}
          </div>
        </section>

        {/* ---- Simulador de poupança ---- */}
        <section style={{ padding: '22px 20px 0' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10, cursor: 'pointer' }}
            onClick={() => setSimExpanded(v => !v)}>
            <h2 style={{ margin: 0, fontSize: 14, fontWeight: 800, color: CD.ink, letterSpacing: '-0.01em' }}>
              Simulador de Poupança
            </h2>
            <span style={{ fontSize: 13, fontWeight: 700, color: theme.primary }}>{simExpanded ? '▲ fechar' : '▼ simular'}</span>
          </div>

          {simExpanded && (
            <Card style={{ padding: '18px 18px 20px' }}>
              {/* slider */}
              <p style={{ margin: '0 0 5px', fontSize: 13, fontWeight: 600, color: CD.ink2 }}>
                Gasto mensal estimado em supermercado
              </p>
              <div style={{ display: 'flex', alignItems: 'baseline', gap: 6, marginBottom: 10 }}>
                <span style={{ fontSize: 30, fontWeight: 800, color: CD.ink, letterSpacing: '-0.03em', fontVariantNumeric: 'tabular-nums' }}>{simBudget}</span>
                <span style={{ fontSize: 15, fontWeight: 700, color: CD.ink2 }}>€/mês</span>
              </div>
              <div style={{ position: 'relative', marginBottom: 18 }}>
                <input type="range" min="20" max="500" step="5" value={simBudget}
                  onChange={e => setSimBudget(Number(e.target.value))}
                  style={{
                    width: '100%', height: 5, borderRadius: 100, border: 'none', outline: 'none', cursor: 'pointer', appearance: 'none', WebkitAppearance: 'none',
                    background: `linear-gradient(90deg, ${theme.primary} ${sliderPct}%, ${CD.lineSoft} ${sliderPct}%)`,
                  }}
                />
              </div>

              {/* free vs premium */}
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
                {/* free */}
                <div style={{ background: CD.lineSoft, borderRadius: 12, padding: '12px 14px' }}>
                  <p style={{ margin: '0 0 4px', fontSize: 11, fontWeight: 700, color: CD.ink3, textTransform: 'uppercase', letterSpacing: '0.07em' }}>Plano Grátis</p>
                  <p style={{ margin: '0 0 2px', fontSize: 22, fontWeight: 800, color: CD.ink, letterSpacing: '-0.03em', fontVariantNumeric: 'tabular-nums' }}>{euro(freeSaving)}</p>
                  <p style={{ margin: 0, fontSize: 11.5, color: CD.ink3, lineHeight: 1.4 }}>com {FREE_PRODUCT_LIMIT} produtos/loja analisados</p>
                </div>
                {/* premium */}
                <div style={{ background: theme.primarySoft, borderRadius: 12, padding: '12px 14px', border: `1.5px solid ${theme.primary}20` }}>
                  <p style={{ margin: '0 0 4px', fontSize: 11, fontWeight: 700, color: theme.savings, textTransform: 'uppercase', letterSpacing: '0.07em' }}>★ Member</p>
                  <p style={{ margin: '0 0 2px', fontSize: 22, fontWeight: 800, color: theme.savings, letterSpacing: '-0.03em', fontVariantNumeric: 'tabular-nums' }}>{euro(premiumSaving)}</p>
                  <p style={{ margin: 0, fontSize: 11.5, color: theme.savings, lineHeight: 1.4, opacity: 0.8 }}>catálogo completo analisado</p>
                </div>
              </div>

              {/* uplift */}
              <div style={{ marginTop: 10, padding: '10px 12px', background: `${theme.primary}10`, borderRadius: 10, display: 'flex', alignItems: 'center', gap: 10 }}>
                <SparkIcon size={20} color={theme.savings} />
                <p style={{ margin: 0, fontSize: 13, color: CD.ink2, lineHeight: 1.4, flex: 1 }}>
                  O Member desbloqueia <strong style={{ color: theme.savings }}>+{euro(uplift)}/mês</strong> de poupança extra — paga-se em {Math.ceil(1 / uplift)} compras.
                </p>
              </div>
            </Card>
          )}

          {!simExpanded && (
            <Card style={{ padding: '14px 16px', boxShadow: 'none', border: `1.5px solid ${CD.lineSoft}`, display: 'flex', alignItems: 'center', gap: 14, cursor: 'pointer' }}
              onClick={() => setSimExpanded(true)}>
              <SparkIcon size={26} color={theme.primary} />
              <div>
                <p style={{ margin: 0, fontSize: 14, fontWeight: 700, color: CD.ink }}>Quanto poupas com a tua lista?</p>
                <p style={{ margin: '2px 0 0', fontSize: 12.5, color: CD.ink2 }}>Simula o teu ganho mensal →</p>
              </div>
            </Card>
          )}
        </section>

        {/* ---- CTA ---- */}
        <section style={{ padding: '20px 20px 0' }}>
          <PrimaryButton theme={theme} onClick={onNewCart}>
            <BasketIcon size={18} color="#fff" />
            {cartCount > 0 ? `Continuar carrinho (${cartCount})` : 'Criar carrinho de compras'}
          </PrimaryButton>
          {plan !== 'member' && (
            <p style={{ textAlign: 'center', fontSize: 12, color: CD.ink3, margin: '8px 0 0', lineHeight: 1.5 }}>
              Plano grátis: 1 análise/mês com {FREE_PRODUCT_LIMIT} produtos por loja
            </p>
          )}
        </section>
      </div>
    </div>
  );
}

// ============ CART SCREEN ============
function CartScreenV2({ theme, cart, onChangeQty, onAdd, onAnalyse, plan, usageLeft }) {
  const [query, setQuery] = useState('');
  const planProds = plan === 'member' ? D.PRODUCTS : FREE_PRODUCTS;
  const results = useMemo(() => {
    if (!query.trim()) return [];
    const q = query.trim().toLowerCase();
    return planProds.filter(p => p.name.toLowerCase().includes(q)).slice(0, 6);
  }, [query, planProds]);

  const cartProducts = cart.map(it => ({ ...it, product: D.PRODUCTS.find(p => p.id === it.productId) })).filter(x => x.product);
  const bestTotal = useMemo(() => {
    if (!cart.length) return 0;
    const r = D.compareCart(cart);
    return r ? r.splitTotal : 0;
  }, [cart]);
  const inCart = id => cart.find(i => i.productId === id);

  const lockedCount = D.PRODUCTS.length - FREE_PRODUCTS.length;

  return (
    <div data-screen-label="Carrinho — criação e pesquisa" style={{ paddingTop: 54 }}>
      <ScreenHeader title="O teu carrinho"
        subtitle={cart.length ? `${cartProducts.reduce((s,i)=>s+i.qty,0)} artigos · melhor total ${euro(bestTotal)}` : 'Adiciona produtos para comparar preços'} />

      {plan !== 'member' && (
        <div style={{ margin: '4px 20px 0', padding: '9px 12px', background: `oklch(96% 0.025 300)`, borderRadius: 10, fontSize: 12.5, color: `oklch(42% 0.12 300)`, fontWeight: 600, display: 'flex', alignItems: 'center', gap: 8 }}>
          <CrownIcon size={15} color={`oklch(42% 0.12 300)`}/>
          <span>Plano Grátis: {FREE_PRODUCT_LIMIT}/{D.PRODUCTS.length} produtos disponíveis. <strong>{lockedCount} bloqueados</strong> no Member.</span>
        </div>
      )}

      {/* pesquisa */}
      <div style={{ padding: '10px 20px 0', position: 'relative', zIndex: 30 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, background: CD.surface,
          border: `1.5px solid ${query ? theme.primary : CD.line}`, borderRadius: 14, padding: '0 14px' }}>
          <SearchIcon size={18} color={CD.ink3}/>
          <input value={query} onChange={e => setQuery(e.target.value)}
            placeholder={plan === 'member' ? 'Pesquisar produto… (catálogo completo)' : `Pesquisar produto… (${FREE_PRODUCT_LIMIT} disponíveis)`}
            style={{ flex:1, border:'none', outline:'none', background:'transparent', fontSize:15, fontFamily:'inherit', color:CD.ink, height:48 }}/>
          {query && <button onClick={()=>setQuery('')} style={{ border:'none', background:'none', cursor:'pointer', color:CD.ink3, fontSize:13, fontWeight:600, fontFamily:'inherit' }}>Limpar</button>}
        </div>

        {results.length > 0 && (
          <div style={{ position:'absolute', left:20, right:20, top:58, background:CD.surface, borderRadius:14, boxShadow:CD.shadowLift, overflow:'hidden', border:`1px solid ${CD.lineSoft}` }}>
            {results.map(p => {
              const cheapest = D.SUPERMARKETS.reduce((b,s) => p.prices[s.id] < p.prices[b.id] ? s : b);
              const added = inCart(p.id);
              return (
                <button key={p.id} onClick={() => { onAdd(p.id); setQuery(''); }}
                  style={{ display:'flex', alignItems:'center', gap:12, width:'100%', padding:'11px 14px', border:'none', background:'none', cursor:'pointer', borderBottom:`1px solid ${CD.lineSoft}`, fontFamily:'inherit', textAlign:'left' }}>
                  <div style={{ flex:1, minWidth:0 }}>
                    <div style={{ fontSize:14.5, fontWeight:600, color:CD.ink }}>{p.name}</div>
                    <div style={{ fontSize:12, color:CD.ink2, marginTop:1 }}>desde {euro(p.prices[cheapest.id])} · {cheapest.name}
                      {p.promo && p.promo[cheapest.id] && <span style={{ color:`oklch(56% 0.16 45)`, fontWeight:700 }}> · promo</span>}
                    </div>
                  </div>
                  <span style={{ width:30, height:30, borderRadius:100, flexShrink:0, background:added?theme.primarySoft:theme.primary, display:'flex', alignItems:'center', justifyContent:'center' }}>
                    {added ? <CheckIcon size={15} color={theme.primary}/> : <PlusIcon size={15} color="#fff"/>}
                  </span>
                </button>
              );
            })}
          </div>
        )}
      </div>

      {/* lista */}
      <div style={{ overflowY:'auto', padding:'14px 20px 130px', height:'calc(100% - 160px)' }}>
        {cartProducts.length === 0 ? (
          <div style={{ textAlign:'center', padding:'40px 24px', color:CD.ink3 }}>
            <BasketIcon size={42} color={CD.line}/>
            <p style={{ fontSize:14.5, lineHeight:1.5, margin:'14px 0 0' }}>Carrinho vazio.<br/>Pesquisa produtos acima.</p>
          </div>
        ) : (
          <Card style={{ padding:'4px 16px' }}>
            {cartProducts.map((it, idx) => {
              const cheapest = D.SUPERMARKETS.reduce((b,s) => it.product.prices[s.id] < it.product.prices[b.id] ? s : b);
              const isPromo = it.product.promo && it.product.promo[cheapest.id];
              return (
                <div key={it.productId} style={{ display:'flex', alignItems:'center', gap:12, padding:'12px 0', borderBottom: idx < cartProducts.length-1 ? `1px solid ${CD.lineSoft}` : 'none' }}>
                  <div style={{ flex:1, minWidth:0 }}>
                    <div style={{ fontSize:14.5, fontWeight:600, color:CD.ink, display:'flex', alignItems:'center', gap:6, flexWrap:'wrap' }}>
                      {it.product.name}
                      {isPromo && <Pill bg="oklch(96.5% 0.03 70)" color="oklch(56% 0.16 45)">promo</Pill>}
                    </div>
                    <div style={{ fontSize:12.5, color:CD.ink2, marginTop:2 }}>melhor: {euro(it.product.prices[cheapest.id])} · {cheapest.name}</div>
                  </div>
                  <QtyStepper qty={it.qty} theme={theme} onChange={d => onChangeQty(it.productId, d)}/>
                </div>
              );
            })}
          </Card>
        )}
      </div>

      {/* CTA fixo */}
      {cartProducts.length > 0 && (
        <div style={{ position:'absolute', left:0, right:0, bottom:62, padding:'12px 20px 14px', background:`linear-gradient(to top, ${CD.bg} 65%, transparent)`, zIndex:50 }}>
          <PrimaryButton theme={theme} onClick={onAnalyse}>
            <SparkIcon size={18} color="#fff"/> Analisar carrinho
          </PrimaryButton>
          <p style={{ textAlign:'center', fontSize:12, color:CD.ink3, margin:'7px 0 0' }}>
            {plan === 'member' ? 'Análises ilimitadas · Member' : usageLeft > 0 ? `${usageLeft} análise gratuita disponível este mês` : 'Limite atingido · upgrade para continuar'}
          </p>
        </div>
      )}
    </div>
  );
}

// ============ ANALYZING SCREEN ============
function AnalyzingScreenV2({ theme, plan }) {
  const [step, setStep] = useState(0);
  const storeList = D.SUPERMARKETS.slice(0, 6);
  useEffect(() => {
    const timers = storeList.map((_, i) => setTimeout(() => setStep(i + 1), 350 + i * 300));
    return () => timers.forEach(clearTimeout);
  }, []);
  const totalToCheck = plan === 'member' ? D.PRODUCTS.length : FREE_PRODUCT_LIMIT;
  return (
    <div data-screen-label="Analisando" style={{ display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', height:'100%', padding:'20px 32px 80px' }}>
      <div style={{ marginBottom:28, position:'relative', width:80, height:80 }}>
        <svg viewBox="0 0 80 80" width="80" height="80" style={{ animation:'cdSpinSlow 3s linear infinite', position:'absolute', inset:0 }}>
          <circle cx="40" cy="40" r="36" fill="none" stroke={CD.lineSoft} strokeWidth="5"/>
          <circle cx="40" cy="40" r="36" fill="none" stroke={theme.primary} strokeWidth="5" strokeDasharray="226" strokeDashoffset={226*(1-step/storeList.length)} strokeLinecap="round" style={{ transition:'stroke-dashoffset 0.4s ease', transform:'rotate(-90deg)', transformOrigin:'center' }}/>
        </svg>
        <div style={{ position:'absolute', inset:0, display:'flex', alignItems:'center', justifyContent:'center', fontSize:22 }}>🔍</div>
      </div>
      <h2 style={{ fontSize:20, fontWeight:800, color:CD.ink, letterSpacing:'-0.02em', textAlign:'center', margin:'0 0 6px' }}>A comparar preços…</h2>
      <p style={{ fontSize:13, color:CD.ink2, margin:'0 0 24px', textAlign:'center' }}>{totalToCheck} produtos · {storeList.length} supermercados</p>
      <div style={{ width:'100%', display:'flex', flexDirection:'column', gap:8 }}>
        {storeList.map((sm, i) => (
          <div key={sm.id} style={{ display:'flex', alignItems:'center', gap:12, padding:'9px 14px', borderRadius:12, background: i < step ? theme.primarySoft : CD.surface, transition:'background 0.3s ease' }}>
            <SuperBadge id={sm.id} name={sm.name} size={30}/>
            <span style={{ flex:1, fontSize:14, fontWeight: i < step ? 700 : 500, color: i < step ? CD.ink : CD.ink2 }}>{sm.name}</span>
            <span style={{ fontSize:14 }}>{i < step ? '✓' : i === step ? <span style={{ display:'inline-block', width:14, height:14, borderRadius:'50%', border:`2px solid ${CD.line}`, borderTopColor:theme.primary, animation:'cdSpin 0.6s linear infinite' }}/> : ''}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ============ ANALYSIS SCREEN ============
function AnalysisScreenV2({ theme, result, plan, onBack, onGoCart, onUpgrade }) {
  const [runAnim, setRunAnim] = useState(false);
  useEffect(() => { const id = setTimeout(() => setRunAnim(true), 100); return () => clearTimeout(id); }, []);

  if (!result) {
    return (
      <div data-screen-label="Análise — vazio" style={{ paddingTop:54 }}>
        <ScreenHeader title="Análise"/>
        <div style={{ textAlign:'center', padding:'64px 32px', color:CD.ink3 }}>
          <CompassIcon size={44} color={CD.line}/>
          <p style={{ fontSize:14.5, lineHeight:1.55, margin:'14px 0 18px' }}>Ainda não fizeste nenhuma análise.<br/>Cria um carrinho primeiro.</p>
          <GhostButton onClick={onGoCart} style={{ maxWidth:240, margin:'0 auto' }}>Ir para o carrinho</GhostButton>
        </div>
      </div>
    );
  }
  const r = result;
  const split = r.shouldSplit;
  const [animVal, setAnimVal] = useState(0);
  useEffect(() => {
    if (!runAnim) return;
    let raf, start;
    const target = split ? r.savings : 0;
    const tick = t => {
      if (!start) start = t;
      const p = Math.min(1,(t-start)/1100);
      setAnimVal(target*(1-Math.pow(1-p,3)));
      if (p < 1) raf = requestAnimationFrame(tick); else setAnimVal(target);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [runAnim, r.savings, split]);

  // free plan teaser
  const freeProducts = D.PRODUCTS.slice(0, FREE_PRODUCT_LIMIT).map(p => p.id);
  const freeCart = result._cart ? result._cart.filter(i => freeProducts.includes(i.productId)) : null;
  const freeResult = plan !== 'member' && freeCart ? D.compareCart(freeCart) : null;
  const premiumExtra = freeResult && r.savings > freeResult.savings ? r.savings - freeResult.savings : 0;

  return (
    <div data-screen-label="Análise — resultado" style={{ paddingTop:54 }}>
      <ScreenHeader title="Resultado da análise"
        subtitle={`${r.totalItems} artigos · ${D.SUPERMARKETS.length} lojas comparadas`}
        onBack={onBack}/>
      <div style={{ overflowY:'auto', padding:'6px 20px 130px', height:'calc(100% - 100px)' }}>
        {/* hero */}
        <Card style={{ textAlign:'center', padding:'24px 20px 20px', background:theme.primarySoft, boxShadow:'none', border:`1.5px solid ${CD.lineSoft}` }}>
          {split ? (
            <div>
              <Pill bg={theme.primary} color="#fff" style={{ marginBottom:14 }}>
                <SparkIcon size={13} color="#fff"/> Divisão recomendada
              </Pill>
              <div style={{ fontSize:13.5, fontWeight:600, color:CD.ink2 }}>Dividindo em {r.splitGroups.length} lojas, poupas</div>
              <div style={{ fontSize:54, fontWeight:800, color:theme.savings, letterSpacing:'-0.04em', lineHeight:1.1, margin:'4px 0 2px', fontVariantNumeric:'tabular-nums' }}>
                {animVal.toFixed(2).replace('.',',')} €
              </div>
              <div style={{ fontSize:13.5, color:CD.ink2 }}>−{String(r.savingsPct).replace('.',',')}% vs {r.bestSingle.name} ({euro(r.singleTotal)})</div>
            </div>
          ) : (
            <div>
              <Pill bg={theme.primary} color="#fff" style={{ marginBottom:14 }}>
                <CheckIcon size={13} color="#fff"/> Uma loja chega
              </Pill>
              <div style={{ fontSize:13.5, fontWeight:600, color:CD.ink2 }}>Compra tudo no</div>
              <div style={{ fontSize:34, fontWeight:800, color:CD.ink, letterSpacing:'-0.03em', margin:'4px 0 2px' }}>{r.bestSingle.name}</div>
              <div style={{ fontSize:14, color:CD.ink2 }}>Total: <strong>{euro(r.singleTotal)}</strong></div>
            </div>
          )}
        </Card>

        {/* premium upsell: member veria X mais */}
        {plan !== 'member' && premiumExtra > 0.5 && (
          <div onClick={onUpgrade} style={{ cursor:'pointer', marginTop:10, padding:'12px 16px', background:`oklch(96% 0.025 300)`, borderRadius:14, display:'flex', alignItems:'center', gap:12, border:`1.5px solid oklch(85% 0.05 300)` }}>
            <CrownIcon size={22} color={`oklch(42% 0.12 300)`}/>
            <div style={{ flex:1 }}>
              <div style={{ fontSize:13.5, fontWeight:800, color:`oklch(28% 0.1 300)` }}>Com Member, pouparias +{euro(premiumExtra)}</div>
              <div style={{ fontSize:12, color:`oklch(45% 0.1 300)`, marginTop:1 }}>Catálogo completo desbloqueado → mais oportunidades</div>
            </div>
            <span style={{ fontSize:13, fontWeight:800, color:`oklch(42% 0.12 300)` }}>↗</span>
          </div>
        )}

        {/* listas por loja */}
        <div style={{ display:'flex', flexDirection:'column', gap:10, marginTop:12 }}>
          {(split ? r.splitGroups : [{ supermarket:r.bestSingle, items:null, subtotal:r.singleTotal }]).map(group => (
            <Card key={group.supermarket.id} style={{ padding:0, overflow:'hidden' }}>
              <div style={{ display:'flex', alignItems:'center', gap:12, padding:'14px 16px', borderBottom:`1px solid ${CD.lineSoft}` }}>
                <SuperBadge id={group.supermarket.id} name={group.supermarket.name} size={36}/>
                <div style={{ flex:1 }}>
                  <div style={{ fontSize:15.5, fontWeight:800, color:CD.ink }}>{group.supermarket.name}</div>
                  {group.items && <div style={{ fontSize:12, color:CD.ink2 }}>{group.items.reduce((s,i)=>s+i.qty,0)} artigos</div>}
                </div>
                <div style={{ fontSize:17, fontWeight:800, color:CD.ink, fontVariantNumeric:'tabular-nums' }}>{euro(group.subtotal)}</div>
              </div>
              {group.items && (
                <div style={{ padding:'6px 16px 10px' }}>
                  {group.items.map(it => (
                    <div key={it.productId} style={{ display:'flex', alignItems:'center', gap:8, padding:'7px 0', fontSize:13.5 }}>
                      <span style={{ color:CD.ink, flex:1, display:'flex', gap:6, alignItems:'center', flexWrap:'wrap' }}>
                        {it.product.name}{it.qty>1?` ×${it.qty}`:''}
                        {it.isPromo && <Pill bg="oklch(96.5% 0.03 70)" color="oklch(56% 0.16 45)">promo</Pill>}
                      </span>
                      <span style={{ color:CD.ink2, fontWeight:600, fontVariantNumeric:'tabular-nums' }}>{euro(it.unitPrice*it.qty)}</span>
                    </div>
                  ))}
                </div>
              )}
            </Card>
          ))}
        </div>

        {/* ranking completo */}
        <Card style={{ padding:'14px 16px', boxShadow:'none', border:`1.5px solid ${CD.lineSoft}`, background:'transparent', marginTop:10 }}>
          <div style={{ fontSize:12.5, fontWeight:700, color:CD.ink3, textTransform:'uppercase', letterSpacing:'0.07em', marginBottom:10 }}>Ranking loja única</div>
          <div style={{ display:'flex', flexDirection:'column', gap:8 }}>
            {r.allTotals.map((t,i) => (
              <div key={t.supermarket.id} style={{ display:'flex', alignItems:'center', gap:10, fontSize:13.5 }}>
                <SuperBadge id={t.supermarket.id} name={t.supermarket.name} size={24}/>
                <span style={{ flex:1, color:i===0?CD.ink:CD.ink2, fontWeight:i===0?700:500 }}>{t.supermarket.name}</span>
                {i===0 && <Pill bg={`oklch(96% 0.045 90)`} color={`oklch(42% 0.1 75)`}>mais barato</Pill>}
                <span style={{ fontWeight:600, color:i===0?CD.ink:CD.ink2, fontVariantNumeric:'tabular-nums' }}>{euro(t.total)}</span>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}

// ============ PROFILE SCREEN ============
function ProfileScreenV2({ theme, plan, usageUsed, usageLimit, lastSavings, onUpgrade }) {
  const isMember = plan === 'member';
  return (
    <div data-screen-label="Perfil — conta e plano" style={{ paddingTop:54 }}>
      <ScreenHeader title="Perfil"/>
      <div style={{ overflowY:'auto', padding:'6px 20px 110px', height:'calc(100% - 100px)', display:'flex', flexDirection:'column', gap:12 }}>
        <Card style={{ display:'flex', alignItems:'center', gap:14 }}>
          <div style={{ width:52, height:52, borderRadius:'50%', background:theme.primarySoft, display:'flex', alignItems:'center', justifyContent:'center', fontSize:20, fontWeight:800, color:theme.primary }}>M</div>
          <div style={{ flex:1 }}>
            <div style={{ fontSize:16.5, fontWeight:800, color:CD.ink }}>Maria Santos</div>
            <div style={{ fontSize:13, color:CD.ink2 }}>maria.santos@email.pt</div>
          </div>
          {isMember
            ? <Pill bg={`oklch(96% 0.025 300)`} color={`oklch(42% 0.12 300)`}><CrownIcon size={12} color={`oklch(42% 0.12 300)`}/> Member</Pill>
            : <Pill bg={CD.lineSoft} color={CD.ink2}>Grátis</Pill>}
        </Card>

        <Card>
          <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:10 }}>
            <span style={{ fontSize:14.5, fontWeight:700, color:CD.ink }}>Análises este mês</span>
            <span style={{ fontSize:13.5, fontWeight:700, color:CD.ink2, fontVariantNumeric:'tabular-nums' }}>
              {isMember ? `${usageUsed} · ilimitadas` : `${usageUsed} / ${usageLimit}`}
            </span>
          </div>
          <div style={{ height:8, borderRadius:100, background:CD.lineSoft, overflow:'hidden' }}>
            <div style={{ height:'100%', borderRadius:100, background:theme.primary, width:isMember?'100%':`${Math.min(usageUsed/usageLimit,1)*100}%`, opacity:isMember?0.35:1, transition:'width 0.4s ease' }}/>
          </div>
          <p style={{ margin:'10px 0 0', fontSize:12.5, color:CD.ink3 }}>
            {isMember ? 'Análises ilimitadas + catálogo completo.' : `Catálogo: ${FREE_PRODUCT_LIMIT}/${D.PRODUCTS.length} produtos. Renova a 1 de julho.`}
          </p>
        </Card>

        {lastSavings != null && lastSavings > 0 && (
          <Card style={{ background:theme.primarySoft, boxShadow:'none', border:`1.5px solid ${CD.lineSoft}` }}>
            <div style={{ display:'flex', alignItems:'center', gap:12 }}>
              <WalletIcon size={26} color={theme.savings}/>
              <div>
                <div style={{ fontSize:14, color:CD.ink2 }}>Poupança na última análise</div>
                <div style={{ fontSize:22, fontWeight:800, color:theme.savings, letterSpacing:'-0.02em' }}>{euro(lastSavings)}</div>
              </div>
            </div>
          </Card>
        )}

        {!isMember && (
          <Card style={{ padding:18 }}>
            <Pill bg={`oklch(96% 0.025 300)`} color={`oklch(42% 0.12 300)`} style={{ marginBottom:12 }}>
              <CrownIcon size={12} color={`oklch(42% 0.12 300)`}/> CestoDoce Member
            </Pill>
            <h3 style={{ margin:'0 0 10px', fontSize:17, fontWeight:800, color:CD.ink, letterSpacing:'-0.015em' }}>Catálogo completo + análises ilimitadas</h3>
            <ul style={{ margin:'0 0 16px', padding:0, listStyle:'none', display:'flex', flexDirection:'column', gap:8 }}>
              {[`${D.PRODUCTS.length} produtos analisados (vs ${FREE_PRODUCT_LIMIT} no grátis)`, 'Análises ilimitadas todos os meses', 'Alertas de promoções da semana'].map(b => (
                <li key={b} style={{ display:'flex', alignItems:'center', gap:9, fontSize:14, color:CD.ink2 }}>
                  <CheckIcon size={15} color={theme.savings}/> {b}
                </li>
              ))}
            </ul>
            <PrimaryButton theme={theme} onClick={onUpgrade}>Tornar-me Member · 1 €/mês</PrimaryButton>
          </Card>
        )}
      </div>
    </div>
  );
}

// ============ PAYWALL SHEET ============
function PaywallSheetV2({ theme, lastSavings, onSubscribe, onClose, simBudget=120 }) {
  const [step, setStep] = useState('offer');
  const [method, setMethod] = useState(null);
  const freeSaving    = Math.round(simBudget * MEDIAN_SAVE_PCT * 100) / 100;
  const premiumSaving = Math.round(simBudget * MEDIAN_SAVE_PCT * PREMIUM_UPLIFT * 100) / 100;
  const uplift        = Math.round((premiumSaving - freeSaving) * 100) / 100;

  function pay(m) { setMethod(m); setStep('paying'); setTimeout(() => setStep('success'), 1400); }
  useEffect(() => { if (step === 'success') { const t = setTimeout(onSubscribe, 1200); return () => clearTimeout(t); } }, [step]);

  return (
    <div style={{ position:'absolute', inset:0, zIndex:200, background:'rgba(15,25,18,0.5)', display:'flex', alignItems:'flex-end', animation:'cdFadeIn 0.2s ease' }}
      onClick={step==='offer'?onClose:undefined}>
      <div onClick={e=>e.stopPropagation()} style={{ width:'100%', background:CD.surface, borderRadius:'24px 24px 0 0', padding:'12px 22px calc(max(env(safe-area-inset-bottom),10px) + 14px)', animation:'cdSlideUp 0.32s cubic-bezier(0.32,0.72,0,1)', maxHeight:'92%', overflowY:'auto' }}>
        <div style={{ width:40, height:4, borderRadius:100, background:CD.line, margin:'0 auto 18px' }}/>

        {step === 'offer' && (<>
          <Pill bg={`oklch(96% 0.025 300)`} color={`oklch(42% 0.12 300)`} style={{ marginBottom:12 }}>
            <CrownIcon size={12} color={`oklch(42% 0.12 300)`}/> CestoDoce Member
          </Pill>
          <h2 style={{ margin:'0 0 6px', fontSize:22, fontWeight:800, color:CD.ink, letterSpacing:'-0.025em', lineHeight:1.2 }}>
            Mais poupança, mais análises
          </h2>
          <p style={{ margin:'0 0 14px', fontSize:14, color:CD.ink2, lineHeight:1.5 }}>
            O catálogo completo desbloqueia oportunidades que o plano grátis não vê.
          </p>

          {/* mini simulador no paywall */}
          <div style={{ background:theme.primarySoft, borderRadius:14, padding:'14px 16px', marginBottom:16 }}>
            <p style={{ margin:'0 0 10px', fontSize:12, fontWeight:700, color:CD.ink3, textTransform:'uppercase', letterSpacing:'0.07em' }}>Impacto estimado com {simBudget}€/mês</p>
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:8 }}>
              <div>
                <div style={{ fontSize:11, color:CD.ink3, fontWeight:600 }}>Plano Grátis</div>
                <div style={{ fontSize:20, fontWeight:800, color:CD.ink, fontVariantNumeric:'tabular-nums' }}>{euro(freeSaving)}</div>
              </div>
              <div>
                <div style={{ fontSize:11, color:theme.savings, fontWeight:700 }}>★ Member</div>
                <div style={{ fontSize:20, fontWeight:800, color:theme.savings, fontVariantNumeric:'tabular-nums' }}>{euro(premiumSaving)}</div>
              </div>
            </div>
            <div style={{ marginTop:10, fontSize:13, color:CD.ink2, paddingTop:10, borderTop:`1px solid ${CD.lineSoft}` }}>
              <strong style={{ color:theme.savings }}>+{euro(uplift)}/mês</strong> com Member — a subscrição de 1€ paga-se em dias.
            </div>
          </div>

          <ul style={{ margin:'0 0 16px', padding:0, listStyle:'none', display:'flex', flexDirection:'column', gap:8 }}>
            {[`${D.PRODUCTS.length} produtos analisados (vs ${FREE_PRODUCT_LIMIT})`, 'Análises ilimitadas', 'Alertas de promoções semanais', 'Catálogo atualizado em tempo real'].map(b => (
              <li key={b} style={{ display:'flex', alignItems:'center', gap:9, fontSize:14, color:CD.ink2 }}>
                <CheckIcon size={15} color={theme.savings}/> {b}
              </li>
            ))}
          </ul>

          <div style={{ textAlign:'center', marginBottom:14 }}>
            <span style={{ fontSize:36, fontWeight:800, color:CD.ink, letterSpacing:'-0.03em' }}>1 €</span>
            <span style={{ fontSize:15, color:CD.ink2, fontWeight:600 }}> / mês</span>
          </div>

          <div style={{ display:'flex', flexDirection:'column', gap:9 }}>
            <button onClick={()=>pay('applepay')} style={{ minHeight:52, borderRadius:14, border:'none', background:'#000', color:'#fff', fontSize:16, fontWeight:700, fontFamily:'inherit', cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center', gap:7 }}>
              <svg width="17" height="20" viewBox="0 0 17 20" fill="#fff"><path d="M13.9 10.6c0-2.4 2-3.6 2.1-3.6-1.1-1.7-2.9-1.9-3.5-1.9-1.5-.2-2.9.9-3.7.9-.8 0-1.9-.9-3.2-.8C4 5.2 2.5 6.1 1.7 7.6c-1.7 3-.4 7.4 1.2 9.8.8 1.2 1.7 2.5 3 2.4 1.2 0 1.7-.8 3.1-.8 1.5 0 1.9.8 3.2.8 1.3 0 2.1-1.2 2.9-2.4.9-1.4 1.3-2.7 1.3-2.8 0 0-2.5-1-2.5-4zM11.5 3.4c.7-.8 1.1-1.9 1-3.1-1 0-2.2.7-2.9 1.5-.6.7-1.2 1.9-1 3 1.1.1 2.2-.6 2.9-1.4z"/></svg>
              Pay
            </button>
            <button onClick={()=>pay('googlepay')} style={{ minHeight:52, borderRadius:14, border:`1.5px solid ${CD.line}`, background:'#fff', color:CD.ink, fontSize:15.5, fontWeight:700, fontFamily:'inherit', cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center', gap:8 }}>
              <span style={{ display:'inline-flex', gap:1, fontWeight:800, fontSize:16 }}>
                <span style={{ color:'#4285F4' }}>G</span><span style={{ color:'#EA4335' }}>o</span><span style={{ color:'#FBBC04' }}>o</span><span style={{ color:'#4285F4' }}>g</span><span style={{ color:'#34A853' }}>l</span><span style={{ color:'#EA4335' }}>e</span>
              </span> Pay
            </button>
            <button onClick={()=>pay('card')} style={{ minHeight:48, borderRadius:14, border:'none', background:'transparent', color:CD.ink2, fontSize:14.5, fontWeight:600, fontFamily:'inherit', cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center', gap:7 }}>
              <WalletIcon size={17} color={CD.ink2}/> Pagar com cartão
            </button>
          </div>
          <p style={{ textAlign:'center', fontSize:11.5, color:CD.ink3, margin:'12px 0 0', lineHeight:1.5 }}>Pagamento dentro da app · Cancela quando quiseres</p>
        </>)}

        {step === 'paying' && (
          <div style={{ textAlign:'center', padding:'44px 0 52px' }}>
            <div style={{ width:52, height:52, margin:'0 auto 18px', borderRadius:'50%', border:`4px solid ${CD.lineSoft}`, borderTopColor:theme.primary, animation:'cdSpin 0.8s linear infinite' }}/>
            <div style={{ fontSize:16, fontWeight:700, color:CD.ink }}>A processar pagamento…</div>
            <div style={{ fontSize:13, color:CD.ink3, marginTop:6 }}>1,00 € · CestoDoce Member</div>
          </div>
        )}

        {step === 'success' && (
          <div style={{ textAlign:'center', padding:'44px 0 52px' }}>
            <div style={{ width:60, height:60, margin:'0 auto 16px', borderRadius:'50%', background:theme.primarySoft, display:'flex', alignItems:'center', justifyContent:'center', animation:'cdPop 0.4s cubic-bezier(0.34,1.56,0.64,1)' }}>
              <CheckIcon size={30} color={theme.savings}/>
            </div>
            <div style={{ fontSize:20, fontWeight:800, color:CD.ink, letterSpacing:'-0.02em' }}>Bem-vinda, Member!</div>
            <div style={{ fontSize:13.5, color:CD.ink2, marginTop:6 }}>Catálogo completo + análises ilimitadas ativados.</div>
          </div>
        )}
      </div>
    </div>
  );
}

Object.assign(window, {
  HomeScreenV2, CartScreenV2, AnalyzingScreenV2, AnalysisScreenV2,
  ProfileScreenV2, PaywallSheetV2, FREE_PRODUCT_LIMIT, FREE_PRODUCTS,
  MEDIAN_SAVE_PCT, PREMIUM_UPLIFT,
});
})();
