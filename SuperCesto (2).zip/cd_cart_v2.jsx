// cd_cart_v2.jsx — CartScreen, AnalyzingScreen, CompareScreen, ReceiptScreen, SplitScreen
const { useState, useEffect, useMemo, useRef } = React;

// ---- split calculator ----
function cestoSplitSimple(cart) {
  if (!cart || cart.length === 0) return { worth: false, split: null, base: 'lidl', baseTotal: 0 };
  const cmp = cestoCompare(cart);
  const base = cmp.cheapest.store;
  const baseTotal = cmp.cheapest.total;
  const THRESHOLD = 1.50;
  let best = null;
  CESTO_STORE_KEYS.filter(s => s !== base).forEach(s => {
    let total = 0;
    const baseItems = [], altItems = [];
    cart.forEach(line => {
      const p = CESTO_PRODUCT_BY_ID[line.id];
      if (!p) return;
      if (p.prices[s] < p.prices[base]) {
        const lp = p.prices[s] * line.qty;
        altItems.push({ id: line.id, qty: line.qty, p, store: s, linePrice: lp, saved: (p.prices[base] - p.prices[s]) * line.qty });
        total += lp;
      } else {
        const lp = p.prices[base] * line.qty;
        baseItems.push({ id: line.id, qty: line.qty, p, store: base, linePrice: lp, saved: 0 });
        total += lp;
      }
    });
    const savings = baseTotal - total;
    if (savings >= THRESHOLD && (!best || savings > best.savings)) {
      best = {
        stores: [base, s], total, savings,
        groups: [
          { store: base, items: baseItems, subtotal: baseItems.reduce((a, i) => a + i.linePrice, 0) },
          { store: s, items: altItems, subtotal: altItems.reduce((a, i) => a + i.linePrice, 0) },
        ].filter(g => g.items.length > 0),
      };
    }
  });
  return { base, baseTotal, worth: best !== null, split: best };
}

// ============ CART ============
function CartScreen({ cart, plan, usageUsed, onAdd, onQty, onAnalyze }) {
  const T = CESTO_STRINGS.pt;
  const [query, setQuery] = useState('');
  const cheapestStore = p => CESTO_STORE_KEYS.reduce((m, s) => p.prices[s] < p.prices[m] ? s : m, CESTO_STORE_KEYS[0]);
  const suggest = useMemo(() => {
    if (!query.trim()) return [];
    const q = query.trim().toLowerCase();
    return CESTO_PRODUCTS.filter(p => p.pt.toLowerCase().includes(q) || p.en.toLowerCase().includes(q)).slice(0, 6);
  }, [query]);
  const inCart = id => cart.find(i => i.id === id);
  const popular = CESTO_DEFAULT_CART.slice(0, 5).map(i => CESTO_PRODUCT_BY_ID[i.id]).filter(Boolean);
  const canGo = plan === 'member' || usageUsed < 1;

  return (
    <div className="screen screen-enter">
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 4 }}>
        <h2 className="h2" style={{ flex: 1 }}>{T.cart_title}</h2>
        {cart.length > 0 && (
          <span style={{ fontSize: 13, fontWeight: 600, color: 'var(--muted)' }}>
            {T.cart_count(cart.reduce((s, i) => s + i.qty, 0))}
          </span>
        )}
      </div>

      {/* search */}
      <div style={{ position: 'relative', zIndex: 30, marginBottom: 14 }}>
        <div className="searchwrap">
          <span className="searchwrap__icon" style={{ fontSize: 15, opacity: .65 }}>⌕</span>
          <input className="searchinput" value={query} onChange={e => setQuery(e.target.value)}
            placeholder={T.cart_search_ph} />
          {query && <button className="searchwrap__clear" onClick={() => setQuery('')}>×</button>}
        </div>
        {suggest.length > 0 && (
          <div className="suggest">
            {suggest.map(p => {
              const cs = cheapestStore(p);
              const added = inCart(p.id);
              return (
                <div key={p.id} className="suggest__row"
                  onClick={() => { onAdd(p.id); setQuery(''); }}>
                  <span className="prod__glyph">{p.glyph}</span>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div className="prod__name">{p.pt}</div>
                    <div className="prod__unit">{T.cart_from} {eur(p.prices[cs])} · {CESTO_STORES[cs].name}</div>
                  </div>
                  <span className="suggest__add" style={{ background: added ? 'var(--line)' : 'var(--mint)', color: added ? 'var(--muted)' : '#fff' }}>
                    {added ? '✓' : '+'}
                  </span>
                </div>
              );
            })}
          </div>
        )}
      </div>

      <div className="screen__scroll">
        {cart.length === 0 ? (
          <div>
            <p className="kicker" style={{ marginBottom: 12 }}>{T.cart_popular}</p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {popular.map(p => {
                const cs = cheapestStore(p);
                return (
                  <div key={p.id} className="cartline">
                    <span className="prod__glyph">{p.glyph}</span>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div className="prod__name">{p.pt}</div>
                      <div className="prod__unit">{eur(p.prices[cs])} · {CESTO_STORES[cs].name}</div>
                    </div>
                    <button className="iconbtn" onClick={() => onAdd(p.id)}
                      style={{ background: 'var(--mint)', color: '#fff', border: 'none', flexShrink: 0 }}>+</button>
                  </div>
                );
              })}
            </div>
            <p style={{ textAlign: 'center', color: 'var(--muted)', fontSize: 13.5, marginTop: 20, lineHeight: 1.5 }}>
              {T.cart_empty}
            </p>
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {cart.map(line => {
              const p = CESTO_PRODUCT_BY_ID[line.id];
              if (!p) return null;
              const cs = cheapestStore(p);
              return (
                <div key={line.id} className="cartline">
                  <span className="prod__glyph">{p.glyph}</span>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div className="prod__name">{p.pt}</div>
                    <div className="prod__unit">{T.cart_from} {eur(p.prices[cs])} · {CESTO_STORES[cs].name}</div>
                  </div>
                  <div className="stepper">
                    <button onClick={() => onQty(line.id, -1)}>−</button>
                    <span className="stepper__n">{line.qty}</span>
                    <button onClick={() => onQty(line.id, 1)}>+</button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
        <div style={{ height: 12 }} />
      </div>

      <div className="screen__foot">
        <button className="btn" onClick={onAnalyze} disabled={cart.length === 0}>
          {T.cart_cta}
        </button>
        {!canGo && (
          <p style={{ textAlign: 'center', fontSize: 12.5, color: 'var(--muted)', marginTop: 4 }}>
            {T.free_used}
          </p>
        )}
      </div>
    </div>
  );
}

// ============ ANALYZING ============
function AnalyzingScreen() {
  const T = CESTO_STRINGS.pt;
  const [step, setStep] = useState(0);
  useEffect(() => {
    const timers = T.analyzing_steps.map((_, i) => setTimeout(() => setStep(i + 1), (i + 1) * 400));
    return () => timers.forEach(clearTimeout);
  }, []);
  return (
    <div className="screen">
      <div className="analyze">
        <div className="scanner">
          <div className="scanner__ring" />
          <div className="scanner__ring scanner__ring--spin" />
          <div className="scanner__core">
            <div className="scanner__line" />
          </div>
        </div>
        <h2 className="h2" style={{ textAlign: 'center', fontSize: 21 }}>{T.analyzing_title}</h2>
        <div className="alist">
          {T.analyzing_steps.map((s, i) => (
            <div key={i} className={'arow' + (i < step ? ' is-done' : i === step ? ' is-active' : '')}>
              <StoreTile store={CESTO_STORE_KEYS[i % CESTO_STORE_KEYS.length]} size={32} />
              <span className="arow__txt">{s}</span>
              <span className="arow__check">
                {i < step ? '✓' : i === step ? <span className="spinner-sm" /> : ''}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ============ COMPARE ============
function CompareScreen({ cmp, splitData, plan, onBack, onReceipt, onSplit, onUpgrade }) {
  const T = CESTO_STRINGS.pt;
  const [run, setRun] = useState(false);
  useEffect(() => { const id = setTimeout(() => setRun(true), 120); return () => clearTimeout(id); }, []);
  const animSavings = useCountUp(cmp.savings, run);
  const sz = cmp.savings > 15 ? 'bold' : cmp.savings < 5 ? 'subtle' : '';

  return (
    <div className="screen screen-enter">
      <TopNav onBack={onBack} right={
        <span style={{ fontSize: 11, fontWeight: 700, color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: '.07em' }}>
          {T.compare_kicker}
        </span>
      } />

      {/* dark savings card */}
      <div className="savings-card" data-savings={sz || undefined}>
        <div className="savings-card__glow" />
        <div style={{ position: 'relative' }}>
          <div className="kicker" style={{ color: 'var(--mint-soft)', marginBottom: 6 }}>
            {T.result_savings_label}
          </div>
          <div className="savings-num">
            <small>−</small>
            {animSavings.toFixed(2).replace('.', ',')} €
          </div>
          <div style={{ fontSize: 13, color: 'var(--mint-soft)', marginTop: 5 }}>{T.result_vs}</div>
          <div style={{ marginTop: 16, paddingTop: 14, borderTop: '1px solid rgba(255,255,255,.12)', display: 'flex', alignItems: 'center', gap: 12 }}>
            <StoreTile store={cmp.cheapest.store} size={42} />
            <div>
              <div style={{ fontSize: 19, fontWeight: 800, color: '#fff', letterSpacing: '-.02em' }}>
                {CESTO_STORES[cmp.cheapest.store].name}
              </div>
              <div style={{ fontSize: 13, color: 'var(--mint-soft)', marginTop: 1 }}>
                {T.compare_cheapest} · {eur(cmp.cheapest.total)}
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="screen__scroll" style={{ marginTop: 16 }}>
        <div className="kicker">{T.compare_ranking}</div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 9, marginTop: 12 }}>
          {cmp.ranking.map((r, i) => {
            const diff = r.total - cmp.cheapest.total;
            const maxDiff = cmp.expensive.total - cmp.cheapest.total;
            const barW = maxDiff > 0 ? (1 - diff / maxDiff) * 100 : 100;
            return (
              <div key={r.store} className="rankrow">
                <span className="rankrow__pos">{i + 1}</span>
                <StoreTile store={r.store} size={36} />
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 15, fontWeight: 700 }}>{CESTO_STORES[r.store].name}</div>
                  <div className="bar" style={{ marginTop: 5 }}>
                    <div className="bar__fill" style={{ width: `${barW}%`, background: 'var(--mint)' }} />
                  </div>
                </div>
                <span className={'diffpill' + (i === 0 ? ' diffpill--win' : '')}>
                  {i === 0 ? eur(r.total) : '+' + eur(diff)}
                </span>
              </div>
            );
          })}
        </div>

        {splitData && splitData.worth && (
          <div className="insight" style={{ marginTop: 20, display: 'flex', alignItems: 'center', gap: 12 }}>
            <span style={{ fontSize: 22 }}>✂️</span>
            <div>
              <div style={{ fontSize: 14.5, fontWeight: 800 }}>Divisão inteligente possível</div>
              <div style={{ fontSize: 13, color: 'var(--muted)', marginTop: 2 }}>
                Dividindo por 2 lojas poupa adicionalmente {eur(splitData.split.savings)}
              </div>
            </div>
          </div>
        )}
        <div style={{ height: 12 }} />
      </div>

      <div className="screen__foot">
        <button className="btn" onClick={onReceipt}>{T.compare_cta}</button>
        {splitData && splitData.worth && (
          plan === 'member'
            ? <button className="btn btn--soft" onClick={onSplit}>✂ {T.compare_split_cta}</button>
            : <button className="btn btn--soft" onClick={onUpgrade}>
                ✂ {T.compare_split_cta} <span className="splitprem" style={{ marginLeft: 4 }}>★ Premium</span>
              </button>
        )}
      </div>
    </div>
  );
}

// ============ RECEIPT ============
function ReceiptScreen({ cmp, cart, onBack, onWallet }) {
  const T = CESTO_STRINGS.pt;
  const winner = cmp.cheapest.store;
  const worst = cmp.expensive.store;
  const items = cart.map(line => {
    const p = CESTO_PRODUCT_BY_ID[line.id];
    if (!p) return null;
    return { id: line.id, qty: line.qty, p, price: p.prices[winner] * line.qty };
  }).filter(Boolean);
  const total = cmp.cheapest.total;
  const worstTotal = cmp.expensive.total;

  return (
    <div className="screen screen-enter" style={{ background: 'var(--surface-2)', paddingLeft: 0, paddingRight: 0 }}>
      <div style={{ padding: '0 24px' }}>
        <TopNav onBack={onBack} right={<span className="kicker">{T.receipt_title}</span>} />
      </div>

      <div className="screen__scroll" style={{ paddingLeft: 20, paddingRight: 20 }}>
        <div className="receipt">
          <div className="receipt__head">
            <StoreTile store={winner} size={42} />
            <div>
              <div className="receipt__store">{CESTO_STORES[winner].name}</div>
              <div className="receipt__meta">{T.receipt_subtitle}</div>
            </div>
          </div>
          <div className="receipt__rule" />
          <div className="receipt__cols">
            <span style={{ flex: 1 }}>Produto</span>
            <span style={{ width: 26 }}>{T.receipt_qty}</span>
            <span>{T.receipt_total}</span>
          </div>
          {items.map(it => (
            <div key={it.id} className="receipt__item mono">
              <span className="receipt__qty">{it.qty}×</span>
              <span className="receipt__name">{it.p.pt}</span>
              <span className="receipt__dots" />
              <span className="receipt__price">{eur(it.price)}</span>
            </div>
          ))}
          <div className="receipt__rule" />
          <div className="receipt__total">
            <span>{T.receipt_total}</span>
            <span className="mono">{eur(total)}</span>
          </div>
          <div className="receipt__worst">
            <span>{T.receipt_worst} ({CESTO_STORES[worst].name})</span>
            <span className="mono">{eur(worstTotal)}</span>
          </div>
        </div>
        <div className="receipt__torn" />

        <div className="savehero">
          <div className="savehero__label">{T.receipt_savings}</div>
          <div className="savehero__num mono">{eur(worstTotal - total)}</div>
          <div className="savehero__sub">{T.result_vs}</div>
        </div>
        <div style={{ height: 14 }} />
      </div>

      <div className="screen__foot" style={{ padding: '14px 24px 20px' }}>
        <button className="btn btn--member" onClick={onWallet}>💚 {T.receipt_to_wallet}</button>
        <button className="btn btn--ghost" style={{ marginTop: 4 }} onClick={onBack}>{T.compare_edit}</button>
      </div>
    </div>
  );
}

// ============ SPLIT ============
function SplitScreen({ splitData, cmp, onBack, onAccept }) {
  const T = CESTO_STRINGS.pt;
  const [mode, setMode] = useState(splitData.worth ? 'split' : 'single');

  return (
    <div className="screen screen-enter">
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 12 }}>
        <button className="iconbtn" onClick={onBack} aria-label="voltar">‹</button>
        <h2 className="h2" style={{ flex: 1 }}>{T.split_title}</h2>
        <span className="splitprem">★ Premium</span>
      </div>
      <p className="body" style={{ fontSize: 13.5, marginBottom: 14 }}>{T.split_sub}</p>

      <div className="splittabs">
        <button className={'splittab' + (mode === 'single' ? ' is-on' : '')} onClick={() => setMode('single')}>
          <span className="splittab__k">{T.split_single}</span>
          <span className="splittab__v mono">{eur(cmp.cheapest.total)}</span>
          <span className="splittab__store">{CESTO_STORES[cmp.cheapest.store].name}</span>
        </button>
        <button
          className={'splittab splittab--best' + (mode === 'split' ? ' is-on' : '')}
          onClick={() => splitData.worth && setMode('split')}
          disabled={!splitData.worth}>
          {splitData.worth && <span className="splittab__badge">★</span>}
          <span className="splittab__k">{T.split_split(2)}</span>
          <span className="splittab__v mono">{splitData.split ? eur(splitData.split.total) : '—'}</span>
          <span className="splittab__store">
            {splitData.worth ? T.split_save_extra + ' −' + eur(splitData.split.savings) : '—'}
          </span>
        </button>
      </div>

      <div className="screen__scroll" style={{ marginTop: 16 }}>
        {mode === 'split' && splitData.worth
          ? splitData.split.groups.map(g => (
            <div key={g.store} className="sgroup" style={{ marginBottom: 12 }}>
              <div className="sgroup__head">
                <StoreTile store={g.store} size={38} />
                <div style={{ flex: 1 }}>
                  <div className="sgroup__name">{CESTO_STORES[g.store].name}</div>
                  <div className="sgroup__meta">{T.split_items(g.items.length)}</div>
                </div>
                <div className="sgroup__sub mono">{eur(g.subtotal)}</div>
              </div>
              <div className="sgroup__items">
                {g.items.map(it => (
                  <div key={it.id} className="sitem">
                    <span className="sitem__glyph">{it.p.glyph}</span>
                    <span className="sitem__name">{it.p.pt}{it.qty > 1 ? ` ×${it.qty}` : ''}</span>
                    {it.saved > 0.005 && <span className="sitem__saved">−{eur(it.saved)}</span>}
                    <span className="sitem__price mono">{eur(it.linePrice)}</span>
                  </div>
                ))}
              </div>
            </div>
          ))
          : (
            <div className="notworth">
              <span style={{ fontSize: 22 }}>🛒</span>
              <div>
                <div className="notworth__t">{T.split_not_worth_title}</div>
                <div className="notworth__b">{T.split_not_worth_body(CESTO_STORES[cmp.cheapest.store].name)}</div>
              </div>
            </div>
          )
        }
        <div style={{ height: 12 }} />
      </div>

      <div className="screen__foot">
        {mode === 'split' && splitData.worth
          ? <button className="btn btn--member" onClick={onAccept}>✨ {T.split_accept}</button>
          : <button className="btn" onClick={onBack}>{T.split_keep_single}</button>
        }
      </div>
    </div>
  );
}

Object.assign(window, { CartScreen, AnalyzingScreen, CompareScreen, ReceiptScreen, SplitScreen, cestoSplitSimple });
