// CestoDoce_app_v2.jsx — App principal v2
(function () {
const { useState, useEffect, useCallback } = React;
const D = window.CestoDoceData;

const STORAGE = {
  PLAN:  'cd2_plan_v1',
  USAGE: 'cd2_usage_v1',
  CART:  'cd2_cart_v1',
};

function loadStorage() {
  try {
    return {
      plan:  localStorage.getItem(STORAGE.PLAN)  || 'free',
      usage: parseInt(localStorage.getItem(STORAGE.USAGE) || '0', 10),
      cart:  JSON.parse(localStorage.getItem(STORAGE.CART) || 'null') || D.DEMO_CART,
    };
  } catch { return { plan:'free', usage:0, cart:D.DEMO_CART }; }
}

function App() {
  const TWEAK_DEFAULTS = { theme:'verde', demo:'free_unused' };
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const theme = CD_THEMES[t.theme] || CD_THEMES.verde;

  const initial = loadStorage();
  function resolveState(demo, stored) {
    if (demo === 'member')      return { plan:'member', usageUsed:3 };
    if (demo === 'used_quota')  return { plan:'free',   usageUsed:1 };
    return { plan:stored.plan, usageUsed:stored.usage };
  }
  const resolved = resolveState(t.demo, initial);
  const USAGE_LIMIT = 1;

  const [screen,         setScreen]         = useState('home');
  const [cart,           setCart]           = useState(initial.cart);
  const [analysisResult, setAnalysisResult] = useState(null);
  const [plan,           setPlan]           = useState(resolved.plan);
  const [usageUsed,      setUsageUsed]      = useState(resolved.usageUsed);
  const [lastSavings,    setLastSavings]    = useState(null);
  const [showPaywall,    setShowPaywall]    = useState(false);
  const [simBudget,      setSimBudget]      = useState(120);

  // Sincronizar demo tweak
  useEffect(() => {
    const r = resolveState(t.demo, initial);
    setPlan(r.plan);
    setUsageUsed(r.usageUsed);
  }, [t.demo]);

  // Persistir cart
  useEffect(() => {
    try { localStorage.setItem(STORAGE.CART, JSON.stringify(cart)); } catch {}
  }, [cart]);

  const cartCount  = cart.reduce((s, i) => s + i.qty, 0);
  const usageLeft  = USAGE_LIMIT - usageUsed;
  const canAnalyse = plan === 'member' || usageLeft > 0;

  // --- Cart ---
  const addToCart = useCallback(productId => {
    setCart(prev => prev.find(i => i.productId === productId) ? prev : [...prev, { productId, qty:1 }]);
  }, []);

  const changeQty = useCallback((productId, delta) => {
    setCart(prev => prev
      .map(i => i.productId === productId ? { ...i, qty: Math.max(0, i.qty + delta) } : i)
      .filter(i => i.qty > 0));
  }, []);

  // --- Analyse ---
  const runAnalysis = useCallback(() => {
    if (!cart.length) return;
    if (!canAnalyse) { setShowPaywall(true); return; }
    setScreen('analyzing');
    setTimeout(() => {
      const result = D.compareCart(cart);
      // tag with original cart for free-vs-premium comparison
      if (result) result._cart = cart;
      setAnalysisResult(result);
      if (result) setLastSavings(result.shouldSplit ? result.savings : 0);
      if (plan === 'free') {
        const next = usageUsed + 1;
        setUsageUsed(next);
        try { localStorage.setItem(STORAGE.USAGE, String(next)); } catch {}
      }
      setScreen('analysis');
    }, D.SUPERMARKETS.length * 300 + 800);
  }, [cart, canAnalyse, plan, usageUsed]);

  // --- Subscribe ---
  const subscribe = useCallback(() => {
    setPlan('member');
    setUsageUsed(0);
    setShowPaywall(false);
    try { localStorage.setItem(STORAGE.PLAN, 'member'); } catch {}
    // re-run if we have a cart
    if (cart.length > 0) {
      setTimeout(() => {
        setScreen('analyzing');
        setTimeout(() => {
          const result = D.compareCart(cart);
          if (result) result._cart = cart;
          setAnalysisResult(result);
          if (result) setLastSavings(result.shouldSplit ? result.savings : 0);
          setScreen('analysis');
        }, D.SUPERMARKETS.length * 300 + 800);
      }, 300);
    }
  }, [cart]);

  const totalMonthlySaved = lastSavings != null ? lastSavings : 4.30;

  function renderScreen() {
    switch (screen) {
      case 'home':
        return <HomeScreenV2
          theme={theme} onNewCart={() => setScreen('cart')}
          cartCount={cartCount} plan={plan} totalMonthlySaved={totalMonthlySaved}
          simBudget={simBudget} onSimBudgetChange={setSimBudget}
        />;
      case 'cart':
        return <CartScreenV2
          theme={theme} cart={cart}
          onChangeQty={changeQty} onAdd={addToCart}
          onAnalyse={runAnalysis}
          plan={plan} usageLeft={usageLeft}
        />;
      case 'analyzing':
        return <AnalyzingScreenV2 theme={theme} plan={plan}/>;
      case 'analysis':
        return <AnalysisScreenV2
          theme={theme} result={analysisResult} plan={plan}
          onBack={() => setScreen('cart')}
          onGoCart={() => setScreen('cart')}
          onUpgrade={() => setShowPaywall(true)}
        />;
      case 'profile':
        return <ProfileScreenV2
          theme={theme} plan={plan}
          usageUsed={usageUsed} usageLimit={USAGE_LIMIT}
          lastSavings={lastSavings}
          onUpgrade={() => setShowPaywall(true)}
        />;
      default: return null;
    }
  }

  const cartScreens = ['cart','analyzing','analysis'];
  const activeTab = cartScreens.includes(screen)
    ? (screen === 'analysis' ? 'analysis' : 'cart')
    : screen;

  return (
    <div style={{ fontFamily:"'DM Sans',sans-serif", color:CD.ink, fontSize:15.5, lineHeight:1.45 }}>
      <PhoneFrame>
        {/* scrollable content */}
        <div style={{ position:'absolute', inset:0, bottom:62, background:CD.bg }}>
          {renderScreen()}
        </div>

        {/* paywall */}
        {showPaywall && (
          <PaywallSheetV2
            theme={theme} lastSavings={lastSavings}
            simBudget={simBudget}
            onSubscribe={subscribe}
            onClose={() => setShowPaywall(false)}
          />
        )}

        {/* tab bar */}
        {screen !== 'analyzing' && (
          <TabBar
            current={activeTab}
            onChange={s => {
              if (s === 'analysis' && !analysisResult) { setScreen('cart'); return; }
              setScreen(s);
            }}
            cartCount={cartCount} theme={theme}
          />
        )}
      </PhoneFrame>

      {/* tweaks */}
      <TweaksPanel>
        <TweakSection label="Aparência"/>
        <TweakRadio
          label="Cor" value={t.theme}
          options={['verde','azul','laranja']}
          onChange={v => setTweak('theme', v)}
        />
        <TweakSection label="Cenário demo"/>
        <TweakSelect
          label="Estado da conta"
          value={t.demo}
          options={[
            { value:'free_unused', label:'Grátis · análise disponível' },
            { value:'used_quota',  label:'Grátis · quota usada' },
            { value:'member',      label:'CestoDoce Member' },
          ]}
          onChange={v => setTweak('demo', v)}
        />
      </TweaksPanel>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App/>);
})();
