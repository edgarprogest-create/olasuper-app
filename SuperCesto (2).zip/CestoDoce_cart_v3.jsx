// CestoDoce_cart_v3.jsx — Cart premium: folhetos + pesquisa + análise + paywall
(function(){
const { useState, useEffect, useMemo, useCallback } = React;
const D  = window.CestoDoceData;
const D3 = window.CestoDoceDataV3;

const FREE_LIMIT = 20;
const FREE_PRODS = D.PRODUCTS.slice(0, FREE_LIMIT);
const MEDIAN_SAVE = 0.14;
const PREMIUM_UP  = 1.42;

// ============ HOME v3 ============
function buildSparks() {
  const prods = D.PRODUCTS;
  const noise = {
    continente:  [1.01,1.02,1.00,1.01,1.02,1.01,1.00,1.00],
    pingodoce:   [1.04,0.99,0.97,0.94,0.93,0.95,0.94,0.94],
    lidl:        [0.92,0.91,0.93,0.90,0.91,0.89,0.90,0.90],
    aldi:        [0.91,0.92,0.90,0.89,0.90,0.88,0.89,0.89],
    mercadona:   [0.97,0.98,0.96,0.97,0.97,0.96,0.96,0.96],
    intermarche: [0.99,1.00,1.01,1.00,1.01,1.00,1.00,1.00],
  };
  const baseAvg = {};
  D.SUPERMARKETS.forEach(sm => {
    baseAvg[sm.id] = prods.reduce((s,p)=>s+(p.prices[sm.id]||0),0)/prods.length;
  });
  return D.SUPERMARKETS.map(sm => {
    const n = noise[sm.id]||Array(8).fill(1);
    const hist = n.map((f,i)=>{
      const maxV = Math.max(...D.SUPERMARKETS.map(s=>baseAvg[s.id]*(noise[s.id]||Array(8).fill(1))[i]));
      return maxV - baseAvg[sm.id]*f;
    });
    return { id:sm.id, name:sm.name, values:hist, today:hist[hist.length-1], delta:hist[hist.length-1]-hist[hist.length-2] };
  }).sort((a,b)=>b.today-a.today);
}

function buildCatWins() {
  return D.CATEGORIES.map(cat=>{
    const prods = D.PRODUCTS.filter(p=>p.category===cat.id);
    if(!prods.length) return null;
    const totals = D.SUPERMARKETS.map(sm=>({ sm, total:prods.reduce((s,p)=>s+(p.prices[sm.id]||0),0) })).sort((a,b)=>a.total-b.total);
    return { category:cat, winner:totals[0].sm, saving:totals[totals.length-1].total-totals[0].total, promoCount:prods.filter(p=>p.promo&&p.promo[totals[0].sm.id]).length };
  }).filter(Boolean);
}

const SPARKS   = buildSparks();
const CAT_WINS = buildCatWins();

function HomeV3({ theme, onNewCart, cartCount, plan, monthlySaved }) {
  const [simOpen, setSimOpen] = useState(false);
  const [budget,  setBudget]  = useState(120);
  const freeSave    = Math.round(budget*MEDIAN_SAVE*100)/100;
  const premSave    = Math.round(budget*MEDIAN_SAVE*PREMIUM_UP*100)/100;
  const uplift      = Math.round((premSave-freeSave)*100)/100;
  const sliderPct   = ((budget-20)/(500-20))*100;
  const col = d => d>0.005?V3.mintText : d<-0.005?V3.red : V3.ink3;

  return (
    <div data-screen-label="Início — stock market" style={{ paddingTop:54, height:'100%', display:'flex', flexDirection:'column' }}>
      {/* header */}
      <div style={{ padding:'12px 20px 0', display:'flex', alignItems:'center', gap:10, flexShrink:0 }}>
        <div style={{ flex:1 }}>
          <p style={{ margin:0, fontSize:11, fontWeight:700, color:V3.ink3, textTransform:'uppercase', letterSpacing:'0.1em' }}>Semana 8–14 jun · Demo</p>
          <h1 style={{ margin:'3px 0 0', fontSize:22, fontWeight:800, color:V3.ink, letterSpacing:'-0.03em', lineHeight:1.1 }}>Mercado de Poupança</h1>
        </div>
        <div style={{ textAlign:'right' }}>
          <p style={{ margin:0, fontSize:10.5, color:V3.ink3 }}>Poupado este mês</p>
          <p style={{ margin:0, fontSize:18, fontWeight:800, color:theme.primaryText, fontVariantNumeric:'tabular-nums' }}>{euro(monthlySaved)}</p>
        </div>
      </div>

      <div style={{ flex:1, overflowY:'auto', padding:'14px 20px 130px' }}>
        {/* stock list */}
        <div style={{ marginBottom:10 }}>
          <div style={{ display:'flex', alignItems:'baseline', justifyContent:'space-between', marginBottom:8 }}>
            <span style={{ fontSize:12, fontWeight:700, color:V3.ink2, textTransform:'uppercase', letterSpacing:'0.07em' }}>Performance · €/produto vs pior loja</span>
          </div>
          <V3Card style={{ padding:'2px 0' }}>
            {SPARKS.map((sm,i)=>{
              const c = col(sm.delta);
              const isWin = i===0;
              return (
                <div key={sm.id} style={{ display:'flex', alignItems:'center', gap:11, padding:'11px 16px', borderBottom:i<SPARKS.length-1?`1px solid ${V3.border}`:'none', background:isWin?`${theme.primaryDim}`:'transparent' }}>
                  <span style={{ width:16, fontSize:11, fontWeight:800, color:isWin?theme.primaryText:V3.ink3, textAlign:'center', flexShrink:0 }}>{i+1}</span>
                  <V3Badge id={sm.id} size={32}/>
                  <div style={{ flex:1, minWidth:0 }}>
                    <div style={{ fontSize:14, fontWeight:isWin?800:600, color:V3.ink, display:'flex', alignItems:'center', gap:6 }}>
                      {sm.name}
                      {isWin && <span style={{ fontSize:9.5, fontWeight:700, color:theme.primary, background:theme.primaryDim, padding:'2px 6px', borderRadius:100, border:`1px solid ${theme.primary}40` }}>↑ LÍDER</span>}
                    </div>
                    <div style={{ fontSize:11.5, color:c, fontWeight:700, marginTop:1, display:'flex', alignItems:'center', gap:3 }}>
                      {sm.delta>0.005?<><TrendUpIco size={11} color={c}/>+{euro(sm.delta)}</>:sm.delta<-0.005?<><TrendDownIco size={11} color={c}/>{euro(sm.delta)}</>:<span style={{color:V3.ink3}}>— estável</span>}
                    </div>
                  </div>
                  <V3Spark values={sm.values} color={c} width={64} height={30}/>
                  <span style={{ fontSize:14, fontWeight:800, color:c, fontVariantNumeric:'tabular-nums', minWidth:38, textAlign:'right' }}>{euro(sm.today)}</span>
                </div>
              );
            })}
          </V3Card>
        </div>

        {/* categories */}
        <div style={{ marginBottom:14 }}>
          <span style={{ fontSize:12, fontWeight:700, color:V3.ink2, textTransform:'uppercase', letterSpacing:'0.07em' }}>Vencedor por Categoria</span>
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:8, marginTop:8 }}>
            {CAT_WINS.map(({category,winner,saving,promoCount})=>(
              <V3Card key={category.id} style={{ padding:'12px 12px' }}>
                <p style={{ margin:'0 0 8px', fontSize:10, fontWeight:700, color:V3.ink3, textTransform:'uppercase', letterSpacing:'0.07em' }}>{category.name}</p>
                <div style={{ display:'flex', alignItems:'center', gap:8 }}>
                  <V3Badge id={winner.id} size={28}/>
                  <div style={{ flex:1, minWidth:0 }}>
                    <div style={{ fontSize:12.5, fontWeight:800, color:V3.ink, whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>{winner.name}</div>
                    <div style={{ fontSize:11, color:theme.primaryText, fontWeight:700 }}>−{euro(saving)}</div>
                  </div>
                </div>
                {promoCount>0&&<V3Pill color={V3.promo} dim={V3.promoDim} style={{marginTop:6,fontSize:10}}><TagIco size={9} color={V3.promo}/> {promoCount} promo</V3Pill>}
              </V3Card>
            ))}
          </div>
        </div>

        {/* simulator */}
        <div>
          <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:8, cursor:'pointer' }} onClick={()=>setSimOpen(v=>!v)}>
            <span style={{ fontSize:12, fontWeight:700, color:V3.ink2, textTransform:'uppercase', letterSpacing:'0.07em' }}>Simulador de Poupança</span>
            <span style={{ fontSize:12, fontWeight:700, color:theme.primaryText }}>{simOpen?'▲':'▼'}</span>
          </div>

          {simOpen ? (
            <V3Card style={{ padding:'18px 16px' }}>
              <div style={{ display:'flex', alignItems:'baseline', gap:6, marginBottom:12 }}>
                <span style={{ fontSize:28, fontWeight:800, color:V3.ink, fontVariantNumeric:'tabular-nums' }}>{budget}</span>
                <span style={{ fontSize:14, fontWeight:700, color:V3.ink2 }}>€/mês estimado</span>
              </div>
              <input type="range" min="20" max="500" step="5" value={budget}
                onChange={e=>setBudget(Number(e.target.value))}
                style={{ width:'100%', height:5, borderRadius:100, marginBottom:16, background:`linear-gradient(90deg,${theme.primary} ${sliderPct}%,${V3.surface3} ${sliderPct}%)` }}
              />
              <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:8 }}>
                <div style={{ background:V3.surface2, borderRadius:12, padding:'12px 14px' }}>
                  <div style={{ fontSize:10, color:V3.ink3, fontWeight:700, textTransform:'uppercase', marginBottom:4 }}>Plano Grátis</div>
                  <div style={{ fontSize:21, fontWeight:800, color:V3.ink, fontVariantNumeric:'tabular-nums' }}>{euro(freeSave)}</div>
                  <div style={{ fontSize:10.5, color:V3.ink3, marginTop:3 }}>{FREE_LIMIT} produtos/loja</div>
                </div>
                <div style={{ background:theme.primaryDim, border:`1px solid ${theme.primary}40`, borderRadius:12, padding:'12px 14px' }}>
                  <div style={{ fontSize:10, color:theme.primaryText, fontWeight:700, textTransform:'uppercase', marginBottom:4 }}>★ Member</div>
                  <div style={{ fontSize:21, fontWeight:800, color:theme.primaryText, fontVariantNumeric:'tabular-nums' }}>{euro(premSave)}</div>
                  <div style={{ fontSize:10.5, color:theme.primary, marginTop:3, opacity:0.8 }}>catálogo completo</div>
                </div>
              </div>
              <div style={{ marginTop:10, padding:'10px 12px', background:V3.surface2, borderRadius:10, fontSize:12.5, color:V3.ink2, lineHeight:1.5 }}>
                <SparkIco size={15} color={theme.primaryText}/>&nbsp; Member desbloqueia <strong style={{color:theme.primaryText}}>+{euro(uplift)}/mês</strong> extra
              </div>
            </V3Card>
          ) : (
            <V3Card style={{ padding:'12px 14px', display:'flex', alignItems:'center', gap:12, cursor:'pointer' }} onClick={()=>setSimOpen(true)}>
              <SparkIco size={22} color={theme.primary}/>
              <div>
                <div style={{ fontSize:13.5, fontWeight:700, color:V3.ink }}>Quanto poupas com a tua lista?</div>
                <div style={{ fontSize:12, color:V3.ink3, marginTop:1 }}>Simula o teu ganho mensal →</div>
              </div>
            </V3Card>
          )}
        </div>

        {/* CTA */}
        <div style={{ marginTop:16 }}>
          <V3Btn theme={theme} onClick={onNewCart}>
            <BasketIco size={18} color="#000"/>
            {cartCount>0?`Continuar carrinho (${cartCount})`:'Criar carrinho'}
          </V3Btn>
        </div>
      </div>
    </div>
  );
}

// ============ CART v3 ============
function CartV3({ theme, cart, onChangeQty, onAdd, onAnalyse, plan, usageLeft }) {
  const [query, setQuery]       = useState('');
  const [activeTab, setActiveTab] = useState('folhetos'); // folhetos | carrinho
  const [selCat, setSelCat]     = useState('frescos');

  const planProds = plan==='member' ? D.PRODUCTS : FREE_PRODS;
  const results = useMemo(()=>{
    if(!query.trim()) return [];
    const q=query.trim().toLowerCase();
    return planProds.filter(p=>p.name.toLowerCase().includes(q)).slice(0,7);
  },[query,planProds]);

  const cartProducts = cart.map(it=>({ ...it, product:D.PRODUCTS.find(p=>p.id===it.productId) })).filter(x=>x.product);
  const bestTotal = useMemo(()=>{
    if(!cart.length) return 0;
    const r=D.compareCart(cart); return r?r.splitTotal:0;
  },[cart]);
  const inCart = id=>cart.find(i=>i.productId===id);

  const CATS = D.CATEGORIES;
  const flyersForCat = D3.getFlyers(selCat);
  const highlights   = D3.getFlyerHighlights();

  return (
    <div data-screen-label="Carrinho — folhetos e pesquisa" style={{ paddingTop:54, height:'100%', display:'flex', flexDirection:'column' }}>
      {/* header */}
      <div style={{ padding:'10px 20px 0', flexShrink:0 }}>
        <div style={{ display:'flex', alignItems:'center', gap:10, marginBottom:12 }}>
          <h1 style={{ flex:1, margin:0, fontSize:20, fontWeight:800, color:V3.ink, letterSpacing:'-0.025em' }}>Carrinho</h1>
          {cart.length>0&&<span style={{ fontSize:12.5, fontWeight:700, color:V3.ink3 }}>{cartProducts.reduce((s,i)=>s+i.qty,0)} artigos · {euro(bestTotal)}</span>}
        </div>

        {/* search */}
        <div style={{ position:'relative', zIndex:40, marginBottom:12 }}>
          <div style={{ display:'flex', alignItems:'center', gap:10, background:V3.surface2, border:`1px solid ${query?theme.primary:V3.border}`, borderRadius:12, padding:'0 14px', transition:'border-color 0.15s' }}>
            <SearchIco size={17} color={V3.ink3}/>
            <input value={query} onChange={e=>setQuery(e.target.value)}
              placeholder={plan==='member'?'Pesquisar (catálogo completo)…':`Pesquisar (${FREE_LIMIT} produtos disponíveis)…`}
              style={{ flex:1, border:'none', outline:'none', background:'transparent', fontSize:14.5, fontFamily:'inherit', color:V3.ink, height:44 }}/>
            {query&&<button onClick={()=>setQuery('')} style={{ border:'none', background:'none', cursor:'pointer', color:V3.ink3, fontSize:13, fontFamily:'inherit' }}>✕</button>}
          </div>
          {results.length>0&&(
            <div style={{ position:'absolute', left:0, right:0, top:46, background:V3.surface, borderRadius:14, boxShadow:V3.shadowLift, overflow:'hidden', border:`1px solid ${V3.borderBright}`, zIndex:50 }}>
              {results.map(p=>{
                const cheapest=D.SUPERMARKETS.reduce((b,s)=>p.prices[s.id]<p.prices[b.id]?s:b);
                const added=inCart(p.id);
                return (
                  <button key={p.id} onClick={()=>{onAdd(p.id);setQuery('');}}
                    style={{ display:'flex', alignItems:'center', gap:12, width:'100%', padding:'10px 14px', border:'none', background:'none', cursor:'pointer', borderBottom:`1px solid ${V3.border}`, fontFamily:'inherit', textAlign:'left' }}>
                    <div style={{ flex:1, minWidth:0 }}>
                      <div style={{ fontSize:14, fontWeight:600, color:V3.ink }}>{p.name}</div>
                      <div style={{ fontSize:11.5, color:V3.ink3, marginTop:1 }}>desde {euro(p.prices[cheapest.id])} · {cheapest.name}
                        {p.promo&&p.promo[cheapest.id]&&<span style={{ color:V3.promo, fontWeight:700 }}> · promo</span>}
                      </div>
                    </div>
                    <span style={{ width:28, height:28, borderRadius:100, flexShrink:0, background:added?V3.mintDim:theme.primary, display:'flex', alignItems:'center', justifyContent:'center' }}>
                      {added?<CheckIco size={14} color={theme.primary}/>:<PlusIco size={14} color="#000"/>}
                    </span>
                  </button>
                );
              })}
            </div>
          )}
        </div>

        {/* tabs */}
        <div style={{ display:'flex', gap:4, background:V3.surface2, padding:3, borderRadius:10, marginBottom:12 }}>
          {[{id:'folhetos',label:'📋 Folhetos'},{id:'carrinho',label:`🧺 Carrinho${cart.length?` (${cart.length})`:''}`}].map(tab=>(
            <button key={tab.id} onClick={()=>setActiveTab(tab.id)} style={{
              flex:1, height:32, border:'none', borderRadius:8, fontFamily:'inherit',
              fontSize:12.5, fontWeight:700, cursor:'pointer',
              background:activeTab===tab.id?V3.surface3:'transparent',
              color:activeTab===tab.id?V3.ink:V3.ink3,
              transition:'all 0.15s',
            }}>{tab.label}</button>
          ))}
        </div>
      </div>

      {/* content */}
      <div style={{ flex:1, overflowY:'auto', padding:'0 20px 130px' }}>
        {activeTab==='folhetos' && (
          <div>
            {/* hero highlights */}
            <div style={{ marginBottom:14 }}>
              <p style={{ fontSize:11, fontWeight:700, color:V3.ink3, textTransform:'uppercase', letterSpacing:'0.08em', marginBottom:8 }}>⚡ Destaques da semana</p>
              <div style={{ display:'flex', gap:10, overflowX:'auto', paddingBottom:4, scrollbarWidth:'none' }}>
                {highlights.map(f=>(
                  <div key={f.id} onClick={()=>{ const p=D.PRODUCTS.find(x=>x.name.toLowerCase().includes(f.product.split(' ')[0].toLowerCase())); if(p)onAdd(p.id); }}
                    style={{ flexShrink:0, width:148, background:V3.surface2, border:`1px solid ${V3.border}`, borderRadius:14, padding:'12px 14px', cursor:'pointer' }}>
                    <div style={{ fontSize:26, marginBottom:6 }}>{f.emoji}</div>
                    <div style={{ fontSize:13, fontWeight:800, color:V3.ink, lineHeight:1.2, marginBottom:4 }}>{f.product}</div>
                    <div style={{ fontSize:11, color:V3.ink3, marginBottom:8 }}>{f.detail} · {f.store==='pingodoce'?'Pingo Doce':f.store==='lidl'?'Lidl':f.store==='aldi'?'Aldi':f.store==='continente'?'Continente':f.store==='mercadona'?'Mercadona':'Intermarché'}</div>
                    <div style={{ display:'flex', alignItems:'baseline', gap:6 }}>
                      <span style={{ fontSize:17, fontWeight:800, color:theme.primaryText, fontVariantNumeric:'tabular-nums' }}>{euro(f.promoPrice)}</span>
                      <span style={{ fontSize:11, color:V3.ink3, textDecoration:'line-through' }}>{euro(f.normalPrice)}</span>
                    </div>
                    <V3Pill color={V3.promo} dim={V3.promoDim} style={{marginTop:6,fontSize:10}}>−{f.savingPct}% · até {f.validUntil}</V3Pill>
                  </div>
                ))}
              </div>
            </div>

            {/* category filter */}
            <p style={{ fontSize:11, fontWeight:700, color:V3.ink3, textTransform:'uppercase', letterSpacing:'0.08em', marginBottom:8 }}>Por Categoria</p>
            <div style={{ display:'flex', gap:6, overflowX:'auto', paddingBottom:8, scrollbarWidth:'none', marginBottom:10 }}>
              {CATS.map(cat=>(
                <button key={cat.id} onClick={()=>setSelCat(cat.id)} style={{
                  flexShrink:0, height:30, padding:'0 12px', border:`1px solid ${selCat===cat.id?theme.primary:V3.border}`,
                  borderRadius:100, background:selCat===cat.id?theme.primaryDim:V3.surface2,
                  color:selCat===cat.id?theme.primaryText:V3.ink2, fontSize:12, fontWeight:700,
                  fontFamily:'inherit', cursor:'pointer', whiteSpace:'nowrap',
                }}>{cat.name}</button>
              ))}
            </div>

            {/* flyer cards */}
            <div style={{ display:'flex', flexDirection:'column', gap:9 }}>
              {flyersForCat.length===0?(
                <div style={{ textAlign:'center', padding:'32px 0', color:V3.ink3, fontSize:13.5 }}>Sem destaques nesta categoria esta semana.</div>
              ):flyersForCat.map(f=>{
                const matchProd = D.PRODUCTS.find(p=>p.name.toLowerCase().includes(f.product.split(' ')[0].toLowerCase()));
                const added = matchProd && inCart(matchProd.id);
                return (
                  <V3Card key={f.id} style={{ padding:'14px 16px' }}>
                    <div style={{ display:'flex', alignItems:'center', gap:12 }}>
                      <div style={{ fontSize:28, flexShrink:0, width:44, textAlign:'center' }}>{f.emoji}</div>
                      <div style={{ flex:1, minWidth:0 }}>
                        <div style={{ display:'flex', alignItems:'center', gap:8, flexWrap:'wrap', marginBottom:2 }}>
                          <span style={{ fontSize:14.5, fontWeight:800, color:V3.ink }}>{f.product}</span>
                          {f.highlight&&<V3Pill color={V3.amber} dim={V3.amberDim} style={{fontSize:10}}>⚡ destaque</V3Pill>}
                        </div>
                        <div style={{ fontSize:12, color:V3.ink3 }}>{f.detail} · até {f.validUntil}</div>
                        <div style={{ marginTop:6, display:'flex', alignItems:'center', gap:8 }}>
                          <V3Badge id={f.store} size={22}/>
                          <span style={{ fontSize:12, color:V3.ink3 }}>{f.store==='pingodoce'?'Pingo Doce':f.store==='lidl'?'Lidl':f.store==='aldi'?'Aldi':f.store==='continente'?'Continente':f.store==='mercadona'?'Mercadona':'Intermarché'}</span>
                        </div>
                      </div>
                      <div style={{ textAlign:'right', flexShrink:0 }}>
                        <div style={{ fontSize:18, fontWeight:800, color:theme.primaryText, fontVariantNumeric:'tabular-nums' }}>{euro(f.promoPrice)}</div>
                        <div style={{ fontSize:11.5, color:V3.ink3, textDecoration:'line-through' }}>{euro(f.normalPrice)}</div>
                        <V3Pill color={V3.promo} dim={V3.promoDim} style={{marginTop:5,fontSize:10}}>−{f.savingPct}%</V3Pill>
                      </div>
                    </div>
                    {matchProd&&(
                      <button onClick={()=>onAdd(matchProd.id)} style={{
                        marginTop:10, width:'100%', height:34, border:`1px solid ${added?theme.primary:V3.border}`,
                        borderRadius:9, background:added?theme.primaryDim:'transparent',
                        color:added?theme.primaryText:V3.ink2, fontSize:13, fontWeight:700,
                        fontFamily:'inherit', cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center', gap:6,
                      }}>
                        {added?<><CheckIco size={14} color={theme.primaryText}/> Adicionado</>:<><PlusIco size={14} color={V3.ink2}/> Adicionar ao carrinho</>}
                      </button>
                    )}
                  </V3Card>
                );
              })}
            </div>
          </div>
        )}

        {activeTab==='carrinho' && (
          <div>
            {cartProducts.length===0?(
              <div style={{ textAlign:'center', padding:'48px 0', color:V3.ink3 }}>
                <BasketIco size={40} color={V3.surface3}/>
                <p style={{ fontSize:14, lineHeight:1.55, margin:'14px 0 0' }}>Carrinho vazio.<br/>Pesquisa ou escolhe dos folhetos.</p>
              </div>
            ):(
              <V3Card style={{ padding:'4px 16px' }}>
                {cartProducts.map((it,idx)=>{
                  const cheapest=D.SUPERMARKETS.reduce((b,s)=>it.product.prices[s.id]<it.product.prices[b.id]?s:b);
                  const isPromo=it.product.promo&&it.product.promo[cheapest.id];
                  return (
                    <div key={it.productId} style={{ display:'flex', alignItems:'center', gap:12, padding:'12px 0', borderBottom:idx<cartProducts.length-1?`1px solid ${V3.border}`:'none' }}>
                      <div style={{ flex:1, minWidth:0 }}>
                        <div style={{ fontSize:14, fontWeight:700, color:V3.ink, display:'flex', alignItems:'center', gap:6, flexWrap:'wrap' }}>
                          {it.product.name}
                          {isPromo&&<V3Pill color={V3.promo} dim={V3.promoDim} style={{fontSize:10}}>promo</V3Pill>}
                        </div>
                        <div style={{ fontSize:12, color:V3.ink3, marginTop:2 }}>melhor: {euro(it.product.prices[cheapest.id])} · {cheapest.name}</div>
                      </div>
                      <V3Stepper qty={it.qty} theme={theme} onChange={d=>onChangeQty(it.productId,d)}/>
                    </div>
                  );
                })}
              </V3Card>
            )}
          </div>
        )}
      </div>

      {/* CTA */}
      {cartProducts.length>0&&(
        <div style={{ position:'absolute', left:0, right:0, bottom:62, padding:'12px 20px 14px', background:`linear-gradient(to top, ${V3.base} 60%, transparent)`, zIndex:50 }}>
          <V3Btn theme={theme} onClick={onAnalyse}>
            <SparkIco size={17} color="#000"/> Analisar carrinho
          </V3Btn>
          <p style={{ textAlign:'center', fontSize:11.5, color:V3.ink3, margin:'6px 0 0' }}>
            {plan==='member'?'Análises ilimitadas · Member':usageLeft>0?`${usageLeft} análise gratuita este mês`:'Limite atingido · upgrade para continuar'}
          </p>
        </div>
      )}
    </div>
  );
}

// ============ ANALYZING v3 ============
function AnalyzingV3({ theme, plan }) {
  const [step, setStep] = useState(0);
  const total = plan==='member'?D.PRODUCTS.length:FREE_LIMIT;
  useEffect(()=>{
    const ts = D.SUPERMARKETS.map((_,i)=>setTimeout(()=>setStep(i+1),400+i*280));
    return ()=>ts.forEach(clearTimeout);
  },[]);
  return (
    <div style={{ display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', height:'100%', padding:'20px 28px 80px', background:V3.base }}>
      <div style={{ position:'relative', width:78, height:78, marginBottom:24 }}>
        <svg viewBox="0 0 80 80" width="80" height="80" style={{ position:'absolute', inset:0 }}>
          <circle cx="40" cy="40" r="36" fill="none" stroke={V3.surface3} strokeWidth="5"/>
          <circle cx="40" cy="40" r="36" fill="none" stroke={theme.primary} strokeWidth="5"
            strokeDasharray="226" strokeDashoffset={226*(1-step/D.SUPERMARKETS.length)}
            strokeLinecap="round" style={{ transition:'stroke-dashoffset 0.35s ease', transform:'rotate(-90deg)', transformOrigin:'center' }}/>
        </svg>
        <div style={{ position:'absolute', inset:0, display:'flex', alignItems:'center', justifyContent:'center', fontSize:20 }}>🔍</div>
      </div>
      <h2 style={{ fontSize:19, fontWeight:800, color:V3.ink, letterSpacing:'-0.02em', textAlign:'center', margin:'0 0 5px' }}>A comparar preços…</h2>
      <p style={{ fontSize:13, color:V3.ink3, margin:'0 0 22px', textAlign:'center' }}>{total} produtos · {D.SUPERMARKETS.length} supermercados</p>
      <div style={{ width:'100%', display:'flex', flexDirection:'column', gap:8 }}>
        {D.SUPERMARKETS.map((sm,i)=>(
          <div key={sm.id} style={{ display:'flex', alignItems:'center', gap:12, padding:'9px 14px', borderRadius:12, background:i<step?theme.primaryDim:V3.surface, border:`1px solid ${i<step?theme.primary+'40':V3.border}`, transition:'all 0.3s' }}>
            <V3Badge id={sm.id} size={28}/>
            <span style={{ flex:1, fontSize:13.5, fontWeight:i<step?700:500, color:i<step?V3.ink:V3.ink2 }}>{sm.name}</span>
            <span style={{ fontSize:13, color:i<step?theme.primaryText:V3.ink3 }}>{i<step?'✓':''}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

Object.assign(window, {
  HomeV3, CartV3, AnalyzingV3,
  FREE_LIMIT, FREE_PRODS, MEDIAN_SAVE, PREMIUM_UP,
});
})();
