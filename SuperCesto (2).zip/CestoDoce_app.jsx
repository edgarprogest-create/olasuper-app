// CestoDoce — App principal: estado global, routing, tweaks
(function () {
const { useState, useEffect, useCallback } = React;
const D = window.CestoDoceData;

const STORAGE = {
  PLAN: 'cd_plan_v1',
  USAGE: 'cd_usage_v1',
  CART: 'cd_cart_v1',
};

function loadStorage() {
  try {
    const plan = localStorage.getItem(STORAGE.PLAN) || 'free';
    const usage = parseInt(localStorage.getItem(STORAGE.USAGE) || '0', 10);
    const cart = JSON.parse(localStorage.getItem(STORAGE.CART) || 'null') || D.DEMO_CART;
    return { plan, usage, cart };
  } catch { return { plan: 'free', usage: 0, cart: D.DEMO_CART }; }
}

function App() {
  const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
    "theme": "verde",
    "demo": "free_unused"
  }/*EDITMODE-END*/;
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const theme = CD_THEMES[t.theme] || CD_THEMES.verde;

  // Carregar estado persistido
  const initial = loadStorage();
  // Se o tweak de demo mudou, substituir plan/usage
  function resolveState(demoPref, stored) {
    if (demoPref === 'member')       return { plan: 'member', usageUsed: 3 };
    if (demoPref === 'used_quota')   return { plan: 'free',   usageUsed: 1 };
    if (demoPref === 'free_unused')  return { plan: 'free',   usageUsed: 0 };
    return { plan: stored.plan, usageUsed: stored.usage };
  }
  const resolved = resolveState(t.demo, initial);

  const USAGE_LIMIT = 1;

  const [screen, setScreen]               = useState('home');
  const [cart, setCart]                   = useState(initial.cart);
  const [analysisResult, setAnalysisResult] = useState(null);
  const [plan, setPlan]                   = useState(resolved.plan);
  const [usageUsed, setUsageUsed]         = useState(resolved.usageUsed);
  const [lastSavings, setLastSavings]     = useState(null);
  const [showPaywall, setShowPaywall]     = useState(false);
  const [analysing, setAnalysing]         = useState(false);

  // Sincronizar tweaks de demo com estado
  useEffect(() => {
    const r = resolveState(t.demo, initial);
    setPlan(r.plan);
    setUsageUsed(r.usageUsed);
  }, [t.demo]);

  // Persistir cart
  useEffect(() => {
    try { localStorage.setItem(STORAGE.CART, JSON.stringify(cart)); } catch {}
  }, [cart]);

  const cartCount = cart.reduce((s, i) => s + i.qty, 0);
  const usageLeft = USAGE_LIMIT - usageUsed;
  const canAnalyse = plan === 'member' || usageLeft > 0;

  // ----- Cart actions -----
  const addToCart = useCallback((productId) => {
    setCart(prev => {
      if (prev.find(i => i.productId === productId)) return prev;
      return [...prev, { productId, qty: 1 }];
    });
  }, []);

  const changeQty = useCallback((productId, delta) => {
    setCart(prev => {
      const next = prev.map(i => i.productId === productId ? { ...i, qty: Math.max(0, i.qty + delta) } : i).filter(i => i.qty > 0);
      return next;
    });
  }, []);

  // ----- Analyse -----
  const runAnalysis = useCallback(() => {
    if (cart.length === 0) return;
    if (!canAnalyse) { setShowPaywall(true); return; }

    setAnalysing(true);
    setTimeout(() => {
      const result = D.compareCart(cart);
      setAnalysisResult(result);
      if (result) setLastSavings(result.shouldSplit ? result.savings : 0);
      if (plan === 'free') {
        const newUsage = usageUsed + 1;
        setUsageUsed(newUsage);
        try { localStorage.setItem(STORAGE.USAGE, String(newUsage)); } catch {}
      }
      setAnalysing(false);
      setScreen('analysis');
    }, 600);
  }, [cart, canAnalyse, plan, usageUsed]);

  // ----- Subscribe -----
  const subscribe = useCallback(() => {
    setPlan('member');
    setUsageUsed(0);
    setShowPaywall(false);
    try { localStorage.setItem(STORAGE.PLAN, 'member'); } catch {}
    setTimeout(() => runAnalysis(), 200);
  }, [runAnalysis]);

  // Screen routing
  function renderScreen() {
    switch (screen) {
      case 'home':
        return <HomeScreen theme={theme} onNewCart={() => setScreen('cart')} cartCount={cartCount} />;
      case 'cart':
        return (
          <CartScreen
            theme={theme} cart={cart}
            onChangeQty={changeQty} onAdd={addToCart}
            onAnalyse={runAnalysis}
            plan={plan} usageLeft={usageLeft}
          />
        );
      case 'analysis':
        return (
          <AnalysisScreen
            theme={theme} result={analysisResult}
            onBack={() => setScreen('cart')}
            onGoCart={() => setScreen('cart')}
          />
        );
      case 'profile':
        return (
          <ProfileScreen
            theme={theme} plan={plan}
            usageUsed={usageUsed} usageLimit={USAGE_LIMIT}
            lastSavings={lastSavings}
            onUpgrade={() => setShowPaywall(true)}
          />
        );
      default: return null;
    }
  }

  return (
    <div style={{ fontFamily: "'DM Sans', sans-serif", color: CD.ink, fontSize: 15.5, lineHeight: 1.45 }}>
      {/* Viewport móvel: centrado e com altura fixa em desktop */}
      <div style={{
        position: 'fixed', inset: 0,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        background: 'oklch(92% 0.01 145)',
      }}>
        {/* App shell */}
        <div style={{
          width: '100%', maxWidth: 430, height: '100%', maxHeight: 900,
          background: CD.bg, position: 'relative', overflow: 'hidden',
          boxShadow: '0 8px 48px rgba(10,30,15,0.18)',
          borderRadius: window.innerWidth > 480 ? '36px' : '0',
        }}>
          {/* Conteúdo com scroll */}
          <div style={{ position: 'absolute', inset: 0, bottom: 62, overflowY: 'auto', overflowX: 'hidden' }}>
            {renderScreen()}
          </div>

          {/* Overlay de análise a decorrer */}
          {analysing && (
            <div style={{
              position: 'absolute', inset: 0, zIndex: 150,
              background: 'rgba(255,255,255,0.72)', backdropFilter: 'blur(6px)',
              display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 14,
            }}>
              <div style={{
                width: 48, height: 48, borderRadius: '50%',
                border: `4px solid ${CD.lineSoft}`, borderTopColor: theme.primary,
                animation: 'cdSpin 0.8s linear infinite',
              }}></div>
              <div style={{ fontSize: 15, fontWeight: 700, color: CD.ink }}>A comparar {D.SUPERMARKETS.length} supermercados…</div>
            </div>
          )}

          {/* Paywall */}
          {showPaywall && (
            <PaywallSheet
              theme={theme} lastSavings={lastSavings}
              onSubscribe={subscribe}
              onClose={() => setShowPaywall(false)}
            />
          )}

          {/* Tab bar */}
          <TabBar
            current={screen} onChange={setScreen}
            cartCount={cartCount} theme={theme}
          />
        </div>
      </div>

      {/* Tweaks panel */}
      <TweaksPanel>
        <TweakSection label="Aparência" />
        <TweakRadio
          label="Cor" value={t.theme}
          options={['verde', 'azul', 'laranja']}
          onChange={v => setTweak('theme', v)}
        />
        <TweakSection label="Cenário demo" />
        <TweakSelect
          label="Estado da conta"
          value={t.demo}
          options={[
            { value: 'free_unused', label: 'Gratuito · análise disponível' },
            { value: 'used_quota', label: 'Gratuito · quota usada' },
            { value: 'member', label: 'CestoDoce Member' },
          ]}
          onChange={v => setTweak('demo', v)}
        />
      </TweaksPanel>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
})();
