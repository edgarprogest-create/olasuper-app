// cd_home_v2.jsx — Home (Apple Wallet style), SideMenu, LimitSheet
const { useMemo: useHMemo } = React;

const HOME_PROMOS = { lidl:17, continente:12, pingo:9, intermarche:14 };

function HomeScreen({ cart, plan, monthSaved, onMenu, onAnalyze, onGoCart }) {
  const T = CESTO_STRINGS.pt;
  const cmp = useHMemo(() => cestoCompare(cart), [cart]);
  const cheapest = cmp.cheapest.store;

  return (
    <div className="screen screen-enter" style={{ paddingLeft:0, paddingRight:0 }}>
      {/* header */}
      <div className="home-top">
        <button className="hicon" onClick={onMenu} aria-label="menu">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
            <path d="M4 7h16M4 12h16M4 17h10"/>
          </svg>
        </button>
        <div style={{ flex:1 }}>
          <div className="home-hi">{T.home_greeting}</div>
          <div className="home-brand">CestoDoce</div>
        </div>
        <div className="home-av">SA</div>
      </div>

      <div className="screen__scroll" style={{ paddingLeft:24, paddingRight:24 }}>
        {/* hero: best store */}
        <div className="home-hero">
          <div className="kicker" style={{ marginBottom:8 }}>{T.home_hero_label}</div>
          <div className="home-hero__row">
            <StoreTile store={cheapest} size={48}/>
            <div style={{ flex:1, minWidth:0 }}>
              <div className="home-hero__store">{CESTO_STORES[cheapest].name}</div>
              <div className="home-hero__sub">{T.home_savings}</div>
            </div>
            <div className="home-hero__save mono">
              {cmp.savings > 0 ? '−'+eur(cmp.savings) : '—'}
            </div>
          </div>
        </div>

        {/* swipeable store cards */}
        <div className="home-row">
          <span className="kicker">{T.home_cards_title}</span>
          <span className="home-swipe">{T.home_swipe} →</span>
        </div>
        <div className="wcards">
          {cmp.ranking.map(r => {
            const isWin = r.store === cheapest;
            const save = cmp.expensive.total - r.total;
            const s = CESTO_STORES[r.store];
            return (
              <div key={r.store} className={'wcard'+(isWin?' wcard--win':'')} onClick={onGoCart}>
                <div className="wcard__head">
                  <StoreTile store={r.store} size={38}/>
                  <span className="wcard__name">{s.name}</span>
                  {isWin && <span className="wcard__win-ic" title={T.home_badge}>★</span>}
                </div>
                <div className="wcard__totlabel">{T.home_cart_total}</div>
                <div className="wcard__total mono">{eur(r.total)}</div>
                <div className="wcard__foot">
                  <div className="wcard__sv mono">
                    {save > 0.005 ? '−'+eur(save) : '—'}
                  </div>
                  <div className="wcard__promo">
                    {T.home_promos(HOME_PROMOS[r.store]||0)}
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* stats row */}
        <div className="home-stats">
          <div className="home-stat">
            <div className="home-stat__k">{T.home_month_saved}</div>
            <div className="home-stat__v mono">{eur(monthSaved)}</div>
          </div>
          <div className={'home-stat home-stat--sub'+(plan==='member'?' is-member':'')}>
            <div className="home-stat__k">{plan==='member'?'★ Member':T.menu_plan}</div>
            <div className="home-stat__sub">
              {plan==='member' ? T.home_sub_member : T.home_sub_free}
            </div>
          </div>
        </div>
        <div style={{ height:12 }}/>
      </div>

      <div className="screen__foot">
        <button className="btn btn--member" onClick={onAnalyze}>✨ {T.home_analyze}</button>
        <button className="sb-entry-btn" onClick={onGoCart}>🧺 {T.home_smart}</button>
      </div>
    </div>
  );
}

// ---- side menu ----
function MenuIcon({ name }) {
  const p = { width:19, height:19, viewBox:'0 0 24 24', fill:'none', stroke:'currentColor', strokeWidth:1.8, strokeLinecap:'round', strokeLinejoin:'round' };
  if (name==='person')  return <svg {...p}><circle cx="12" cy="8" r="3.2"/><path d="M5.5 19c0-3.4 2.9-5.6 6.5-5.6s6.5 2.2 6.5 5.6"/></svg>;
  if (name==='clock')   return <svg {...p}><circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/></svg>;
  if (name==='wallet2') return <svg {...p}><rect x="3" y="6" width="18" height="13" rx="2.5"/><path d="M3 10h18"/></svg>;
  if (name==='star')    return <svg {...p}><path d="M12 4l2.3 4.7 5.2.8-3.8 3.6.9 5.1L12 15.8 7.4 18.2l.9-5.1L4.5 9.5l5.2-.8z"/></svg>;
  if (name==='gear')    return <svg {...p}><circle cx="12" cy="12" r="3"/><path d="M12 3v3M12 18v3M3 12h3M18 12h3M5.6 5.6l2.1 2.1M16.3 16.3l2.1 2.1M18.4 5.6l-2.1 2.1M7.7 16.3l-2.1 2.1"/></svg>;
  if (name==='chat')    return <svg {...p}><path d="M5 5h14v10H9l-4 4z"/></svg>;
  return null;
}

function SideMenu({ plan, open, onClose, onNav }) {
  const T = CESTO_STRINGS.pt;
  const items = [
    { id:'profile', label:T.menu_profile,  icon:'person'  },
    { id:'wallet',  label:T.wallet_title,  icon:'wallet2' },
    ...(plan!=='member'?[{ id:'member', label:T.menu_premium, icon:'star' }]:[]),
    { id:'settings',label:T.menu_settings, icon:'gear'    },
    { id:'support', label:T.menu_support,  icon:'chat'    },
  ];
  return (
    <div className={'drawer-scrim'+(open?' is-open':'')} onClick={onClose}>
      <div className="drawer" onClick={e => e.stopPropagation()}>
        <div className="drawer__head">
          <div className="home-av" style={{ width:52, height:52, fontSize:18 }}>SA</div>
          <div>
            <div className="drawer__name">Sofia Almeida</div>
            <div className={'drawer__plan'+(plan==='member'?' is-member':'')}>
              {plan==='member' ? '★ CestoDoce Member' : T.menu_tagline}
            </div>
          </div>
        </div>
        <div className="drawer__items">
          {items.map(i => (
            <button key={i.id}
              className={'drawer-item'+(i.id==='member'?' drawer-item--gold':'')}
              onClick={() => { onNav(i.id); onClose(); }}>
              <span className="drawer-item__ic"><MenuIcon name={i.icon}/></span>
              <span className="drawer-item__lb">{i.label}</span>
              <span className="drawer-item__ch">›</span>
            </button>
          ))}
        </div>
        <div className="drawer__foot">CestoDoce · v2.0</div>
      </div>
    </div>
  );
}

// ---- free limit sheet ----
function LimitSheet({ onUpgrade, onClose }) {
  const T = CESTO_STRINGS.pt;
  return (
    <div className="paywall-scrim" onClick={onClose}>
      <div className="limit anim-up" onClick={e => e.stopPropagation()}>
        <div className="paywall__grip"/>
        <div className="limit__ic">🔒</div>
        <div className="limit__title">{T.limit_title}</div>
        <p className="limit__body">{T.limit_body(T.limit_date)}</p>
        <button className="btn btn--member" style={{ marginTop:16 }} onClick={onUpgrade}>
          ★ {T.limit_cta}
        </button>
        <button className="btn btn--ghost" style={{ width:'100%', marginTop:4 }} onClick={onClose}>
          {T.limit_close}
        </button>
      </div>
    </div>
  );
}

Object.assign(window, { HomeScreen, SideMenu, LimitSheet, MenuIcon });
