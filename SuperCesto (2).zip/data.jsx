// data.jsx — content for the Cesto prototype (PT primary / EN secondary)

const CESTO_STRINGS = {
  pt: {
    welcome_kicker: "O seu assistente de compras",
    welcome_title: "Vamos otimizar\no seu Cesto.",
    welcome_body: "3 perguntas rápidas. Depois lemos os folhetos por si e encontramos o plano mais barato desta semana.",
    welcome_cta: "Começar",
    welcome_meta: "Continente · Pingo Doce · Lidl · Intermarché",

    step_of: (a, b) => `Pergunta ${a} de ${b}`,
    back: "Voltar",
    next: "Continuar",
    finish: "Otimizar o meu Cesto",

    q1_title: "O seu plano de compras",
    q1_sub: "Usamos isto para prever quando vai precisar de reabastecer.",
    q1_options: [
      { id: "semanal", label: "Semanal", hint: "Compro todas as semanas" },
      { id: "quinzenal", label: "Quinzenal", hint: "De 15 em 15 dias" },
      { id: "mensal", label: "Mensal", hint: "Uma grande compra por mês" },
    ],

    q2_title: "Em que dia costuma fazer compras?",
    q2_sub: "Ativamos alertas de folhetos e sugerimos o melhor dia.",
    q2_options: [
      { id: "seg", label: "Segunda", short: "S" },
      { id: "ter", label: "Terça", short: "T" },
      { id: "qua", label: "Quarta", short: "Q" },
      { id: "qui", label: "Quinta", short: "Q" },
      { id: "sex", label: "Sexta", short: "S" },
      { id: "sab", label: "Sábado", short: "S" },
      { id: "dom", label: "Domingo", short: "D" },
    ],

    q3_title: "Que categorias quer otimizar primeiro?",
    q3_sub: "Escolha as que mais pesam no seu cesto. Pode escolher várias.",
    q3_selected: (n) => `${n} selecionada${n === 1 ? "" : "s"}`,
    q3_min: "Escolha pelo menos uma",

    analyzing_title: "A otimizar o seu Cesto…",
    analyzing_steps: [
      "A ler os folhetos desta semana",
      "A reconhecer produtos e preços",
      "A normalizar nomes e quantidades",
      "A calcular o preço por unidade",
      "A comparar os supermercados",
    ],

    result_kicker: "O seu Cesto otimizado · esta semana",
    result_title: "Encontrámos o melhor\nplano para si.",
    result_savings_label: "Poupança estimada",
    result_vs: "vs. compra habitual num só sítio",
    result_plan_title: "O plano por loja",
    result_insight_title: "Vale a pena dividir?",
    result_insight_body: "Comprar nas 3 lojas poupa 18,40 €. Só no Lidl, a poupança cai para 9,10 € — mas evita 2 deslocações.",
    result_insight_a: "Ver plano em 1 só loja",
    result_insight_b: "Manter plano em 3 lojas",
    result_cta: "Ver lista de compras",
    result_share: "Partilhar poupança",
    best_day_label: "Melhor dia para comprar",
    best_day_value: "Quinta-feira",
    best_day_hint: "Folhetos novos entram quarta à noite",

    list_title: "A sua lista",
    list_sub: "Organizada por loja para uma volta rápida.",
    list_total: "Total estimado",
    list_done: "Concluído",
  },

  en: {
    welcome_kicker: "Your shopping assistant",
    welcome_title: "Let's optimize\nyour Basket.",
    welcome_body: "3 quick questions. Then we read the weekly flyers for you and find the cheapest plan this week.",
    welcome_cta: "Get started",
    welcome_meta: "Continente · Pingo Doce · Lidl · Intermarché",

    step_of: (a, b) => `Question ${a} of ${b}`,
    back: "Back",
    next: "Continue",
    finish: "Optimize my Basket",

    q1_title: "Your shopping plan",
    q1_sub: "We use this to predict when you'll need to restock.",
    q1_options: [
      { id: "semanal", label: "Weekly", hint: "I shop every week" },
      { id: "quinzenal", label: "Fortnightly", hint: "Every two weeks" },
      { id: "mensal", label: "Monthly", hint: "One big shop a month" },
    ],

    q2_title: "Which day do you usually shop?",
    q2_sub: "We turn on flyer alerts and suggest the best day.",
    q2_options: [
      { id: "seg", label: "Monday", short: "M" },
      { id: "ter", label: "Tuesday", short: "T" },
      { id: "qua", label: "Wednesday", short: "W" },
      { id: "qui", label: "Thursday", short: "T" },
      { id: "sex", label: "Friday", short: "F" },
      { id: "sab", label: "Saturday", short: "S" },
      { id: "dom", label: "Sunday", short: "S" },
    ],

    q3_title: "Which categories to optimize first?",
    q3_sub: "Pick the ones that weigh most in your basket. Choose several.",
    q3_selected: (n) => `${n} selected`,
    q3_min: "Pick at least one",

    analyzing_title: "Optimizing your Basket…",
    analyzing_steps: [
      "Reading this week's flyers",
      "Recognizing products and prices",
      "Normalizing names and quantities",
      "Calculating price per unit",
      "Comparing the supermarkets",
    ],

    result_kicker: "Your optimized Basket · this week",
    result_title: "We found the best\nplan for you.",
    result_savings_label: "Estimated savings",
    result_vs: "vs. a usual one-stop shop",
    result_plan_title: "The plan by store",
    result_insight_title: "Worth splitting up?",
    result_insight_body: "Shopping all 3 stores saves €18.40. Lidl only drops it to €9.10 — but saves you 2 trips.",
    result_insight_a: "See 1-store plan",
    result_insight_b: "Keep 3-store plan",
    result_cta: "See shopping list",
    result_share: "Share savings",
    best_day_label: "Best day to shop",
    best_day_value: "Thursday",
    best_day_hint: "New flyers land Wednesday night",

    list_title: "Your list",
    list_sub: "Sorted by store for a quick run.",
    list_total: "Estimated total",
    list_done: "Done",
  },
};

// Categories — id, PT label, EN label, simple glyph (we avoid drawing complex icons)
const CESTO_CATEGORIES = [
  { id: "enlatados", pt: "Enlatados", en: "Canned goods", glyph: "🥫" },
  { id: "bebidas", pt: "Bebidas", en: "Drinks", glyph: "🧃" },
  { id: "cuidados", pt: "Cuidados pessoais", en: "Personal care", glyph: "🧴" },
  { id: "talho", pt: "Talho / Carne", en: "Butcher / Meat", glyph: "🥩" },
  { id: "peixe", pt: "Peixe", en: "Fish", glyph: "🐟" },
  { id: "laticinios", pt: "Laticínios", en: "Dairy", glyph: "🧀" },
  { id: "congelados", pt: "Congelados", en: "Frozen", glyph: "🧊" },
  { id: "limpeza", pt: "Limpeza doméstica", en: "Cleaning", glyph: "🧽" },
  { id: "snacks", pt: "Snacks", en: "Snacks", glyph: "🍫" },
  { id: "basicos", pt: "Produtos básicos", en: "Pantry basics", glyph: "🍝" },
];

// Stores — generic placeholder tiles (NOT real logos). Distinct hues for recognition.
const CESTO_STORES = {
  lidl: { id: "lidl", name: "Lidl", mark: "L", hue: 222 },
  continente: { id: "continente", name: "Continente", mark: "C", hue: 8 },
  pingo: { id: "pingo", name: "Pingo Doce", mark: "PD", hue: 142 },
  intermarche: { id: "intermarche", name: "Intermarché", mark: "I", hue: 28 },
};

// The optimized result — store assignments with PT/EN tags and prices
const CESTO_RESULT = {
  savings: 18.40,
  total: 71.60,
  usual: 90.00,
  plan: [
    {
      store: "lidl",
      tagPt: "Snacks + básicos",
      tagEn: "Snacks + basics",
      price: 26.30,
      items: 9,
      rank: 1,
    },
    {
      store: "continente",
      tagPt: "Higiene e limpeza",
      tagEn: "Hygiene & cleaning",
      price: 24.10,
      items: 7,
      rank: 2,
    },
    {
      store: "intermarche",
      tagPt: "Carne em promoção",
      tagEn: "Meat on sale",
      price: 21.20,
      items: 4,
      rank: 3,
    },
  ],
  // a small slice of the per-store list for the list screen
  list: {
    lidl: [
      { pt: "Bolachas integrais", en: "Wholegrain biscuits", price: 1.29 },
      { pt: "Arroz agulha 1kg", en: "Long-grain rice 1kg", price: 0.99 },
      { pt: "Massa esparguete 500g", en: "Spaghetti 500g", price: 0.69 },
      { pt: "Frutos secos 200g", en: "Mixed nuts 200g", price: 2.49 },
    ],
    continente: [
      { pt: "Detergente roupa 2L", en: "Laundry detergent 2L", price: 4.99 },
      { pt: "Gel de banho 750ml", en: "Shower gel 750ml", price: 2.19 },
      { pt: "Papel higiénico 12un", en: "Toilet paper 12pk", price: 3.89 },
    ],
    intermarche: [
      { pt: "Peito de frango 1kg", en: "Chicken breast 1kg", price: 5.49 },
      { pt: "Bife do lombo 500g", en: "Sirloin steak 500g", price: 6.90 },
    ],
  },
};

Object.assign(window, { CESTO_STRINGS, CESTO_CATEGORIES, CESTO_STORES, CESTO_RESULT });
