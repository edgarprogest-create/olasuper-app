// CestoDoce_analysis_v3.jsx — Análise + Scanner de Ingredientes (Premium) + Perfil + Paywall
(function(){
const { useState, useEffect, useMemo, useRef } = React;
const D  = window.CestoDoceData;
const D3 = window.CestoDoceDataV3;

// ============ ANALYSIS v3 ============
function AnalysisV3({ theme, result, plan, onBack, onGoCart, onUpgrade }) {
  const [anim, setAnim] = useState(false);
  useEffect(()=>{ const t=setTimeout(()=>setAnim(true),80); return()=>clearTimeout(t); },[]);
  const [animVal, setAnimVal] = useState(0);
  useEffect(()=>{
    if(!anim||!result) return;
    const target = result.shouldSplit?result.savings:0;
    let raf, start;
    const tick=t=>{
      if(!start)start=t;
      const p=Math.min(1,(t-start)/1100);
      setAnimVal(target*(1-Math.pow(1-p,3)));
      if(p<1)raf=requestAnimationFrame(tick); else setAnimVal(target);
    };
    raf=requestAnimationFrame(tick);
    return()=>cancelAnimationFrame(raf);
  },[anim,result]);

  if(!result) return (
    <div data-screen-label="Análise — vazio" style={{ paddingTop:54 }}>
      <V3Header title="Análise"/>
      <div style={{ textAlign:'center', padding:'60px 32px', color:V3.ink3 }}>
        <div style={{ fontSize:40, marginBottom:14 }}>🧭</div>
        <p style={{ fontSize:14, lineHeight:1.55, margin:'0 0 18px' }}>Ainda sem análises.<br/>Cria um carrinho primeiro.</p>
        <V3GhostBtn onClick={onGoCart} style={{ maxWidth:240, margin:'0 auto' }}>Ir para o carrinho</V3GhostBtn>
      </div>
    </div>
  );

  const r = result;
  const split = r.shouldSplit;
  const freePriceIds = D.PRODUCTS.slice(0,FREE_LIMIT).map(p=>p.id);
  const freeCart  = r._cart?r._cart.filter(i=>freePriceIds.includes(i.productId)):null;
  const freeResult= plan!=='member'&&freeCart?D.compareCart(freeCart):null;
  const extra     = freeResult&&r.savings>freeResult.savings?r.savings-freeResult.savings:0;

  return (
    <div data-screen-label="Análise — resultado" style={{ paddingTop:54, height:'100%', display:'flex', flexDirection:'column' }}>
      <V3Header title="Resultado" subtitle={`${r.totalItems} artigos · ${D.SUPERMARKETS.length} lojas`} onBack={onBack}/>
      <div style={{ flex:1, overflowY:'auto', padding:'4px 20px 120px' }}>

        {/* hero savings */}
        <div style={{ borderRadius:20, padding:'24px 20px 20px', marginBottom:12, position:'relative', overflow:'hidden',
          background:`linear-gradient(135deg, ${V3.surface2} 0%, ${V3.surface3} 100%)`,
          border:`1px solid ${split?theme.primary+'50':V3.borderBright}`,
          boxShadow: split?`0 0 32px ${theme.primaryGlow}`:'none' }}>
          <div style={{ position:'absolute', top:-40, right:-40, width:160, height:160, borderRadius:'50%', background:theme.primaryDim, pointerEvents:'none' }}/>
          <div style={{ position:'relative' }}>
            {split?(
              <>
                <V3Pill color={theme.primaryText} dim={theme.primaryDim} style={{marginBottom:12}}>
                  <SparkIco size={12} color={theme.primaryText}/> Divisão recomendada
                </V3Pill>
                <div style={{ fontSize:12.5, color:V3.ink3, marginBottom:2 }}>Dividindo em {r.splitGroups.length} lojas, poupas</div>
                <div style={{ fontSize:54, fontWeight:800, color:theme.primaryText, letterSpacing:'-0.04em', lineHeight:1.05, marginBottom:4, fontVariantNumeric:'tabular-nums' }}>
                  {animVal.toFixed(2).replace('.',',')} €
                </div>
                <div style={{ fontSize:13, color:V3.ink3 }}>−{String(r.savingsPct).replace('.',',')}% vs {r.bestSingle.name} ({euro(r.singleTotal)})</div>
              </>
            ):(
              <>
                <V3Pill color={theme.primaryText} dim={theme.primaryDim} style={{marginBottom:12}}>
                  <CheckIco size={12} color={theme.primaryText}/> Uma loja basta
                </V3Pill>
                <div style={{ fontSize:13.5, color:V3.ink3, marginBottom:4 }}>Compra tudo em</div>
                <div style={{ fontSize:32, fontWeight:800, color:V3.ink, letterSpacing:'-0.03em', marginBottom:4 }}>{r.bestSingle.name}</div>
                <div style={{ fontSize:14, color:V3.ink3 }}>Total: <strong style={{color:V3.ink}}>{euro(r.singleTotal)}</strong></div>
              </>
            )}
          </div>
        </div>

        {/* member upsell */}
        {plan!=='member'&&extra>0.5&&(
          <div onClick={onUpgrade} style={{ cursor:'pointer', marginBottom:12, padding:'12px 14px', background:V3.memberDim, borderRadius:14, display:'flex', alignItems:'center', gap:12, border:`1px solid ${V3.member}40` }}>
            <CrownIco size={22} color={V3.member}/>
            <div style={{ flex:1 }}>
              <div style={{ fontSize:13.5, fontWeight:800, color:V3.member }}>Com Member, pouparias +{euro(extra)}</div>
              <div style={{ fontSize:12, color:V3.ink3, marginTop:1 }}>Catálogo completo → mais oportunidades</div>
            </div>
            <span style={{ color:V3.member, fontWeight:800 }}>↗</span>
          </div>
        )}

        {/* split groups */}
        <div style={{ display:'flex', flexDirection:'column', gap:10, marginBottom:12 }}>
          {(split?r.splitGroups:[{supermarket:r.bestSingle,items:null,subtotal:r.singleTotal}]).map(g=>(
            <V3Card key={g.supermarket.id} style={{ padding:0, overflow:'hidden' }}>
              <div style={{ display:'flex', alignItems:'center', gap:12, padding:'13px 16px', borderBottom:`1px solid ${V3.border}` }}>
                <V3Badge id={g.supermarket.id} size={34}/>
                <div style={{ flex:1 }}>
                  <div style={{ fontSize:15, fontWeight:800, color:V3.ink }}>{g.supermarket.name}</div>
                  {g.items&&<div style={{ fontSize:11.5, color:V3.ink3 }}>{g.items.reduce((s,i)=>s+i.qty,0)} artigos</div>}
                </div>
                <div style={{ fontSize:16, fontWeight:800, color:V3.ink, fontVariantNumeric:'tabular-nums' }}>{euro(g.subtotal)}</div>
              </div>
              {g.items&&(
                <div style={{ padding:'6px 16px 10px' }}>
                  {g.items.map(it=>(
                    <div key={it.productId} style={{ display:'flex', alignItems:'center', gap:8, padding:'6px 0', fontSize:13 }}>
                      <span style={{ color:V3.ink, flex:1, display:'flex', gap:6, alignItems:'center', flexWrap:'wrap' }}>
                        {it.product.name}{it.qty>1?` ×${it.qty}`:''}
                        {it.isPromo&&<V3Pill color={V3.promo} dim={V3.promoDim} style={{fontSize:10}}>promo</V3Pill>}
                      </span>
                      <span style={{ color:V3.ink3, fontWeight:600, fontVariantNumeric:'tabular-nums' }}>{euro(it.unitPrice*it.qty)}</span>
                    </div>
                  ))}
                </div>
              )}
            </V3Card>
          ))}
        </div>

        {/* full ranking */}
        <V3Card style={{ padding:'14px 16px' }}>
          <div style={{ fontSize:11, fontWeight:700, color:V3.ink3, textTransform:'uppercase', letterSpacing:'0.07em', marginBottom:10 }}>Ranking loja única</div>
          <div style={{ display:'flex', flexDirection:'column', gap:8 }}>
            {r.allTotals.map((t,i)=>(
              <div key={t.supermarket.id} style={{ display:'flex', alignItems:'center', gap:10, fontSize:13 }}>
                <V3Badge id={t.supermarket.id} size={22}/>
                <span style={{ flex:1, color:i===0?V3.ink:V3.ink2, fontWeight:i===0?700:500 }}>{t.supermarket.name}</span>
                {i===0&&<V3Pill color={theme.primaryText} dim={theme.primaryDim} style={{fontSize:10}}>mais barato</V3Pill>}
                <span style={{ fontWeight:600, color:i===0?V3.ink:V3.ink3, fontVariantNumeric:'tabular-nums' }}>{euro(t.total)}</span>
              </div>
            ))}
          </div>
        </V3Card>
      </div>
    </div>
  );
}

// ============ SCANNER v3 (Premium) ============
const NOVA_COLORS = { 1:'#00C875', 2:'#7BC67E', 3:'#FFB830', 4:'#FF4D4D' };
const NOVA_LABELS = { 1:'Mínimo processado', 2:'Ingrediente culinário', 3:'Processado', 4:'Ultra-processado' };
const NS_COLORS   = { A:'#038141', B:'#85BB2F', C:'#FECB02', D:'#EE8100', E:'#E63E11' };
const RISK_CONFIG = {
  alto:  { color:V3.red,   dim:V3.redDim,   label:'Risco alto',  icon:'🔴' },
  medio: { color:V3.amber, dim:V3.amberDim, label:'Atenção',     icon:'🟡' },
  baixo: { color:V3.mint,  dim:V3.mintDim,  label:'Baixo risco', icon:'🟢' },
};

function ScannerV3({ theme, plan, onUpgrade }) {
  const [phase, setPhase]     = useState('idle'); // idle | scanning | result | manual
  const [scanIdx, setScanIdx] = useState(0);
  const [report,  setReport]  = useState(null);
  const [manualInput, setManualInput] = useState('');
  const timerRef = useRef(null);

  function startScan() {
    if(plan!=='member'){ onUpgrade(); return; }
    setPhase('scanning');
    let prog=0;
    const tick=()=>{
      prog++;
      setScanIdx(prog);
      if(prog<18) timerRef.current=setTimeout(tick,80);
      else finishScan();
    };
    timerRef.current=setTimeout(tick,80);
  }

  function finishScan() {
    const prod = D3.getScanDemo();
    const r    = D3.analyseIngredients(prod);
    setReport(r);
    setPhase('result');
  }

  function reset() { setPhase('idle'); setReport(null); setScanIdx(0); clearTimeout(timerRef.current); }

  function doManual(e) {
    e.preventDefault();
    if(!manualInput.trim()) return;
    if(plan!=='member'){ onUpgrade(); return; }
    const dummy = D3.SCAN_DEMO_PRODUCTS.find(p=>p.additives.length>0)||D3.SCAN_DEMO_PRODUCTS[0];
    const r = D3.analyseIngredients(dummy);
    setReport(r); setPhase('result'); setManualInput('');
  }

  const DEMOS = D3.SCAN_DEMO_PRODUCTS;

  return (
    <div data-screen-label="Scanner de Ingredientes" style={{ paddingTop:54, height:'100%', display:'flex', flexDirection:'column' }}>
      <V3Header title="Scanner" subtitle={plan==='member'?'Analisa ingredientes de qualquer produto':'Funcionalidade Premium'} right={
        plan!=='member'&&<V3Pill color={V3.member} dim={V3.memberDim}><CrownIco size={11} color={V3.member}/> Premium</V3Pill>
      }/>
      <div style={{ flex:1, overflowY:'auto', padding:'6px 20px 100px' }}>

        {/* IDLE */}
        {phase==='idle'&&(
          <div>
            {/* camera viewfinder */}
            <div style={{ position:'relative', borderRadius:20, overflow:'hidden', marginBottom:14, background:V3.surface2, border:`1px solid ${V3.border}` }}>
              <div style={{ height:220, display:'flex', alignItems:'center', justifyContent:'center', flexDirection:'column', gap:14 }}>
                {/* fake viewfinder */}
                <div style={{ width:180, height:140, border:`2px solid ${plan==='member'?theme.primary:V3.surface3}`, borderRadius:14, position:'relative' }}>
                  {['tl','tr','bl','br'].map(c=>{
                    const s={position:'absolute',width:16,height:16,borderColor:plan==='member'?theme.primary:V3.ink3,borderStyle:'solid'};
                    if(c==='tl')s.cssText='top:-2px;left:-2px;border-width:3px 0 0 3px;border-radius:4px 0 0 0';
                    return null;
                  })}
                  {/* corner brackets */}
                  {[{top:-2,left:-2,btop:3,bleft:3,bbt:0,bbr:0},{top:-2,right:-2,btop:3,bright:3,bbt:0,bbl:0},{bottom:-2,left:-2,bbot:3,bleft:3,bbt:0,bbr:0},{bottom:-2,right:-2,bbot:3,bright:3,bbt:0,bbl:0}].map((_,i)=>(
                    <div key={i} style={{ position:'absolute',
                      ...(i===0?{top:0,left:0,borderTop:`3px solid ${plan==='member'?theme.primary:V3.ink3}`,borderLeft:`3px solid ${plan==='member'?theme.primary:V3.ink3}`,borderRadius:'4px 0 0 0'}:{}),
                      ...(i===1?{top:0,right:0,borderTop:`3px solid ${plan==='member'?theme.primary:V3.ink3}`,borderRight:`3px solid ${plan==='member'?theme.primary:V3.ink3}`,borderRadius:'0 4px 0 0'}:{}),
                      ...(i===2?{bottom:0,left:0,borderBottom:`3px solid ${plan==='member'?theme.primary:V3.ink3}`,borderLeft:`3px solid ${plan==='member'?theme.primary:V3.ink3}`,borderRadius:'0 0 0 4px'}:{}),
                      ...(i===3?{bottom:0,right:0,borderBottom:`3px solid ${plan==='member'?theme.primary:V3.ink3}`,borderRight:`3px solid ${plan==='member'?theme.primary:V3.ink3}`,borderRadius:'0 0 4px 0'}:{}),
                      width:16,height:16
                    }}/>
                  ))}
                  <div style={{ position:'absolute', inset:0, display:'flex', alignItems:'center', justifyContent:'center', flexDirection:'column', gap:6 }}>
                    <span style={{ fontSize:26, opacity:plan==='member'?1:0.4 }}>📦</span>
                    <span style={{ fontSize:11, color:plan==='member'?V3.ink3:V3.surface3, fontWeight:600 }}>
                      {plan==='member'?'Aponta para a embalagem':'Bloqueado'}
                    </span>
                  </div>
                </div>
                <div style={{ fontSize:12, color:V3.ink3, fontWeight:600 }}>
                  {plan==='member'?'Aponta a câmara para a lista de ingredientes':'Upgrade para usar o scanner'}
                </div>
              </div>
              {plan!=='member'&&(
                <div style={{ position:'absolute', inset:0, background:'rgba(11,14,19,0.65)', display:'flex', alignItems:'center', justifyContent:'center' }}>
                  <div style={{ textAlign:'center', padding:24 }}>
                    <CrownIco size={32} color={V3.member}/>
                    <div style={{ fontSize:14.5, fontWeight:800, color:V3.ink, marginTop:8, marginBottom:4 }}>Funcionalidade Premium</div>
                    <div style={{ fontSize:12.5, color:V3.ink3, marginBottom:12 }}>Scanner de ingredientes disponível no CestoDoce Member</div>
                    <button onClick={onUpgrade} style={{ height:38, padding:'0 20px', borderRadius:10, border:'none', background:theme.primary, color:'#000', fontSize:13, fontWeight:800, fontFamily:'inherit', cursor:'pointer' }}>
                      Aderir · 1€/mês
                    </button>
                  </div>
                </div>
              )}
            </div>

            {plan==='member'&&(
              <V3Btn theme={theme} onClick={startScan} style={{ marginBottom:12 }}>
                <CameraIco size={18} color="#000"/> Iniciar scan
              </V3Btn>
            )}

            {/* manual entry */}
            <V3Card style={{ padding:'14px 16px', marginBottom:14 }}>
              <div style={{ fontSize:12, fontWeight:700, color:V3.ink3, textTransform:'uppercase', letterSpacing:'0.07em', marginBottom:10 }}>✏ Inserir ingredientes manualmente</div>
              <form onSubmit={doManual}>
                <textarea value={manualInput} onChange={e=>setManualInput(e.target.value)}
                  placeholder="Cola o texto da lista de ingredientes aqui…"
                  style={{ width:'100%', minHeight:80, background:V3.surface2, border:`1px solid ${V3.border}`, borderRadius:10, padding:'10px 12px', color:V3.ink, fontSize:13.5, fontFamily:'inherit', resize:'vertical', outline:'none', lineHeight:1.5 }}/>
                <button type="submit" style={{ marginTop:8, width:'100%', height:40, borderRadius:10, border:'none', background:plan==='member'?theme.primary:V3.surface3, color:plan==='member'?'#000':V3.ink3, fontSize:13.5, fontWeight:800, fontFamily:'inherit', cursor:plan==='member'?'pointer':'default' }}>
                  {plan==='member'?'Analisar ingredientes':'★ Função Premium'}
                </button>
              </form>
            </V3Card>

            {/* demo products */}
            <div style={{ fontSize:12, fontWeight:700, color:V3.ink3, textTransform:'uppercase', letterSpacing:'0.07em', marginBottom:8 }}>Produtos Demo</div>
            <div style={{ display:'flex', flexDirection:'column', gap:8 }}>
              {DEMOS.map(p=>{
                const rc = p.additives.length===0?{color:V3.mint,dim:V3.mintDim,label:'Sem aditivos'}:p.additives.some(a=>D3.ADDITIVES_DB[a]?.risk==='alto')?RISK_CONFIG.alto:RISK_CONFIG.medio;
                return (
                  <V3Card key={p.id} style={{ padding:'12px 14px', display:'flex', alignItems:'center', gap:12, cursor:'pointer' }}
                    onClick={()=>{ if(plan!=='member'){onUpgrade();return;} const r=D3.analyseIngredients(p); setReport(r); setPhase('result'); }}>
                    <div style={{ flex:1, minWidth:0 }}>
                      <div style={{ fontSize:13.5, fontWeight:700, color:V3.ink }}>{p.name}</div>
                      <div style={{ fontSize:11.5, color:V3.ink3, marginTop:1 }}>{p.brand} · {p.store}</div>
                    </div>
                    <div style={{ display:'flex', alignItems:'center', gap:6 }}>
                      {p.nutriscore&&<div style={{ width:22, height:22, borderRadius:6, background:NS_COLORS[p.nutriscore]||V3.surface3, display:'flex', alignItems:'center', justifyContent:'center', fontSize:11, fontWeight:800, color:'#fff' }}>{p.nutriscore}</div>}
                      <V3Pill color={rc.color} dim={rc.dim} style={{fontSize:10}}>{rc.label}</V3Pill>
                    </div>
                  </V3Card>
                );
              })}
            </div>
          </div>
        )}

        {/* SCANNING */}
        {phase==='scanning'&&(
          <div style={{ textAlign:'center', padding:'48px 0 40px' }}>
            <div style={{ width:100, height:100, margin:'0 auto 20px', position:'relative' }}>
              <div style={{ position:'absolute', inset:0, borderRadius:24, border:`3px solid ${theme.primary}`, opacity:0.3, animation:'cdPulse 1.2s ease infinite' }}/>
              <div style={{ position:'absolute', inset:8, borderRadius:18, background:V3.surface2, display:'flex', alignItems:'center', justifyContent:'center', fontSize:34 }}>📦</div>
              <div style={{ position:'absolute', left:0, right:0, top:`${(scanIdx%18)/18*88}%`, height:2, background:theme.primary, boxShadow:`0 0 8px ${theme.primaryGlow}`, transition:'top 0.08s linear' }}/>
            </div>
            <h3 style={{ fontSize:17, fontWeight:800, color:V3.ink, margin:'0 0 6px' }}>A ler ingredientes…</h3>
            <p style={{ fontSize:13, color:V3.ink3 }}>OCR a processar · a identificar aditivos</p>
          </div>
        )}

        {/* RESULT */}
        {phase==='result'&&report&&(
          <div>
            {/* verdict banner */}
            {(()=>{
              const v = report.verdict==='alerta'
                ? { color:V3.red,   dim:V3.redDim,   icon:'🔴', text:'Contém aditivos de risco alto' }
                : report.verdict==='atencao'
                  ? { color:V3.amber, dim:V3.amberDim, icon:'🟡', text:'Requer atenção' }
                  : { color:V3.mint,  dim:V3.mintDim,  icon:'🟢', text:'Perfil de aditivos aceitável' };
              return (
                <div style={{ padding:'14px 16px', borderRadius:16, background:v.dim, border:`1px solid ${v.color}40`, marginBottom:12, display:'flex', alignItems:'center', gap:12 }}>
                  <span style={{ fontSize:24 }}>{v.icon}</span>
                  <div>
                    <div style={{ fontSize:15, fontWeight:800, color:v.color }}>{v.text}</div>
                    <div style={{ fontSize:12.5, color:V3.ink3, marginTop:2 }}>{report.product.name}</div>
                  </div>
                </div>
              );
            })()}

            {/* nutricion row */}
            <div style={{ display:'flex', gap:8, marginBottom:12 }}>
              {report.product.nutriscore&&(
                <V3Card style={{ flex:1, padding:'12px 14px', textAlign:'center' }}>
                  <div style={{ fontSize:11, color:V3.ink3, marginBottom:6 }}>Nutri-Score</div>
                  <div style={{ width:36, height:36, borderRadius:10, background:NS_COLORS[report.product.nutriscore]||V3.surface3, display:'flex', alignItems:'center', justifyContent:'center', fontSize:18, fontWeight:800, color:'#fff', margin:'0 auto' }}>{report.product.nutriscore}</div>
                </V3Card>
              )}
              {report.product.nova&&(
                <V3Card style={{ flex:1, padding:'12px 14px', textAlign:'center' }}>
                  <div style={{ fontSize:11, color:V3.ink3, marginBottom:6 }}>NOVA</div>
                  <div style={{ width:36, height:36, borderRadius:10, background:NOVA_COLORS[report.product.nova]||V3.surface3, display:'flex', alignItems:'center', justifyContent:'center', fontSize:18, fontWeight:800, color:'#fff', margin:'0 auto' }}>{report.product.nova}</div>
                  <div style={{ fontSize:9.5, color:V3.ink3, marginTop:4, lineHeight:1.3 }}>{NOVA_LABELS[report.product.nova]}</div>
                </V3Card>
              )}
              <V3Card style={{ flex:1, padding:'12px 14px', textAlign:'center' }}>
                <div style={{ fontSize:11, color:V3.ink3, marginBottom:6 }}>Calorias</div>
                <div style={{ fontSize:18, fontWeight:800, color:V3.ink, fontVariantNumeric:'tabular-nums' }}>{report.product.kcal}</div>
                <div style={{ fontSize:10, color:V3.ink3, marginTop:2 }}>kcal/100g</div>
              </V3Card>
            </div>

            {/* additives */}
            {report.additives.length>0?(
              <V3Card style={{ padding:'14px 16px', marginBottom:12 }}>
                <div style={{ fontSize:12, fontWeight:700, color:V3.ink3, textTransform:'uppercase', letterSpacing:'0.07em', marginBottom:10 }}>
                  {report.additives.length} Aditivo{report.additives.length>1?'s':''} detetado{report.additives.length>1?'s':''}
                </div>
                <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
                  {report.additives.map(a=>{
                    const rc = RISK_CONFIG[a.risk]||RISK_CONFIG.baixo;
                    return (
                      <div key={a.code} style={{ display:'flex', gap:12, padding:'10px 12px', background:rc.dim, borderRadius:12, border:`1px solid ${rc.color}30` }}>
                        <div style={{ flexShrink:0 }}>
                          <div style={{ fontSize:13, fontWeight:800, color:rc.color }}>{a.code}</div>
                          <V3Pill color={rc.color} dim='transparent' style={{fontSize:9,marginTop:3,padding:'1px 6px',border:`1px solid ${rc.color}60`}}>{rc.label}</V3Pill>
                        </div>
                        <div style={{ flex:1, minWidth:0 }}>
                          <div style={{ fontSize:13.5, fontWeight:700, color:V3.ink, marginBottom:2 }}>{a.name}</div>
                          <div style={{ fontSize:11, color:V3.ink3, lineHeight:1.45, textTransform:'capitalize' }}>{a.type}</div>
                          <div style={{ fontSize:12, color:V3.ink2, lineHeight:1.45, marginTop:4 }}>{a.note}</div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </V3Card>
            ):(
              <V3Card style={{ padding:'16px', textAlign:'center', marginBottom:12 }}>
                <div style={{ fontSize:22, marginBottom:6 }}>✅</div>
                <div style={{ fontSize:14.5, fontWeight:700, color:V3.mint }}>Sem aditivos detetados</div>
                <div style={{ fontSize:12.5, color:V3.ink3, marginTop:4 }}>Este produto não contém aditivos artificiais.</div>
              </V3Card>
            )}

            {/* ingredients raw */}
            <V3Card style={{ padding:'14px 16px', marginBottom:12 }}>
              <div style={{ fontSize:12, fontWeight:700, color:V3.ink3, textTransform:'uppercase', letterSpacing:'0.07em', marginBottom:8 }}>Ingredientes</div>
              <p style={{ fontSize:12.5, color:V3.ink2, lineHeight:1.6, margin:0 }}>{report.product.ingredients}</p>
            </V3Card>

            {report.product.allergens&&report.product.allergens.length>0&&(
              <V3Card style={{ padding:'14px 16px', marginBottom:12 }}>
                <div style={{ fontSize:12, fontWeight:700, color:V3.ink3, textTransform:'uppercase', letterSpacing:'0.07em', marginBottom:8 }}>⚠ Alergénios</div>
                <div style={{ display:'flex', gap:6, flexWrap:'wrap' }}>
                  {report.product.allergens.map(a=>(
                    <V3Pill key={a} color={V3.amber} dim={V3.amberDim}>{a}</V3Pill>
                  ))}
                </div>
              </V3Card>
            )}

            <V3GhostBtn onClick={reset}>← Novo scan</V3GhostBtn>
          </div>
        )}
      </div>
    </div>
  );
}

// ============ PROFILE v3 ============
function ProfileV3({ theme, plan, usageUsed, usageLimit, lastSavings, onUpgrade }) {
  const isMember = plan==='member';
  return (
    <div data-screen-label="Perfil" style={{ paddingTop:54, height:'100%', display:'flex', flexDirection:'column' }}>
      <V3Header title="Perfil"/>
      <div style={{ flex:1, overflowY:'auto', padding:'4px 20px 110px', display:'flex', flexDirection:'column', gap:10 }}>
        <V3Card style={{ display:'flex', alignItems:'center', gap:14, padding:'16px' }}>
          <div style={{ width:50, height:50, borderRadius:'50%', background:theme.primaryDim, border:`1px solid ${theme.primary}50`, display:'flex', alignItems:'center', justifyContent:'center', fontSize:18, fontWeight:800, color:theme.primaryText }}>M</div>
          <div style={{ flex:1 }}>
            <div style={{ fontSize:16, fontWeight:800, color:V3.ink }}>Maria Santos</div>
            <div style={{ fontSize:12.5, color:V3.ink3 }}>maria.santos@email.pt</div>
          </div>
          {isMember
            ?<V3Pill color={V3.member} dim={V3.memberDim}><CrownIco size={11} color={V3.member}/> Member</V3Pill>
            :<V3Pill color={V3.ink3} dim={V3.surface3}>Grátis</V3Pill>}
        </V3Card>

        <V3Card style={{ padding:'14px 16px' }}>
          <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:10 }}>
            <span style={{ fontSize:14, fontWeight:700, color:V3.ink }}>Análises este mês</span>
            <span style={{ fontSize:13, fontWeight:700, color:V3.ink3, fontVariantNumeric:'tabular-nums' }}>
              {isMember?`${usageUsed} · ilimitadas`:`${usageUsed} / ${usageLimit}`}
            </span>
          </div>
          <div style={{ height:6, borderRadius:100, background:V3.surface3, overflow:'hidden' }}>
            <div style={{ height:'100%', borderRadius:100, background:theme.primary, width:isMember?'100%':`${Math.min(usageUsed/usageLimit,1)*100}%`, opacity:isMember?0.35:1, transition:'width 0.4s' }}/>
          </div>
          <p style={{ margin:'8px 0 0', fontSize:12, color:V3.ink3 }}>
            {isMember?`${D.PRODUCTS.length} produtos · análises ilimitadas`:`${FREE_LIMIT}/${D.PRODUCTS.length} produtos. Renova a 1 de julho.`}
          </p>
        </V3Card>

        {lastSavings!=null&&lastSavings>0&&(
          <V3Card style={{ padding:'14px 16px', background:theme.primaryDim, border:`1px solid ${theme.primary}40` }}>
            <div style={{ display:'flex', alignItems:'center', gap:12 }}>
              <WalletIco size={24} color={theme.primaryText}/>
              <div>
                <div style={{ fontSize:13, color:V3.ink3 }}>Poupança na última análise</div>
                <div style={{ fontSize:21, fontWeight:800, color:theme.primaryText, letterSpacing:'-0.02em' }}>{euro(lastSavings)}</div>
              </div>
            </div>
          </V3Card>
        )}

        {!isMember&&(
          <V3Card style={{ padding:'16px' }}>
            <V3Pill color={V3.member} dim={V3.memberDim} style={{marginBottom:12}}><CrownIco size={11} color={V3.member}/> CestoDoce Member</V3Pill>
            <h3 style={{ margin:'0 0 10px', fontSize:16, fontWeight:800, color:V3.ink, letterSpacing:'-0.015em' }}>Catálogo completo + scanner</h3>
            <ul style={{ margin:'0 0 14px', padding:0, listStyle:'none', display:'flex', flexDirection:'column', gap:7 }}>
              {[`${D.PRODUCTS.length} produtos (vs ${FREE_LIMIT} no grátis)`,'Análises ilimitadas','Scanner de ingredientes','Alertas de promoções'].map(b=>(
                <li key={b} style={{ display:'flex', alignItems:'center', gap:9, fontSize:13.5, color:V3.ink2 }}>
                  <CheckIco size={14} color={theme.primaryText}/> {b}
                </li>
              ))}
            </ul>
            <V3Btn theme={theme} onClick={onUpgrade}>Aderir · 1 €/mês</V3Btn>
          </V3Card>
        )}
      </div>
    </div>
  );
}

// ============ PAYWALL v3 ============
function PaywallV3({ theme, lastSavings, simBudget=120, onSubscribe, onClose }) {
  const [step, setStep] = useState('offer');
  const freeSave  = Math.round(simBudget*MEDIAN_SAVE*100)/100;
  const premSave  = Math.round(simBudget*MEDIAN_SAVE*PREMIUM_UP*100)/100;
  const uplift    = Math.round((premSave-freeSave)*100)/100;
  function pay(){ setStep('paying'); setTimeout(()=>{setStep('success');setTimeout(onSubscribe,1200);},1400); }
  return (
    <div style={{ position:'absolute', inset:0, zIndex:200, background:'rgba(5,7,9,0.7)', display:'flex', alignItems:'flex-end', animation:'cdFadeIn 0.2s ease' }}
      onClick={step==='offer'?onClose:undefined}>
      <div onClick={e=>e.stopPropagation()} style={{ width:'100%', background:V3.surface, borderRadius:'24px 24px 0 0', border:`1px solid ${V3.borderBright}`, padding:'10px 22px calc(max(env(safe-area-inset-bottom),10px) + 12px)', animation:'cdSlideUp 0.32s cubic-bezier(0.32,0.72,0,1)', maxHeight:'92%', overflowY:'auto' }}>
        <div style={{ width:38, height:4, borderRadius:100, background:V3.surface3, margin:'0 auto 16px' }}/>

        {step==='offer'&&(<>
          <V3Pill color={V3.member} dim={V3.memberDim} style={{marginBottom:12}}><CrownIco size={11} color={V3.member}/> CestoDoce Member</V3Pill>
          <h2 style={{ margin:'0 0 6px', fontSize:21, fontWeight:800, color:V3.ink, letterSpacing:'-0.025em', lineHeight:1.2 }}>Mais poupança, catálogo completo, scanner</h2>
          <p style={{ margin:'0 0 14px', fontSize:13.5, color:V3.ink3, lineHeight:1.5 }}>Por menos do que um café por mês.</p>

          <div style={{ background:V3.surface2, borderRadius:14, padding:'14px 16px', marginBottom:14, border:`1px solid ${V3.border}` }}>
            <p style={{ margin:'0 0 8px', fontSize:11, fontWeight:700, color:V3.ink3, textTransform:'uppercase', letterSpacing:'0.07em' }}>Impacto com {simBudget}€/mês</p>
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:8 }}>
              <div>
                <div style={{ fontSize:10, color:V3.ink3 }}>Plano Grátis</div>
                <div style={{ fontSize:19, fontWeight:800, color:V3.ink, fontVariantNumeric:'tabular-nums' }}>{euro(freeSave)}</div>
              </div>
              <div>
                <div style={{ fontSize:10, color:theme.primaryText, fontWeight:700 }}>★ Member</div>
                <div style={{ fontSize:19, fontWeight:800, color:theme.primaryText, fontVariantNumeric:'tabular-nums' }}>{euro(premSave)}</div>
              </div>
            </div>
            <div style={{ marginTop:8, paddingTop:8, borderTop:`1px solid ${V3.border}`, fontSize:12.5, color:V3.ink2 }}>
              <strong style={{color:theme.primaryText}}>+{euro(uplift)}/mês</strong> extra — subscrição paga-se em dias
            </div>
          </div>

          <ul style={{ margin:'0 0 14px', padding:0, listStyle:'none', display:'flex', flexDirection:'column', gap:7 }}>
            {[`${D.PRODUCTS.length} produtos analisados (vs ${FREE_LIMIT})`,'Análises ilimitadas','Scanner de ingredientes IA','Alertas semanais de promoções'].map(b=>(
              <li key={b} style={{ display:'flex', alignItems:'center', gap:9, fontSize:13.5, color:V3.ink2 }}>
                <CheckIco size={14} color={theme.primaryText}/> {b}
              </li>
            ))}
          </ul>

          <div style={{ textAlign:'center', marginBottom:12 }}>
            <span style={{ fontSize:34, fontWeight:800, color:V3.ink, letterSpacing:'-0.03em' }}>1 €</span>
            <span style={{ fontSize:14, color:V3.ink3, fontWeight:600 }}> / mês</span>
          </div>

          <div style={{ display:'flex', flexDirection:'column', gap:8 }}>
            <button onClick={pay} style={{ height:52, borderRadius:14, border:'none', background:'#000', color:'#fff', fontSize:16, fontWeight:700, fontFamily:'inherit', cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center', gap:7 }}>
              <svg width="16" height="19" viewBox="0 0 17 20" fill="#fff"><path d="M13.9 10.6c0-2.4 2-3.6 2.1-3.6-1.1-1.7-2.9-1.9-3.5-1.9-1.5-.2-2.9.9-3.7.9-.8 0-1.9-.9-3.2-.8C4 5.2 2.5 6.1 1.7 7.6c-1.7 3-.4 7.4 1.2 9.8.8 1.2 1.7 2.5 3 2.4 1.2 0 1.7-.8 3.1-.8 1.5 0 1.9.8 3.2.8 1.3 0 2.1-1.2 2.9-2.4.9-1.4 1.3-2.7 1.3-2.8 0 0-2.5-1-2.5-4zM11.5 3.4c.7-.8 1.1-1.9 1-3.1-1 0-2.2.7-2.9 1.5-.6.7-1.2 1.9-1 3 1.1.1 2.2-.6 2.9-1.4z"/></svg>
              Pay
            </button>
            <button onClick={pay} style={{ height:52, borderRadius:14, border:`1px solid ${V3.borderBright}`, background:'transparent', color:V3.ink, fontSize:15, fontWeight:700, fontFamily:'inherit', cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center', gap:8 }}>
              <span style={{ fontWeight:800 }}><span style={{color:'#4285F4'}}>G</span><span style={{color:'#EA4335'}}>o</span><span style={{color:'#FBBC04'}}>o</span><span style={{color:'#4285F4'}}>g</span><span style={{color:'#34A853'}}>l</span><span style={{color:'#EA4335'}}>e</span></span> Pay
            </button>
            <button onClick={pay} style={{ height:44, borderRadius:12, border:'none', background:'transparent', color:V3.ink3, fontSize:14, fontWeight:600, fontFamily:'inherit', cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center', gap:7 }}>
              <WalletIco size={16} color={V3.ink3}/> Pagar com cartão
            </button>
          </div>
          <p style={{ textAlign:'center', fontSize:11, color:V3.ink3, margin:'10px 0 0', lineHeight:1.5 }}>Pagamento dentro da app · Cancela quando quiseres</p>
        </>)}

        {step==='paying'&&(
          <div style={{ textAlign:'center', padding:'44px 0 52px' }}>
            <div style={{ width:50, height:50, margin:'0 auto 16px', borderRadius:'50%', border:`4px solid ${V3.surface3}`, borderTopColor:theme.primary, animation:'cdSpin 0.8s linear infinite' }}/>
            <div style={{ fontSize:15, fontWeight:700, color:V3.ink }}>A processar…</div>
            <div style={{ fontSize:12.5, color:V3.ink3, marginTop:5 }}>1,00 € · CestoDoce Member</div>
          </div>
        )}
        {step==='success'&&(
          <div style={{ textAlign:'center', padding:'44px 0 52px' }}>
            <div style={{ width:58, height:58, margin:'0 auto 14px', borderRadius:'50%', background:theme.primaryDim, border:`2px solid ${theme.primary}60`, display:'flex', alignItems:'center', justifyContent:'center', animation:'cdPop 0.4s cubic-bezier(0.34,1.56,0.64,1)' }}>
              <CheckIco size={28} color={theme.primaryText}/>
            </div>
            <div style={{ fontSize:19, fontWeight:800, color:V3.ink, letterSpacing:'-0.02em' }}>Bem-vinda, Member!</div>
            <div style={{ fontSize:13, color:V3.ink3, marginTop:5 }}>Catálogo completo + scanner ativados.</div>
          </div>
        )}
      </div>
    </div>
  );
}

Object.assign(window, { AnalysisV3, ScannerV3, ProfileV3, PaywallV3 });
})();
