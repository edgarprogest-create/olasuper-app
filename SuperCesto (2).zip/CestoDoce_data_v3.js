// CestoDoce_data_v3.js — Folhetos semanais + dados de ingredientes
window.CestoDoceDataV3 = (function () {

  // ---- Folhetos: destaques semanais por categoria e loja ----
  // Formato real: produto específico em promoção, com foto placeholder
  const FLYERS = [
    // FRESCOS
    {
      id: 'fl_tomate_pingo',
      category: 'frescos',
      store: 'pingodoce',
      product: 'Tomate Rama',
      detail: '1 kg',
      normalPrice: 1.99,
      promoPrice: 0.59,
      savingPct: 70,
      validUntil: '14 jun',
      emoji: '🍅',
      highlight: true,
    },
    {
      id: 'fl_alface_pingo',
      category: 'frescos',
      store: 'pingodoce',
      product: 'Alface Iceberg',
      detail: 'unid.',
      normalPrice: 0.99,
      promoPrice: 0.29,
      savingPct: 71,
      validUntil: '14 jun',
      emoji: '🥬',
      highlight: false,
    },
    {
      id: 'fl_laranja_pingo',
      category: 'frescos',
      store: 'pingodoce',
      product: 'Laranjas Valencia',
      detail: '1 kg',
      normalPrice: 1.99,
      promoPrice: 0.59,
      savingPct: 70,
      validUntil: '14 jun',
      emoji: '🍊',
      highlight: false,
    },
    {
      id: 'fl_banana_aldi',
      category: 'frescos',
      store: 'aldi',
      product: 'Bananas Cavendish',
      detail: '1 kg',
      normalPrice: 1.49,
      promoPrice: 0.79,
      savingPct: 47,
      validUntil: '15 jun',
      emoji: '🍌',
      highlight: false,
    },

    // CARNES E PEIXE
    {
      id: 'fl_frango_pingo',
      category: 'carnes',
      store: 'pingodoce',
      product: 'Frango do Campo Inteiro',
      detail: 'unid. ≈1,2 kg',
      normalPrice: 3.29,
      promoPrice: 1.49,
      savingPct: 55,
      validUntil: '14 jun',
      emoji: '🍗',
      highlight: true,
    },
    {
      id: 'fl_picada_lidl',
      category: 'carnes',
      store: 'lidl',
      product: 'Carne Picada de Novilho',
      detail: '500 g',
      normalPrice: 3.99,
      promoPrice: 2.49,
      savingPct: 38,
      validUntil: '15 jun',
      emoji: '🥩',
      highlight: false,
    },
    {
      id: 'fl_salmao_inter',
      category: 'carnes',
      store: 'intermarche',
      product: 'Salmão Fumado',
      detail: '100 g',
      normalPrice: 3.49,
      promoPrice: 1.99,
      savingPct: 43,
      validUntil: '13 jun',
      emoji: '🐟',
      highlight: false,
    },
    {
      id: 'fl_asa_frango_aldi',
      category: 'carnes',
      store: 'aldi',
      product: 'Asas de Frango',
      detail: '1 kg',
      normalPrice: 3.99,
      promoPrice: 2.29,
      savingPct: 43,
      validUntil: '15 jun',
      emoji: '🍗',
      highlight: false,
    },

    // LATICÍNIOS
    {
      id: 'fl_iogurte_lidl',
      category: 'laticinios',
      store: 'lidl',
      product: 'Iogurte Grego Natural',
      detail: 'pack 4 × 150 g',
      normalPrice: 2.29,
      promoPrice: 1.19,
      savingPct: 48,
      validUntil: '15 jun',
      emoji: '🥛',
      highlight: true,
    },
    {
      id: 'fl_manteiga_aldi',
      category: 'laticinios',
      store: 'aldi',
      product: 'Manteiga sem Sal',
      detail: '250 g',
      normalPrice: 2.99,
      promoPrice: 1.59,
      savingPct: 47,
      validUntil: '15 jun',
      emoji: '🧈',
      highlight: false,
    },

    // CONGELADOS
    {
      id: 'fl_pizza_lidl',
      category: 'congelados',
      store: 'lidl',
      product: 'Pizza Ristorante Mozzarella',
      detail: '355 g',
      normalPrice: 4.99,
      promoPrice: 2.49,
      savingPct: 50,
      validUntil: '15 jun',
      emoji: '🍕',
      highlight: true,
    },
    {
      id: 'fl_gelado_cont',
      category: 'congelados',
      store: 'continente',
      product: 'Gelado Magnum Classic',
      detail: '4 unid.',
      normalPrice: 5.99,
      promoPrice: 3.49,
      savingPct: 42,
      validUntil: '14 jun',
      emoji: '🍦',
      highlight: false,
    },

    // HIGIENE
    {
      id: 'fl_dove_cont',
      category: 'higiene',
      store: 'continente',
      product: 'Dove Shower Gel',
      detail: '500 ml',
      normalPrice: 3.99,
      promoPrice: 1.99,
      savingPct: 50,
      validUntil: '14 jun',
      emoji: '🧴',
      highlight: true,
    },
    {
      id: 'fl_detersivo_aldi',
      category: 'higiene',
      store: 'aldi',
      product: 'Detergente Roupa Liq.',
      detail: '30 doses',
      normalPrice: 8.99,
      promoPrice: 4.79,
      savingPct: 47,
      validUntil: '15 jun',
      emoji: '🧺',
      highlight: false,
    },

    // BEBIDAS
    {
      id: 'fl_agua_merc',
      category: 'bebidas',
      store: 'mercadona',
      product: 'Água Hacendado 1,5 L',
      detail: 'pack 6',
      normalPrice: 2.49,
      promoPrice: 1.39,
      savingPct: 44,
      validUntil: '14 jun',
      emoji: '💧',
      highlight: true,
    },
    {
      id: 'fl_sumo_pingo',
      category: 'bebidas',
      store: 'pingodoce',
      product: 'Compal Frutos Tropicais',
      detail: '1 L',
      normalPrice: 2.49,
      promoPrice: 1.19,
      savingPct: 52,
      validUntil: '14 jun',
      emoji: '🧃',
      highlight: false,
    },
  ];

  // ---- Base de dados de ingredientes / aditivos ----
  // Simulação de scan de produto: biblioteca de aditivos classificados
  const ADDITIVES_DB = {
    'E102': { name:'Tartrazina', type:'corante', risk:'alto',   note:'Associado a hiperatividade em crianças. Proibido em vários países.' },
    'E110': { name:'Amarelo Sunset', type:'corante', risk:'alto', note:'Pode causar reações alérgicas. Proibido no Japão.' },
    'E120': { name:'Carmim / Cochonilha', type:'corante', risk:'medio', note:'Origem animal. Pode causar reações em alérgicos.' },
    'E122': { name:'Carmoisina', type:'corante', risk:'alto', note:'Pode causar hiperatividade. Proibido nos EUA.' },
    'E124': { name:'Ponceau 4R', type:'corante', risk:'alto', note:'Pode causar hiperatividade. Proibido nos EUA e Noruega.' },
    'E129': { name:'Vermelho Allura', type:'corante', risk:'medio', note:'Associado a hiperatividade. Desaconselhado para crianças.' },
    'E211': { name:'Benzoato de sódio', type:'conservante', risk:'alto', note:'Combinado com vitamina C, pode formar benzeno (cancerígeno).' },
    'E220': { name:'Dióxido de enxofre', type:'conservante', risk:'medio', note:'Pode causar asma e alergias. Limite diário recomendado.' },
    'E250': { name:'Nitrito de sódio', type:'conservante', risk:'alto', note:'Presente em carnes processadas. Potencialmente cancerígeno em excesso.' },
    'E320': { name:'BHA', type:'antioxidante', risk:'medio', note:'Suspeita de ser carcinogénico. Limitado em vários países.' },
    'E621': { name:'Glutamato monossódico', type:'realcador', risk:'medio', note:'Pode causar dores de cabeça em pessoas sensíveis (síndrome MSG).' },
    'E951': { name:'Aspartame', type:'adocante', risk:'medio', note:'Contraindicado em fenilcetonúria. Em revisão pela EFSA.' },
    'E954': { name:'Sacarina', type:'adocante', risk:'medio', note:'Associado a perturbações intestinais em doses elevadas.' },
    'E407': { name:'Carragenina', type:'espessante', risk:'medio', note:'Pode causar inflamação intestinal. Em revisão pela UE.' },
    'E415': { name:'Goma xantana', type:'espessante', risk:'baixo', note:'Geralmente seguro. Pode ter efeito laxante em doses altas.' },
    'E471': { name:'Mono e diglicéridos', type:'emulsionante', risk:'baixo', note:'Habitualmente seguros. Podem ser de origem animal.' },
    'E450': { name:'Difosfatos', type:'fosfato', risk:'medio', note:'Excesso pode afetar ossos e rins. Comum em produtos processados.' },
  };

  // Produtos demo para o scanner (simulação)
  const SCAN_DEMO_PRODUCTS = [
    {
      id: 'scan_bolachas',
      name: 'Bolachas Maria Recheadas',
      brand: 'Marca Branca',
      store: 'lidl',
      barcode: '5601234567890',
      nutriscore: 'D',
      ingredients: 'Farinha de trigo, açúcar, óleo de palma, xarope de glucose-frutose, sal, E211, E102, E320, lecitina de soja, aroma natural de baunilha.',
      additives: ['E211','E102','E320'],
      allergens: ['glúten','soja'],
      nova: 4,
      kcal: 487,
    },
    {
      id: 'scan_fiambre',
      name: 'Fiambre Extra Fatiado',
      brand: 'Marca Premium',
      store: 'continente',
      barcode: '5609876543210',
      nutriscore: 'C',
      ingredients: 'Carne de porco (92%), água, amido, sal, proteína de soja, antioxidante: E301; conservante: E250; realçador de sabor: E621.',
      additives: ['E250','E621','E301'],
      allergens: ['soja'],
      nova: 3,
      kcal: 112,
    },
    {
      id: 'scan_refrigerante',
      name: 'Refrigerante Cola Zero',
      brand: 'Marca Branca',
      store: 'aldi',
      barcode: '5601111222333',
      nutriscore: 'B',
      ingredients: 'Água carbonatada, corante E150d, acidificante E338, aromas naturais, edulcorantes: E951 e E954.',
      additives: ['E951','E954','E150d','E338'],
      allergens: [],
      nova: 4,
      kcal: 1,
    },
    {
      id: 'scan_iogurte',
      name: 'Iogurte Natural Integral',
      brand: 'Continente Orgânico',
      store: 'continente',
      barcode: '5601234000001',
      nutriscore: 'A',
      ingredients: 'Leite gordo pasteurizado, fermentos lácticos.',
      additives: [],
      allergens: ['leite'],
      nova: 1,
      kcal: 68,
    },
    {
      id: 'scan_molho',
      name: 'Ketchup Clássico',
      brand: 'Marca Branca',
      store: 'pingodoce',
      barcode: '5605678901234',
      nutriscore: 'C',
      ingredients: 'Tomate (72%), açúcar, vinagre, sal, especiarias, conservante E211, estabilizador E415, E621.',
      additives: ['E211','E415','E621'],
      allergens: [],
      nova: 4,
      kcal: 101,
    },
  ];

  function getFlyers(category) {
    if (category) return FLYERS.filter(f => f.category === category);
    return FLYERS;
  }

  function getFlyerHighlights() {
    // top highlight per category
    return FLYERS.filter(f => f.highlight);
  }

  function getScanDemo() {
    return SCAN_DEMO_PRODUCTS[Math.floor(Math.random() * SCAN_DEMO_PRODUCTS.length)];
  }

  function analyseIngredients(product) {
    if (!product) return null;
    const found = product.additives.map(code => ({
      code,
      ...(ADDITIVES_DB[code] || { name: code, type: 'desconhecido', risk: 'desconhecido', note: 'Sem dados disponíveis.' })
    }));
    const highRisk  = found.filter(a => a.risk === 'alto');
    const medRisk   = found.filter(a => a.risk === 'medio');
    const lowRisk   = found.filter(a => a.risk === 'baixo');
    const verdict =
      highRisk.length > 0  ? 'alerta' :
      medRisk.length  > 1  ? 'atencao' : 'ok';
    return { product, additives: found, highRisk, medRisk, lowRisk, verdict };
  }

  return { FLYERS, ADDITIVES_DB, SCAN_DEMO_PRODUCTS, getFlyers, getFlyerHighlights, getScanDemo, analyseIngredients };
})();
