// CestoDoce — Dados de demonstração (preços fictícios, semana de 8–14 jun 2026)
window.CestoDoceData = (function () {
  const SUPERMARKETS = [
    { id: 'continente', name: 'Continente', short: 'Cont.' },
    { id: 'pingodoce', name: 'Pingo Doce', short: 'P. Doce' },
    { id: 'lidl', name: 'Lidl', short: 'Lidl' },
    { id: 'aldi', name: 'Aldi', short: 'Aldi' },
    { id: 'mercadona', name: 'Mercadona', short: 'Merc.' },
    { id: 'intermarche', name: 'Intermarché', short: 'Inter.' },
  ];

  const CATEGORIES = [
    { id: 'carnes', name: 'Carnes & Peixe' },
    { id: 'frescos', name: 'Frescos' },
    { id: 'laticinios', name: 'Laticínios' },
    { id: 'bebidas', name: 'Bebidas' },
    { id: 'higiene', name: 'Higiene & Limpeza' },
    { id: 'congelados', name: 'Congelados' },
  ];

  // promo: { supermercadoId: true } => preço promocional desta semana
  const PRODUCTS = [
    // CARNES & PEIXE
    { id: 'frango_inteiro', name: 'Frango Inteiro', unit: 'unid.', category: 'carnes',
      prices: { continente: 3.29, pingodoce: 1.49, lidl: 2.59, aldi: 2.79, mercadona: 2.99, intermarche: 3.19 },
      promo: { pingodoce: true } },
    { id: 'carne_picada', name: 'Carne Picada 500g', unit: 'emb.', category: 'carnes',
      prices: { continente: 3.99, pingodoce: 3.79, lidl: 3.29, aldi: 3.19, mercadona: 3.49, intermarche: 3.89 } },
    { id: 'peito_frango', name: 'Peito de Frango 500g', unit: 'emb.', category: 'carnes',
      prices: { continente: 4.99, pingodoce: 4.79, lidl: 3.99, aldi: 3.89, mercadona: 4.29, intermarche: 4.69 } },
    { id: 'costeletas_porco', name: 'Costeletas de Porco kg', unit: 'kg', category: 'carnes',
      prices: { continente: 5.49, pingodoce: 5.29, lidl: 4.79, aldi: 4.59, mercadona: 5.09, intermarche: 5.39 } },
    { id: 'pescada', name: 'Pescada Congelada 700g', unit: 'emb.', category: 'carnes',
      prices: { continente: 4.49, pingodoce: 4.29, lidl: 3.59, aldi: 3.49, mercadona: 3.99, intermarche: 4.29 } },

    // FRESCOS
    { id: 'tomates', name: 'Tomates 1kg', unit: 'kg', category: 'frescos',
      prices: { continente: 1.99, pingodoce: 0.59, lidl: 1.49, aldi: 1.59, mercadona: 1.69, intermarche: 1.89 },
      promo: { pingodoce: true } },
    { id: 'alface', name: 'Alface', unit: 'unid.', category: 'frescos',
      prices: { continente: 0.99, pingodoce: 0.29, lidl: 0.79, aldi: 0.79, mercadona: 0.89, intermarche: 0.95 },
      promo: { pingodoce: true } },
    { id: 'cebolas', name: 'Cebolas 1kg', unit: 'kg', category: 'frescos',
      prices: { continente: 1.29, pingodoce: 1.19, lidl: 0.99, aldi: 0.89, mercadona: 1.09, intermarche: 1.19 } },
    { id: 'bananas', name: 'Bananas 1kg', unit: 'kg', category: 'frescos',
      prices: { continente: 1.49, pingodoce: 1.39, lidl: 1.09, aldi: 0.99, mercadona: 1.19, intermarche: 1.35 } },
    { id: 'macas', name: 'Maçãs Fuji 1kg', unit: 'kg', category: 'frescos',
      prices: { continente: 2.49, pingodoce: 2.29, lidl: 1.99, aldi: 1.89, mercadona: 2.19, intermarche: 2.39 } },
    { id: 'laranjas', name: 'Laranjas 1kg', unit: 'kg', category: 'frescos',
      prices: { continente: 1.99, pingodoce: 0.59, lidl: 1.39, aldi: 1.29, mercadona: 1.59, intermarche: 1.79 },
      promo: { pingodoce: true } },

    // LATICÍNIOS
    { id: 'leite_uht', name: 'Leite UHT 1L', unit: 'unid.', category: 'laticinios',
      prices: { continente: 1.09, pingodoce: 1.05, lidl: 0.85, aldi: 0.82, mercadona: 0.95, intermarche: 1.00 } },
    { id: 'iogurte_natural', name: 'Iogurte Natural pack 4', unit: 'pack', category: 'laticinios',
      prices: { continente: 1.89, pingodoce: 1.69, lidl: 1.39, aldi: 1.35, mercadona: 1.59, intermarche: 1.79 } },
    { id: 'manteiga', name: 'Manteiga 250g', unit: 'emb.', category: 'laticinios',
      prices: { continente: 2.99, pingodoce: 2.79, lidl: 2.39, aldi: 2.29, mercadona: 2.59, intermarche: 2.89 } },
    { id: 'queijo_flamengo', name: 'Queijo Flamengo 400g', unit: 'emb.', category: 'laticinios',
      prices: { continente: 3.49, pingodoce: 3.29, lidl: 2.79, aldi: 2.69, mercadona: 3.09, intermarche: 3.39 } },
    { id: 'queijo_fresco', name: 'Queijo Fresco 250g', unit: 'emb.', category: 'laticinios',
      prices: { continente: 1.59, pingodoce: 1.49, lidl: 1.29, aldi: 1.19, mercadona: 1.39, intermarche: 1.49 } },

    // BEBIDAS
    { id: 'agua_6pack', name: 'Água 1.5L pack 6', unit: 'pack', category: 'bebidas',
      prices: { continente: 2.49, pingodoce: 2.29, lidl: 1.99, aldi: 1.89, mercadona: 2.09, intermarche: 2.39 } },
    { id: 'sumo_laranja', name: 'Sumo de Laranja 1L', unit: 'unid.', category: 'bebidas',
      prices: { continente: 2.49, pingodoce: 2.19, lidl: 1.89, aldi: 1.79, mercadona: 2.09, intermarche: 2.29 } },
    { id: 'cerveja_6pack', name: 'Cerveja pack 6×33cl', unit: 'pack', category: 'bebidas',
      prices: { continente: 4.99, pingodoce: 4.79, lidl: 3.99, aldi: 3.89, mercadona: 4.29, intermarche: 4.69 } },
    { id: 'cola_2l', name: 'Cola 2L', unit: 'unid.', category: 'bebidas',
      prices: { continente: 1.99, pingodoce: 1.89, lidl: 1.49, aldi: 1.49, mercadona: 1.69, intermarche: 1.89 } },

    // HIGIENE & LIMPEZA
    { id: 'champo', name: 'Champô 400ml', unit: 'unid.', category: 'higiene',
      prices: { continente: 3.99, pingodoce: 3.79, lidl: 2.99, aldi: 2.89, mercadona: 3.29, intermarche: 3.69 } },
    { id: 'gel_banho', name: 'Gel de Banho 500ml', unit: 'unid.', category: 'higiene',
      prices: { continente: 2.99, pingodoce: 2.79, lidl: 1.99, aldi: 1.89, mercadona: 2.29, intermarche: 2.69 } },
    { id: 'pasta_dentes', name: 'Pasta Dentífrica 75ml', unit: 'unid.', category: 'higiene',
      prices: { continente: 2.49, pingodoce: 2.29, lidl: 1.79, aldi: 1.69, mercadona: 1.99, intermarche: 2.29 } },
    { id: 'detergente_roupa', name: 'Detergente Roupa 30 doses', unit: 'unid.', category: 'higiene',
      prices: { continente: 8.99, pingodoce: 8.49, lidl: 6.99, aldi: 6.79, mercadona: 7.49, intermarche: 8.29 } },
    { id: 'papel_higienico', name: 'Papel Higiénico 12 rolos', unit: 'pack', category: 'higiene',
      prices: { continente: 4.99, pingodoce: 4.79, lidl: 3.99, aldi: 3.79, mercadona: 4.29, intermarche: 4.69 } },

    // CONGELADOS
    { id: 'ervilhas', name: 'Ervilhas Congeladas 1kg', unit: 'emb.', category: 'congelados',
      prices: { continente: 1.99, pingodoce: 1.89, lidl: 1.49, aldi: 1.39, mercadona: 1.69, intermarche: 1.89 } },
    { id: 'batata_frita_cong', name: 'Batatas Fritas Congeladas 1kg', unit: 'emb.', category: 'congelados',
      prices: { continente: 2.49, pingodoce: 2.29, lidl: 1.79, aldi: 1.69, mercadona: 2.09, intermarche: 2.39 } },
    { id: 'pizza_congelada', name: 'Pizza Congelada', unit: 'unid.', category: 'congelados',
      prices: { continente: 4.99, pingodoce: 4.79, lidl: 3.49, aldi: 3.29, mercadona: 3.99, intermarche: 4.59 } },
    { id: 'gelado_baunilha', name: 'Gelado Baunilha 1L', unit: 'unid.', category: 'congelados',
      prices: { continente: 3.99, pingodoce: 3.79, lidl: 2.79, aldi: 2.59, mercadona: 3.29, intermarche: 3.69 } },
    { id: 'frutos_vermelhos', name: 'Frutos Vermelhos 500g', unit: 'emb.', category: 'congelados',
      prices: { continente: 3.49, pingodoce: 3.29, lidl: 2.59, aldi: 2.49, mercadona: 2.99, intermarche: 3.19 } },
  ];

  // Tendência semanal (demo): -1 desceu de preço, 0 igual, 1 subiu
  const WEEKLY_TRENDS = {
    carnes: { pingodoce: -1, mercadona: 1 },
    frescos: { pingodoce: -1, intermarche: 1 },
    laticinios: { aldi: -1, continente: 1 },
    bebidas: {},
    higiene: { aldi: -1 },
    congelados: { lidl: 1 },
  };

  function round2(n) { return Math.round(n * 100) / 100; }

  function getWeeklyRanking() {
    return CATEGORIES.map(cat => {
      const catProducts = PRODUCTS.filter(p => p.category === cat.id);
      const ranking = SUPERMARKETS.map(sm => {
        const avg = catProducts.reduce((s, p) => s + (p.prices[sm.id] || 0), 0) / catProducts.length;
        const promoCount = catProducts.filter(p => p.promo && p.promo[sm.id]).length;
        return { supermarket: sm, avg: round2(avg), trend: (WEEKLY_TRENDS[cat.id] || {})[sm.id] || 0, promoCount };
      }).sort((a, b) => a.avg - b.avg);
      return { category: cat, ranking };
    });
  }

  // Comparação: melhor loja única vs divisão inteligente (máx. 2 lojas)
  function compareCart(cartItems) {
    if (!cartItems || cartItems.length === 0) return null;

    const totals = {};
    SUPERMARKETS.forEach(sm => {
      totals[sm.id] = cartItems.reduce((sum, item) => {
        const p = PRODUCTS.find(x => x.id === item.productId);
        return p ? sum + p.prices[sm.id] * item.qty : sum;
      }, 0);
    });

    const sortedSingles = SUPERMARKETS.slice().sort((a, b) => totals[a.id] - totals[b.id]);
    const bestSingle = sortedSingles[0];
    const worstSingle = sortedSingles[sortedSingles.length - 1];

    // ótimo por item
    const itemOptimal = cartItems.map(item => {
      const product = PRODUCTS.find(x => x.id === item.productId);
      if (!product) return null;
      const cheapest = SUPERMARKETS.reduce((best, sm) =>
        product.prices[sm.id] < product.prices[best.id] ? sm : best);
      return {
        productId: item.productId, qty: item.qty, product,
        supermarket: cheapest,
        unitPrice: product.prices[cheapest.id],
        isPromo: !!(product.promo && product.promo[cheapest.id]),
      };
    }).filter(Boolean);

    // agrupar por loja
    const map = {};
    itemOptimal.forEach(it => {
      const sid = it.supermarket.id;
      if (!map[sid]) map[sid] = { supermarket: it.supermarket, items: [], subtotal: 0 };
      map[sid].items.push(it);
      map[sid].subtotal += it.unitPrice * it.qty;
    });
    let groups = Object.values(map).sort((a, b) => b.subtotal - a.subtotal);

    // limitar a 2 lojas (praticidade) — redistribui itens das restantes
    if (groups.length > 2) {
      const top2 = groups.slice(0, 2);
      groups.slice(2).forEach(g => {
        g.items.forEach(it => {
          const target = top2.reduce((best, tg) =>
            it.product.prices[tg.supermarket.id] < it.product.prices[best.supermarket.id] ? tg : best);
          const price = it.product.prices[target.supermarket.id];
          target.items.push({ ...it, supermarket: target.supermarket, unitPrice: price,
            isPromo: !!(it.product.promo && it.product.promo[target.supermarket.id]) });
          target.subtotal += price * it.qty;
        });
      });
      groups = top2.sort((a, b) => b.subtotal - a.subtotal);
    }

    groups = groups.map(g => ({ ...g, subtotal: round2(g.subtotal) }));
    const splitTotal = round2(groups.reduce((s, g) => s + g.subtotal, 0));
    const singleTotal = round2(totals[bestSingle.id]);
    const savings = round2(singleTotal - splitTotal);
    const savingsPct = singleTotal > 0 ? Math.round((savings / singleTotal) * 1000) / 10 : 0;
    const shouldSplit = groups.length > 1 && (savings > 2 || savingsPct > 3);

    return {
      singleTotal, splitTotal, savings, savingsPct,
      bestSingle, worstSingle,
      worstSingleTotal: round2(totals[worstSingle.id]),
      allTotals: sortedSingles.map(sm => ({ supermarket: sm, total: round2(totals[sm.id]) })),
      splitGroups: groups, shouldSplit,
      totalItems: cartItems.reduce((s, i) => s + i.qty, 0),
    };
  }

  const DEMO_CART = [
    { productId: 'frango_inteiro', qty: 1 },
    { productId: 'tomates', qty: 2 },
    { productId: 'laranjas', qty: 1 },
    { productId: 'alface', qty: 1 },
    { productId: 'leite_uht', qty: 4 },
    { productId: 'iogurte_natural', qty: 2 },
    { productId: 'queijo_flamengo', qty: 1 },
    { productId: 'agua_6pack', qty: 1 },
    { productId: 'detergente_roupa', qty: 1 },
    { productId: 'pizza_congelada', qty: 2 },
  ];

  return { SUPERMARKETS, CATEGORIES, PRODUCTS, getWeeklyRanking, compareCart, DEMO_CART };
})();
