-- OláSuper — Supabase Setup SQL
-- Run this in the Supabase SQL Editor:
-- https://supabase.com/dashboard/project/_/sql/new

-- ─────────────────────────────────────────────────────────────
-- 1. PROFILES TABLE
-- ─────────────────────────────────────────────────────────────
create table if not exists public.profiles (
  id             uuid         primary key references auth.users(id) on delete cascade,
  plano          text         not null default 'free',      -- 'free' | 'plus' | 'plus_health'
  analises_usadas int         not null default 0,
  data_reset     date         default (date_trunc('month', now()) + interval '1 month')::date,
  distrito       text         default 'lisboa',
  lingua         text         default 'pt',
  created_at     timestamptz  not null default now()
);

-- Enable Row Level Security
alter table public.profiles enable row level security;

-- Users can only read/update their own profile
create policy "profiles: self read"
  on public.profiles for select
  using (auth.uid() = id);

create policy "profiles: self update"
  on public.profiles for update
  using (auth.uid() = id);

-- ─────────────────────────────────────────────────────────────
-- 2. AUTO-CREATE PROFILE ON SIGNUP (trigger)
-- ─────────────────────────────────────────────────────────────
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id, plano, analises_usadas, data_reset, distrito, lingua)
  values (
    new.id,
    'free',
    0,
    (date_trunc('month', now()) + interval '1 month')::date,
    'lisboa',
    'pt'
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- ─────────────────────────────────────────────────────────────
-- 3. DECREMENT ANALYSIS USAGE (RPC called from app)
-- ─────────────────────────────────────────────────────────────
create or replace function public.decrement_analises(user_id uuid)
returns void
language plpgsql
security definer set search_path = public
as $$
begin
  update public.profiles
  set analises_usadas = analises_usadas + 1
  where id = user_id
    and plano = 'free';   -- only counts for free plan
end;
$$;

-- ─────────────────────────────────────────────────────────────
-- 4. AUTO-RESET USAGE ON THE 1st OF EACH MONTH (cron job)
-- ─────────────────────────────────────────────────────────────
-- Requires pg_cron extension (enabled in Supabase by default)
-- Run once to schedule the reset:

select cron.schedule(
  'reset-analises-mensais',        -- job name
  '0 0 1 * *',                     -- cron: midnight on the 1st of every month
  $$
    update public.profiles
    set
      analises_usadas = 0,
      data_reset = (date_trunc('month', now()) + interval '1 month')::date
    where plano = 'free';
  $$
);

-- ─────────────────────────────────────────────────────────────
-- 5. VERIFY — check everything was created correctly
-- ─────────────────────────────────────────────────────────────
select column_name, data_type, column_default
from information_schema.columns
where table_schema = 'public'
  and table_name   = 'profiles'
order by ordinal_position;
