// cd_wallet_v2.jsx — WalletScreen + MemberSheet (paywall)
const { useState: useWV, useEffect: useEW, useMemo: useMW } = React;

// ============ WALLET ============
function WalletScreen({ plan, onJoin }) {
  const T = CESTO_STRINGS.pt;
  const W = CESTO_WALLET;
  const [period, setPeriod] = useWV('mes');
  const [run, setRun] = useWV(false);
  useEW(() => { const id = setTimeout(() => setRun(true), 120); return () => clearTimeout(id); }, []);
  const P = W.periods[period];
  const animated = useCountUp(P.saved, run);
  const handlePeriod = p => { setPeriod(p); setRun(false); setTimeout(() => setRun(true), 30); };
  const cats = CESTO_SAVE_MIX.map(m => ({
    ...m, meta: CESTO_CATEGORIES.find(c => c.id === m.id), amount: P.saved * m.w,
  })).filter(c => c.meta);
  const maxCat = cats[0].amount;
  const spentPct = Math.min(100, P.spent / P.budget * 100);
  const fee = cestoFee();
  const feePctNum = fee / W.periods.mes.saved * 100;
  const feePctStr = (feePctNum < 10 ? feePctNum.toFixed(1) : Math.round(feePctNum).toString()).replace('.', ',') + '%';

  return (
    <div className="screen screen-enter">
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 14 }}>
        <h2 className="h2" style={{ flex: 1 }}>{T.wallet_title}</h2>
        {plan === 'member' && <span className="prempill">★ {T.wallet_member_badge}</span>}
      </div>

      <div className="segmented">
        {['semana', 'mes', 'ano'].map(k => (
          <button key={k} className={'seg' + (period === k ? ' is-on' : '')} onClick={() => handlePeriod(k)}>
            {W.periods[k].label_pt}
          </button>
        ))}
      </div>

      <div className="screen__scroll" style={{ marginTop: 14 }}>
        {/* animated hero */}
        <div className="wallet-hero">
          <div className="wallet-hero__glow" />
          <div style={{ position: 'relative' }}>
            <div className="wallet-hero__label">{T.wallet_saved_label} · {P.label_pt}</div>
            <div className="wallet-hero__num mono">
              {animated.toFixed(2).replace('.', ',')}&nbsp;€
            </div>
            <div className="wallet-hero__sub">{T.wallet_baskets(P.baskets)}</div>
          </div>
        </div>

        {/* goal */}
        <div className="card-pro" style={{ marginTop: 14 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
            <span className="card-pro__title">{T.wallet_goal_title}</span>
            <span className="mono" style={{ fontWeight: 700, fontSize: 14 }}>{eur(P.budget)}</span>
          </div>
          <div className="goalbar">
            <div className="goalbar__fill" style={{ width: `${spentPct}%` }} />
          </div>
          <div className="goalstats">
            <div>
              <span className="goalstats__k">{T.wallet_goal_spent}</span>
              <span className="goalstats__v mono">{eur(P.spent)}</span>
            </div>
            <div style={{ textAlign: 'right' }}>
              <span className="goalstats__k">{T.wallet_goal_left}</span>
              <span className="goalstats__v mono" style={{ color: 'var(--mint)' }}>{eur(P.budget - P.spent)}</span>
            </div>
          </div>
        </div>

        {/* categories */}
        <div className="kicker" style={{ marginTop: 22, marginBottom: 12 }}>{T.wallet_cats_title}</div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 9 }}>
          {cats.map(c => (
            <div key={c.id} className="anlz-row">
              <span className="prod__glyph" style={{ width: 34, height: 34 }}>{c.meta.glyph}</span>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div className="prod__name" style={{ fontSize: 14.5 }}>{c.meta.pt}</div>
                <div className="bar" style={{ marginTop: 6 }}>
                  <div className="bar__fill" style={{ width: `${c.amount / maxCat * 100}%`, background: 'var(--mint)' }} />
                </div>
              </div>
              <span className="anlz-amt anlz-amt--g mono">{eur(c.amount)}</span>
            </div>
          ))}
        </div>

        {/* history */}
        <div className="kicker" style={{ marginTop: 22, marginBottom: 12 }}>{T.wallet_history_title}</div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 9 }}>
          {W.history.map((h, i) => (
            <div key={i} className="histrow">
              <StoreTile store={h.store} size={36} />
              <div style={{ flex: 1, minWidth: 0 }}>
                <div className="prod__name" style={{ fontSize: 14.5 }}>{CESTO_STORES[h.store].name}</div>
                <div className="prod__unit">{h.date_pt}</div>
              </div>
              <span className="anlz-amt anlz-amt--g mono">+{eur(h.saved)}</span>
            </div>
          ))}
        </div>

        {/* fee card */}
        <div className={'feecard' + (plan === 'member' ? ' feecard--member' : '')} style={{ marginTop: 20 }}>
          <div style={{ flex: 1 }}>
            <div className="feecard__title">{T.wallet_fee_title}</div>
            <div className="feecard__caption">{T.wallet_fee_caption(eur(W.periods.mes.saved))}</div>
            <div className="feecard__capped">✓ {T.wallet_fee_capped(feePctStr)}</div>
          </div>
          <div style={{ textAlign: 'right' }}>
            <div className="feecard__amt mono">{eur(fee)}<span>/mês</span></div>
            {plan !== 'member' && (
              <button className="feecard__join" onClick={onJoin}>Aderir</button>
            )}
          </div>
        </div>
        <div style={{ height: 14 }} />
      </div>
    </div>
  );
}

// ============ MEMBER SHEET ============
function MemberSheet({ onSubscribe, onClose }) {
  const T = CESTO_STRINGS.pt;
  const MIN = 40, MAX = 300;
  const [target, setTarget] = useWV(120);
  const [payStep, setPayStep] = useWV('offer'); // offer | paying | success
  const worthIt = target >= CESTO_FEE_THRESHOLD;
  const pctNum = CESTO_FEE / target * 100;
  const pctStr = (pctNum < 10 ? pctNum.toFixed(1) : Math.round(pctNum).toString()).replace('.', ',') + '%';
  const sliderPct = (target - MIN) / (MAX - MIN) * 100;
  const threshPct = (CESTO_FEE_THRESHOLD - MIN) / (MAX - MIN) * 100;
  const NEW_BENEFITS = new Set([2, 3]);

  function doPay() {
    setPayStep('paying');
    setTimeout(() => {
      setPayStep('success');
      setTimeout(onSubscribe, 1200);
    }, 1400);
  }

  return (
    <div className="paywall-scrim" onClick={payStep === 'offer' ? onClose : undefined}>
      <div className="member anim-up" onClick={e => e.stopPropagation()}>
        <div className="paywall__grip" />
        <div className="paywall__glow" />
        <div className="member__scroll">

          {payStep === 'offer' && (
            <>
              <div className="m-emblem">★</div>
              <div className="kicker" style={{ color: 'var(--mint-bright)', textAlign: 'center', letterSpacing: '.18em' }}>
                {T.member_kicker}
              </div>
              <h2 className="h2" style={{ color: '#fff', whiteSpace: 'pre-line', marginTop: 8, textAlign: 'center', lineHeight: 1.12 }}>
                {T.member_title}
              </h2>
              <p style={{ color: 'var(--mint-soft)', marginTop: 10, fontSize: 13.5, opacity: .9, textAlign: 'center', maxWidth: 300, margin: '10px auto 0', whiteSpace: 'pre-line', lineHeight: 1.5, fontWeight: 500 }}>
                {T.member_body}
              </p>

              {/* price card */}
              <div className="m-price">
                <div className="m-price__glow" />
                <div className="m-price__main">
                  <span className="m-price__amt">1,00 €</span>
                  <span className="m-price__per">{T.member_sim_per}</span>
                </div>
                <span className="m-price__pill">✓ {T.member_price_pill}</span>
                <div className="m-price__cap">{T.member_price_cap}</div>
              </div>

              {/* value simulator */}
              <div className="m-sim">
                <div className="m-sim__head">{T.member_value_title}</div>
                <span style={{ display: 'block', marginTop: 10, fontSize: 12.5, fontWeight: 600, color: 'var(--mint-soft)' }}>
                  {T.member_sim_label}
                </span>
                <div className="m-sim__target">
                  {target}&nbsp;<small style={{ fontSize: 14, fontWeight: 600, color: 'var(--mint-soft)' }}>€/mês</small>
                </div>
                <div className="sim__sliderwrap">
                  <input className="mslider" type="range" min={MIN} max={MAX} step="5" value={target}
                    onChange={e => setTarget(Number(e.target.value))}
                    style={{ background: `linear-gradient(90deg,var(--mint) ${sliderPct}%,rgba(255,255,255,.15) ${sliderPct}%)` }}
                  />
                  <div className="sim__thresh" style={{ left: `${threshPct}%` }}>
                    <span className="sim__threshtip">{T.member_threshold_tip}</span>
                  </div>
                </div>
                <div className={'sim__verdict' + (worthIt ? ' is-yes' : ' is-no')}>
                  <span className="sim__verdictpct">{pctStr}</span>
                  <span className="sim__verdicttxt">
                    {worthIt ? T.member_sim_pct(pctStr) : T.member_reco_no}
                  </span>
                </div>
                {worthIt && <div className="m-reco">{T.member_reco_yes}</div>}
              </div>

              {/* benefits */}
              <div className="kicker" style={{ color: 'var(--mint-bright)', marginTop: 22 }}>
                {T.member_benefits_title}
              </div>
              <div className="m-bens">
                {T.member_benefits.map((b, i) => (
                  <div key={i} className="m-ben">
                    <span className="m-ben__ic">✓</span>
                    <span className="m-ben__txt">{b}</span>
                    {NEW_BENEFITS.has(i) && <span className="m-ben__new">{T.member_new}</span>}
                  </div>
                ))}
              </div>

              <div className="member__local">🛒 {T.member_local}</div>

              {/* payment methods */}
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginTop: 18 }}>
                <button onClick={doPay} style={{
                  height: 52, borderRadius: 14, border: 'none', background: '#000', color: '#fff',
                  fontSize: 16, fontWeight: 700, fontFamily: 'var(--font)', cursor: 'pointer',
                  display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 7,
                }}>
                  <svg width="17" height="20" viewBox="0 0 17 20" fill="#fff" aria-hidden="true"><path d="M13.9 10.6c0-2.4 2-3.6 2.1-3.6-1.1-1.7-2.9-1.9-3.5-1.9-1.5-.2-2.9.9-3.7.9-.8 0-1.9-.9-3.2-.8C4 5.2 2.5 6.1 1.7 7.6c-1.7 3-.4 7.4 1.2 9.8.8 1.2 1.7 2.5 3 2.4 1.2 0 1.7-.8 3.1-.8 1.5 0 1.9.8 3.2.8 1.3 0 2.1-1.2 2.9-2.4.9-1.4 1.3-2.7 1.3-2.8 0 0-2.5-1-2.5-4zM11.5 3.4c.7-.8 1.1-1.9 1-3.1-1 0-2.2.7-2.9 1.5-.6.7-1.2 1.9-1 3 1.1.1 2.2-.6 2.9-1.4z"/></svg>
                  Pay
                </button>
                <button onClick={doPay} style={{
                  height: 52, borderRadius: 14, border: '1.5px solid rgba(255,255,255,.25)', background: 'transparent',
                  color: '#fff', fontSize: 15.5, fontWeight: 700, fontFamily: 'var(--font)', cursor: 'pointer',
                  display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
                }}>
                  <span aria-hidden="true" style={{ fontWeight: 800, fontSize: 16 }}>
                    <span style={{ color: '#4285F4' }}>G</span><span style={{ color: '#EA4335' }}>o</span><span style={{ color: '#FBBC04' }}>o</span><span style={{ color: '#4285F4' }}>g</span><span style={{ color: '#34A853' }}>l</span><span style={{ color: '#EA4335' }}>e</span>
                  </span>
                  Pay
                </button>
                <button onClick={doPay} style={{
                  height: 46, borderRadius: 12, border: 'none', background: 'transparent',
                  color: 'var(--mint-soft)', fontSize: 14.5, fontWeight: 600,
                  fontFamily: 'var(--font)', cursor: 'pointer', width: '100%',
                }}>
                  💳 Pagar com cartão
                </button>
              </div>

              <div style={{ textAlign: 'center', fontSize: 11.5, fontWeight: 600, color: 'var(--mint-soft)', opacity: .75, marginTop: 8, marginBottom: 4 }}>
                {T.member_trust}
              </div>
            </>
          )}

          {payStep === 'paying' && (
            <div style={{ textAlign: 'center', padding: '52px 0 60px' }}>
              <div style={{
                width: 52, height: 52, margin: '0 auto 18px', borderRadius: '50%',
                border: '4px solid rgba(255,255,255,.2)', borderTopColor: 'var(--mint)',
                animation: 'spin .8s linear infinite',
              }} />
              <div style={{ fontSize: 16, fontWeight: 700, color: '#fff' }}>A processar…</div>
              <div style={{ fontSize: 13, color: 'var(--mint-soft)', marginTop: 5 }}>1,00 € · CestoDoce Member</div>
            </div>
          )}

          {payStep === 'success' && (
            <div style={{ textAlign: 'center', padding: '48px 0 56px' }}>
              <div style={{
                width: 64, height: 64, margin: '0 auto 16px', borderRadius: '50%',
                background: 'var(--mint)', display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: 30, color: '#06281a', animation: 'popIn .4s cubic-bezier(.34,1.56,.64,1) both',
              }}>✓</div>
              <div style={{ fontSize: 20, fontWeight: 800, color: '#fff', letterSpacing: '-.02em' }}>
                Bem-vinda, Member!
              </div>
              <div style={{ fontSize: 13.5, color: 'var(--mint-soft)', marginTop: 6 }}>
                Análises ilimitadas ativadas.
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { WalletScreen, MemberSheet });
