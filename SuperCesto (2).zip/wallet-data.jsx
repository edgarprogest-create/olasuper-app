// wallet-data.jsx — Wallet (poupança) data + CestoDoce Member strings.
// Loaded after catalog.jsx, so CESTO_STRINGS already exists.

// Fixed category proportions of total savings (sums ~1). Top 5 shown.
const CESTO_SAVE_MIX = [
  { id: "snacks", w: 0.27 },
  { id: "limpeza", w: 0.22 },
  { id: "enlatados", w: 0.17 },
  { id: "laticinios", w: 0.14 },
  { id: "bebidas", w: 0.11 },
  { id: "congelados", w: 0.09 },
];

// CestoDoce Member = flat €1/month. The threshold below which it stops making
// sense is €100 saved/month (at €100, €1 is exactly 1% of savings).
const CESTO_FEE = 1;
const CESTO_FEE_THRESHOLD = 100;
function cestoFee() { return CESTO_FEE; }

const CESTO_WALLET = {
  periods: {
    semana: { label_pt: "Semana", label_en: "Week",  saved: 18.40,  baskets: 1,  budget: 70,   spent: 51.60 },
    mes:    { label_pt: "Mês",    label_en: "Month", saved: 128.50, baskets: 4,  budget: 250,  spent: 214.30 },
    ano:    { label_pt: "Ano",    label_en: "Year",  saved: 942.00, baskets: 47, budget: 3000, spent: 2480.00 },
  },
  history: [
    { date_pt: "7 Jun",  date_en: "Jun 7",  store: "lidl",        saved: 18.40 },
    { date_pt: "31 Mai", date_en: "May 31", store: "continente",  saved: 22.10 },
    { date_pt: "24 Mai", date_en: "May 24", store: "intermarche", saved: 15.60 },
    { date_pt: "17 Mai", date_en: "May 17", store: "pingo",       saved: 9.80 },
    { date_pt: "10 Mai", date_en: "May 10", store: "lidl",        saved: 24.30 },
    { date_pt: "3 Mai",  date_en: "May 3",  store: "continente",  saved: 14.05 },
  ],
};

Object.assign(window, { CESTO_SAVE_MIX, CESTO_WALLET, cestoFee, CESTO_FEE, CESTO_FEE_THRESHOLD });

Object.assign(CESTO_STRINGS.pt, {
  brand: "CestoDoce",
  brand_member: "CestoDoce Member",

  // result/receipt CTA into wallet
  receipt_to_wallet: "Adicionar à Wallet",

  // wallet
  wallet_title: "Wallet",
  wallet_sub: "A sua poupança, ao detalhe.",
  wallet_saved_label: "Poupança acumulada",
  wallet_baskets: (n) => `${n} ${n === 1 ? "cesto" : "cestos"} otimizado${n === 1 ? "" : "s"}`,
  wallet_goal_title: "Objetivo do mês",
  wallet_goal_budget: "Orçamento",
  wallet_goal_spent: "Gasto",
  wallet_goal_left: "Disponível",
  wallet_goal_set: "250 €",
  wallet_cats_title: "Onde mais poupou",
  wallet_history_title: "Histórico",
  wallet_fee_title: "A sua mensalidade",
  wallet_fee_caption: (saved) => `Mensalidade fixa · poupou ${saved} este mês`,
  wallet_fee_capped: (pct) => `1 € é só ${pct} do que poupou`,
  wallet_member_badge: "Member",

  // profile / dashboard
  profile_title: "Perfil",
  profile_name: "Sofia Almeida",
  profile_email: "sofia.almeida@email.pt",
  profile_member_since: "Member desde Mar 2026",
  profile_free_since: "Plano grátis",
  profile_sec_plan: "Plano",
  profile_sec_wallet: "Wallet",
  profile_sec_history: "Histórico",
  profile_plan_member: "CestoDoce Member",
  profile_plan_free: "Plano grátis",
  profile_plan_fee_member: (fee) => `${fee} / mês · fixo`,
  profile_plan_fee_free: "1 €/mês · vale a pena se poupar 100 €+",
  profile_manage: "Gerir",
  profile_join: "Aderir",
  profile_saved_total: "Poupança acumulada",
  profile_this_month: "este mês",
  profile_see_all: "Ver tudo",
  profile_settings: "Definições",
  profile_signout: "Terminar sessão",

  // member sheet (reframed paywall)
  member_kicker: "CestoDoce Member",
  member_title: "Poupe mais.\nPague só 1 € por mês.",
  member_body: "O premium não existe apenas para desbloquear funcionalidades.\n\nEle existe para transformar a forma como compra todas as semanas.",
  member_price_pill: "Fixo · para sempre",
  member_price_cap: "Mensalidade fixa, sem surpresas.",
  member_value_title: "O que vale para si",
  member_new: "Novo",
  member_sim_label: "Quanto quer poupar por mês?",
  member_sim_fee: "A sua mensalidade",
  member_sim_fixed: "1 € / mês · fixo",
  member_sim_pct: (pct) => `Só ${pct} do que poupa`,
  member_reco_yes: "✓ Vale a pena para si",
  member_reco_no: "Recomendado a partir de 100 €/mês",
  member_threshold_tip: "100 €",
  member_sim_per: "/ mês",
  member_benefits_title: "Tudo incluído",
  member_benefits: [
    "Comparação automática de preços",
    "Recibos otimizados sem limite",
    "Alertas quando saem os folhetos semanais",
    "Alertas quando os favoritos entram em promoção",
    "Wallet de poupança integrada",
    "Recomendações automáticas de cesto",
    "Suporte humano via WhatsApp",
  ],
  member_local: "Ao aderir, ajuda também os supermercados locais a competir.",
  member_cta: "Aderir ao CestoDoce Member",
  member_later: "Agora não",
  member_trust: "Cancela quando quiseres · sem compromisso",
});

Object.assign(CESTO_STRINGS.en, {
  brand: "CestoDoce",
  brand_member: "CestoDoce Member",

  receipt_to_wallet: "Add to Wallet",

  wallet_title: "Wallet",
  wallet_sub: "Your savings, in detail.",
  wallet_saved_label: "Total savings",
  wallet_baskets: (n) => `${n} optimized ${n === 1 ? "basket" : "baskets"}`,
  wallet_goal_title: "This month's goal",
  wallet_goal_budget: "Budget",
  wallet_goal_spent: "Spent",
  wallet_goal_left: "Available",
  wallet_goal_set: "€250",
  wallet_cats_title: "Where you saved most",
  wallet_history_title: "History",
  wallet_fee_title: "Your membership",
  wallet_fee_caption: (saved) => `Flat fee · saved ${saved} this month`,
  wallet_fee_capped: (pct) => `€1 is just ${pct} of what you saved`,
  wallet_member_badge: "Member",

  // profile / dashboard
  profile_title: "Profile",
  profile_name: "Sofia Almeida",
  profile_email: "sofia.almeida@email.pt",
  profile_member_since: "Member since Mar 2026",
  profile_free_since: "Free plan",
  profile_sec_plan: "Plan",
  profile_sec_wallet: "Wallet",
  profile_sec_history: "History",
  profile_plan_member: "CestoDoce Member",
  profile_plan_free: "Free plan",
  profile_plan_fee_member: (fee) => `${fee} / mo · flat`,
  profile_plan_fee_free: "€1/mo · worth it if you save €100+",
  profile_manage: "Manage",
  profile_join: "Join",
  profile_saved_total: "Total savings",
  profile_this_month: "this month",
  profile_see_all: "See all",
  profile_settings: "Settings",
  profile_signout: "Sign out",

  member_kicker: "CestoDoce Member",
  member_title: "Save more.\nPay just €1 a month.",
  member_body: "A flat monthly fee, made for people who save €100 or more a month. At that level, €1 is less than 1% of what you save.",
  member_price_pill: "Flat · forever",
  member_price_cap: "A flat fee, no surprises.",
  member_value_title: "What it's worth to you",
  member_new: "New",
  member_sim_label: "How much do you want to save per month?",
  member_sim_fee: "Your membership",
  member_sim_fixed: "€1 / mo · flat",
  member_sim_pct: (pct) => `Just ${pct} of what you save`,
  member_reco_yes: "✓ Worth it for you",
  member_reco_no: "Recommended from €100/mo",
  member_threshold_tip: "€100",
  member_sim_per: "/ mo",
  member_benefits_title: "Everything included",
  member_benefits: [
    "Automatic price comparison",
    "Unlimited optimized receipts",
    "Alerts when weekly flyers drop",
    "Alerts when your favorites go on sale",
    "Built-in savings Wallet",
    "Automatic basket recommendations",
    "Human support via WhatsApp",
  ],
  member_local: "By joining, you also help local supermarkets compete.",
  member_cta: "Join CestoDoce Member",
  member_later: "Not now",
  member_trust: "Cancel anytime · no commitment",
});

// ===== Preferred district → local supermarket ranking =====
// Each district has its own ordering of the 4 chains. Totals/savings are
// derived from rank so the #1 store changes per locality.
const CESTO_DIST_TOTALS = [71.60, 76.40, 82.30, 90.00];
const CESTO_STORE_PROMOS = { lidl: 17, continente: 12, pingo: 9, intermarche: 14 };
const CESTO_DISTRICTS = [
  { id: "lisboa",     name: "Lisboa",            order: ["continente", "pingo", "lidl", "intermarche"] },
  { id: "porto",      name: "Porto",             order: ["lidl", "continente", "intermarche", "pingo"] },
  { id: "braga",      name: "Braga",             order: ["intermarche", "lidl", "pingo", "continente"] },
  { id: "coimbra",    name: "Coimbra",           order: ["pingo", "lidl", "continente", "intermarche"] },
  { id: "aveiro",     name: "Aveiro",            order: ["lidl", "intermarche", "continente", "pingo"] },
  { id: "setubal",    name: "Setúbal",           order: ["pingo", "continente", "lidl", "intermarche"] },
  { id: "faro",       name: "Faro",              order: ["continente", "lidl", "intermarche", "pingo"] },
  { id: "leiria",     name: "Leiria",            order: ["lidl", "pingo", "intermarche", "continente"] },
  { id: "aveiro2",    name: "Viseu",             order: ["intermarche", "continente", "lidl", "pingo"] },
  { id: "santarem",   name: "Santarém",          order: ["continente", "intermarche", "pingo", "lidl"] },
];

function cestoDistrictRanking(distId) {
  const d = CESTO_DISTRICTS.find((x) => x.id === distId) || CESTO_DISTRICTS[0];
  const worst = CESTO_DIST_TOTALS[CESTO_DIST_TOTALS.length - 1];
  return d.order.map((store, i) => ({
    store, rank: i + 1,
    total: CESTO_DIST_TOTALS[i],
    saved: worst - CESTO_DIST_TOTALS[i],
    promos: CESTO_STORE_PROMOS[store] || 0,
  }));
}

Object.assign(window, { CESTO_DISTRICTS, cestoDistrictRanking });

Object.assign(CESTO_STRINGS.pt, {
  result_district_label: "Distrito preferencial",
  result_rank_title: (d) => `Melhores supermercados em ${d}`,
  result_rank_total: "Total do cesto",
  result_rank_save: (v) => `Poupa ${v}`,
  result_rank_promos: (n) => `${n} em promoção`,
  result_best_here: "Melhor aqui",
});
Object.assign(CESTO_STRINGS.en, {
  result_district_label: "Preferred district",
  result_rank_title: (d) => `Best supermarkets in ${d}`,
  result_rank_total: "Basket total",
  result_rank_save: (v) => `Saves ${v}`,
  result_rank_promos: (n) => `${n} on promo`,
  result_best_here: "Best here",
});
