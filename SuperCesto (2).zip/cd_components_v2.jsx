// cd_components_v2.jsx — phone shell, StoreTile, TabBar, shared utilities
const { useState: useCV, useEffect: useEV, useRef: useRV, useLayoutEffect: useLEV } = React;

// ---- viewport scale ----
function usePhoneScale() {
  const [scale, setScale] = useCV(1);
  useLEV(() => {
    const fit = () => {
      const sx = (window.innerWidth  - 32) / 390;
      const sy = (window.innerHeight - 32) / 844;
      setScale(Math.min(1.08, Math.max(0.4, Math.min(sx, sy))));
    };
    fit();
    window.addEventListener('resize', fit);
    return () => window.removeEventListener('resize', fit);
  }, []);
  return scale;
}

// ---- status bar ----
function StatusBar({ dark }) {
  const now = new Date();
  const time = `${String(now.getHours()).padStart(2,'0')}:${String(now.getMinutes()).padStart(2,'0')}`;
  return (
    <div className="statusbar" style={{ color: dark ? '#eef6f0' : 'var(--ink)' }}>
      <span>{time}</span>
      <div className="statusbar__dots">
        <i/><i/><i/>
        <span style={{ width:6 }}/>
        <span style={{ fontWeight:800, fontSize:12 }}>5G</span>
        <span style={{ width:4 }}/>
        <span className="statusbar__bat"><i/></span>
      </div>
    </div>
  );
}

// ---- phone frame ----
function PhoneFrame({ children, dark }) {
  const scale = usePhoneScale();
  return (
    <div className="stage">
      <div className="phone-scaler" style={{ transform:`scale(${scale})` }}>
        <div className="phone">
          <div className="phone__cam"/>
          <div className="phone__screen">
            <StatusBar dark={dark} />
            {children}
            <div className="homebar" style={{ opacity: dark ? 0.45 : 0.28 }}/>
          </div>
        </div>
      </div>
    </div>
  );
}

// ---- StoreTile: colored + drag/click to upload logo ----
const _CD_LOGOS = {};
(function(){
  try {
    Object.keys(CESTO_STORES).forEach(k => {
      const v = localStorage.getItem('cesto_logo_' + k);
      if (v) _CD_LOGOS[k] = v;
    });
  } catch(e){}
})();

function cdSetLogo(store, url) {
  if (url) _CD_LOGOS[store] = url; else delete _CD_LOGOS[store];
  try {
    if (url) localStorage.setItem('cesto_logo_' + store, url);
    else localStorage.removeItem('cesto_logo_' + store);
  } catch(e){}
  window.dispatchEvent(new CustomEvent('cesto-logos-changed'));
}

function StoreTile({ store, size = 46 }) {
  const s = CESTO_STORES[store];
  if (!s) return <div style={{ width:size, height:size, borderRadius:12, background:'var(--line)' }}/>;
  const [logo, setLogo] = useCV(_CD_LOGOS[store] || null);
  const fileRef = useRV(null);
  const [over, setOver] = useCV(false);
  useEV(() => {
    const h = () => setLogo(_CD_LOGOS[store] || null);
    window.addEventListener('cesto-logos-changed', h);
    return () => window.removeEventListener('cesto-logos-changed', h);
  }, [store]);
  const bg = `linear-gradient(155deg, hsl(${s.hue} 32% 42%), hsl(${s.hue} 36% 32%))`;
  const handleFile = f => {
    if (!f || !f.type.startsWith('image/')) return;
    const reader = new FileReader();
    reader.onload = () => {
      const img = new Image();
      img.onload = () => {
        const max=180, sc=Math.min(1, max/Math.max(img.width,img.height));
        const w=Math.max(1,Math.round(img.width*sc)), h2=Math.max(1,Math.round(img.height*sc));
        const c=document.createElement('canvas'); c.width=w; c.height=h2;
        c.getContext('2d').drawImage(img,0,0,w,h2);
        try { cdSetLogo(store, c.toDataURL('image/png')); } catch(e) { cdSetLogo(store, reader.result); }
      };
      img.onerror = () => cdSetLogo(store, reader.result);
      img.src = reader.result;
    };
    reader.readAsDataURL(f);
  };
  return (
    <div
      className={'store-tile'+(logo?' store-tile--logo':'')+(over?' is-over':'')}
      style={{ width:size, height:size, fontSize:size*.32, background:logo?'#fff':bg, cursor:'pointer' }}
      title={s.name+' — clique ou arraste para definir logótipo'}
      onClick={e => { e.stopPropagation(); fileRef.current&&fileRef.current.click(); }}
      onDragOver={e => { e.preventDefault(); e.stopPropagation(); setOver(true); }}
      onDragLeave={() => setOver(false)}
      onDrop={e => { e.preventDefault(); e.stopPropagation(); setOver(false); handleFile(e.dataTransfer.files[0]); }}
    >
      {logo
        ? <img src={logo} alt={s.name} style={{ width:'100%',height:'100%',objectFit:'contain',padding:Math.round(size*.1) }}/>
        : s.mark}
      <input ref={fileRef} type="file" accept="image/*"
        onChange={e => { handleFile(e.target.files[0]); e.target.value=''; }}
        style={{ display:'none' }}/>
    </div>
  );
}

// ---- animated count-up ----
function useCountUp(target, run, ms = 1100) {
  const [v, setV] = useCV(0);
  useEV(() => {
    if (!run) { setV(0); return; }
    let raf, start, cancelled = false;
    const tick = t => {
      if (cancelled) return;
      if (!start) start = t;
      const p = Math.min(1,(t-start)/ms);
      setV(target*(1-Math.pow(1-p,3)));
      if (p < 1) raf = requestAnimationFrame(tick); else setV(target);
    };
    raf = requestAnimationFrame(tick);
    return () => { cancelled=true; cancelAnimationFrame(raf); };
  }, [target, run, ms]);
  return v;
}

// ---- currency formatter (PT) ----
function eur(n) {
  return Number(n).toFixed(2).replace('.', ',') + '\u00a0€';
}

// ---- tab bar ----
function TabBar({ screen, onNav, cartCount }) {
  const tabs = [
    { id:'home',    label:'Início' },
    { id:'cart',    label:'Carrinho' },
    { id:'wallet',  label:'Wallet' },
    { id:'profile', label:'Perfil' },
  ];
  const cartActive = ['cart','analyzing','compare','receipt','split'].includes(screen);
  return (
    <div className="tabbar">
      {tabs.map(tab => {
        const on = tab.id === screen || (tab.id==='cart' && cartActive);
        return (
          <button key={tab.id} className={'tab'+(on?' is-on':'')} onClick={() => onNav(tab.id)}>
            <TIcon id={tab.id} on={on} />
            {tab.id==='cart' && cartCount>0 && <span className="tab__dot"/>}
            <span className="tab__label">{tab.label}</span>
          </button>
        );
      })}
    </div>
  );
}

function TIcon({ id, on }) {
  const col = on ? 'var(--mint)' : 'var(--muted)';
  const p = { width:23, height:23, viewBox:'0 0 24 24', fill:'none', stroke:col, strokeWidth:1.8, strokeLinecap:'round', strokeLinejoin:'round' };
  if (id==='home')    return <svg {...p}><path d="M3 11.5L12 4l9 7.5V21h-6v-5H9v5H3z"/></svg>;
  if (id==='cart')    return <svg {...p}><path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6L18 2H6z"/><path d="M3 6h18"/><path d="M16 10a4 4 0 01-8 0"/></svg>;
  if (id==='wallet')  return <svg {...p}><rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 3H8L2 7"/><path d="M22 7l-5-4"/><circle cx="16" cy="14" r="1.5" fill={col} stroke="none"/></svg>;
  if (id==='profile') return <svg {...p}><circle cx="12" cy="8" r="3.5"/><path d="M5 20c0-3.5 3-6 7-6s7 2.5 7 6"/></svg>;
  return null;
}

// ---- top back nav ----
function TopNav({ onBack, showBack=true, right }) {
  return (
    <div style={{ display:'flex', alignItems:'center', gap:12, marginBottom:20 }}>
      <button className="iconbtn" onClick={onBack}
        style={{ visibility:showBack?'visible':'hidden' }} aria-label="voltar">‹</button>
      <div style={{ flex:1 }}/>
      {right}
    </div>
  );
}

Object.assign(window, {
  usePhoneScale, PhoneFrame, StatusBar, StoreTile, cdSetLogo,
  useCountUp, eur, TabBar, TIcon, TopNav,
});
