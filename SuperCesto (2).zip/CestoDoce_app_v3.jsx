// CestoDoce_app_v3.jsx — App principal v3: dark premium
(function(){
const { useState, useEffect, useCallback } = React;
const D = window.CestoDoceData;

const SK = { PLAN:'cd3_plan', USAGE:'cd3_usage', CART:'cd3_cart' };

function load() {
  try {
    return {
      plan:  localStorage.getItem(SK.PLAN)  || 'free',
      usage: parseInt(localStorage.getItem(SK.USAGE)||'0',10),
      cart:  JSON.parse(localStorage.getItem(SK.CART)||'null') || D.DEMO_CART,
    };
  } catch { return { plan:'free', usage:0, cart:D.DEMO_CART }; }
}

function App() {
  const DEFS = { theme:'verde', demo:'free_unused' };
  const [t, setTweak] = useTweaks(DEFS);
  const theme = V3_THEMES[t.theme] || V3_THEMES.verde;

  const ini = load();
  function resolve(demo, stored) {
    if (demo==='member')     return { plan:'member', usageUsed:5 };
    if (demo==='used_quota') return { plan:'free',   usageUsed:1 };
    return { plan:stored.plan, usageUsed:stored.usage };
  }
  const res = resolve(t.demo, ini);
  const LIMIT = 1;

  const [screen,  setScreen]  = useState('home');
  const [cart,    setCart]    = useState(ini.cart);
  const [result,  setResult]  = useState(null);
  const [plan,    setPlan]    = useState(res.plan);
  const [usage,   setUsage]   = useState(res.usageUsed);
  const [savings, setSavings] = useState(null);
  const [paywall, setPaywall] = useState(false);
  const [simBudget, setSimBudget] = useState(120);

  useEffect(()=>{ const r=resolve(t.demo,ini); setPlan(r.plan); setUsage(r.usageUsed); },[t.demo]);
  useEffect(()=>{ try{ localStorage.setItem(SK.CART, JSON.stringify(cart)); }catch{} },[cart]);

  const cartCount = cart.reduce((s,i)=>s+i.qty,0);
  const usageLeft = LIMIT - usage;
  const canAnalyse = plan==='member' || usageLeft>0;

  const addToCart = useCallback(id=>{
    setCart(p=>p.find(i=>i.productId===id)?p:[...p,{productId:id,qty:1}]);
  },[]);

  const changeQty = useCallback((id,d)=>{
    setCart(p=>p.map(i=>i.productId===id?{...i,qty:Math.max(0,i.qty+d)}:i).filter(i=>i.qty>0));
  },[]);

  const runAnalysis = useCallback(()=>{
    if(!cart.length) return;
    if(!canAnalyse){ setPaywall(true); return; }
    setScreen('analyzing');
    setTimeout(()=>{
      const r = D.compareCart(cart);
      if(r) r._cart = cart;
      setResult(r);
      if(r) setSavings(r.shouldSplit?r.savings:0);
      if(plan==='free'){
        const next=usage+1; setUsage(next);
        try{ localStorage.setItem(SK.USAGE,String(next)); }catch{}
      }
      setScreen('analysis');
    }, D.SUPERMARKETS.length*290+820);
  },[cart,canAnalyse,plan,usage]);

  const subscribe = useCallback(()=>{
    setPlan('member'); setUsage(0); setPaywall(false);
    try{ localStorage.setItem(SK.PLAN,'member'); }catch{}
    if(cart.length){
      setTimeout(()=>{
        setScreen('analyzing');
        setTimeout(()=>{
          const r=D.compareCart(cart); if(r)r._cart=cart;
          setResult(r); if(r)setSavings(r.shouldSplit?r.savings:0);
          setScreen('analysis');
        }, D.SUPERMARKETS.length*290+820);
      },300);
    }
  },[cart]);

  const cartScreens = ['cart','analyzing','analysis'];
  const activeTab   = cartScreens.includes(screen)?(screen==='analysis'?'analysis':'cart'):screen;

  function renderScreen() {
    switch(screen){
      case 'home':
        return <HomeV3 theme={theme} onNewCart={()=>setScreen('cart')} cartCount={cartCount}
          plan={plan} monthlySaved={savings!=null?savings:4.30}
          simBudget={simBudget} onSimBudgetChange={setSimBudget}/>;
      case 'cart':
        return <CartV3 theme={theme} cart={cart} onChangeQty={changeQty} onAdd={addToCart}
          onAnalyse={runAnalysis} plan={plan} usageLeft={usageLeft}/>;
      case 'analyzing':
        return <AnalyzingV3 theme={theme} plan={plan}/>;
      case 'analysis':
        return <AnalysisV3 theme={theme} result={result} plan={plan}
          onBack={()=>setScreen('cart')} onGoCart={()=>setScreen('cart')}
          onUpgrade={()=>setPaywall(true)}/>;
      case 'scanner':
        return <ScannerV3 theme={theme} plan={plan} onUpgrade={()=>setPaywall(true)}/>;
      case 'profile':
        return <ProfileV3 theme={theme} plan={plan} usageUsed={usage} usageLimit={LIMIT}
          lastSavings={savings} onUpgrade={()=>setPaywall(true)}/>;
      default: return null;
    }
  }

  return (
    <div style={{ fontFamily:"'DM Sans',sans-serif", color:V3.ink, fontSize:15.5, lineHeight:1.45 }}>
      <V3Phone>
        {/* content */}
        <div style={{ position:'absolute', inset:0, bottom:62, background:V3.base, overflowY:'auto', overflowX:'hidden' }}>
          {renderScreen()}
        </div>

        {/* paywall */}
        {paywall&&<PaywallV3 theme={theme} lastSavings={savings} simBudget={simBudget}
          onSubscribe={subscribe} onClose={()=>setPaywall(false)}/>}

        {/* tabbar */}
        {screen!=='analyzing'&&(
          <V3TabBar
            current={activeTab}
            onChange={s=>{
              if(s==='analysis'&&!result){ setScreen('cart'); return; }
              setScreen(s);
            }}
            cartCount={cartCount} theme={theme}
          />
        )}
      </V3Phone>

      <TweaksPanel>
        <TweakSection label="Aparência"/>
        <TweakRadio label="Cor" value={t.theme}
          options={['verde','azul','laranja']}
          onChange={v=>setTweak('theme',v)}/>
        <TweakSection label="Cenário"/>
        <TweakSelect label="Conta"
          value={t.demo}
          options={[
            {value:'free_unused',label:'Grátis · disponível'},
            {value:'used_quota', label:'Grátis · quota usada'},
            {value:'member',     label:'CestoDoce Member'},
          ]}
          onChange={v=>setTweak('demo',v)}/>
      </TweaksPanel>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App/>);
})();
