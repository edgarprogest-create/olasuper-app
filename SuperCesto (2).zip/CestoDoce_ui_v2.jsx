// CestoDoce_ui_v2.jsx — Tokens v1 + PhoneFrame + StatusBar + Sparkline
const { useState: useUIV2, useEffect: useEV2, useRef: useRV2, useMemo: useMV2, useLayoutEffect: useLV2 } = React;

// ---- Design tokens (iguais ao v1) ----
const CD_THEMES = {
  verde:   { primary:'oklch(40% 0.13 150)', primaryDark:'oklch(30% 0.11 150)', primarySoft:'oklch(96% 0.025 150)', savings:'oklch(46% 0.17 150)' },
  azul:    { primary:'oklch(40% 0.13 250)', primaryDark:'oklch(30% 0.11 250)', primarySoft:'oklch(96% 0.02 250)',  savings:'oklch(46% 0.17 250)' },
  laranja: { primary:'oklch(48% 0.14 55)',  primaryDark:'oklch(36% 0.12 55)',  primarySoft:'oklch(96.5% 0.025 70)', savings:'oklch(50% 0.16 55)'  },
};
const CD = {
  bg:'oklch(98% 0.006 150)', surface:'#FFFFFF',
  ink:'oklch(20% 0.012 150)', ink2:'oklch(45% 0.012 150)', ink3:'oklch(62% 0.01 150)',
  line:'oklch(93% 0.008 150)', lineSoft:'oklch(95.5% 0.006 150)',
  promo:'oklch(56% 0.16 45)', promoBg:'oklch(96.5% 0.03 70)',
  gold:'oklch(75% 0.13 85)', goldBg:'oklch(96% 0.045 90)', goldInk:'oklch(42% 0.1 75)',
  member:'oklch(42% 0.12 300)', memberBg:'oklch(96% 0.025 300)',
  shadow:'0 1px 3px rgba(20,40,25,0.05), 0 4px 16px rgba(20,40,25,0.05)',
  shadowLift:'0 4px 12px rgba(20,40,25,0.08), 0 12px 32px rgba(20,40,25,0.10)',
};

// ---- Ícones ----
function CdSvg({ size=22, color='currentColor', children }) {
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">{children}</svg>;
}
function HomeIcon(p)      { return <CdSvg {...p}><path d="M3 10.5 12 3l9 7.5"/><path d="M5 9.5V21h14V9.5"/><path d="M9.5 21v-6h5v6"/></CdSvg>; }
function BasketIcon(p)    { return <CdSvg {...p}><path d="M4 9h16l-1.5 11h-13z"/><path d="M8 9l4-6 4 6"/></CdSvg>; }
function CompassIcon(p)   { return <CdSvg {...p}><circle cx="12" cy="12" r="9"/><path d="M15.5 8.5 13.8 13.8 8.5 15.5l1.7-5.3z"/></CdSvg>; }
function PersonIcon(p)    { return <CdSvg {...p}><circle cx="12" cy="7.5" r="3.5"/><path d="M4.5 20.5c0-4 3.4-6.5 7.5-6.5s7.5 2.5 7.5 6.5"/></CdSvg>; }
function SearchIcon(p)    { return <CdSvg {...p}><circle cx="11" cy="11" r="7"/><path d="m20 20-3.8-3.8"/></CdSvg>; }
function PlusIcon(p)      { return <CdSvg {...p}><path d="M12 5v14M5 12h14"/></CdSvg>; }
function MinusIcon(p)     { return <CdSvg {...p}><path d="M5 12h14"/></CdSvg>; }
function CheckIcon(p)     { return <CdSvg {...p}><path d="m4.5 12.5 5 5L19.5 7"/></CdSvg>; }
function ArrowLeftIcon(p) { return <CdSvg {...p}><path d="M19 12H5"/><path d="m11 6-6 6 6 6"/></CdSvg>; }
function TagIcon(p)       { return <CdSvg {...p}><path d="M3 11V4a1 1 0 0 1 1-1h7l10 10-8 8z"/><circle cx="8" cy="8" r="1.4"/></CdSvg>; }
function SparkIcon(p)     { return <CdSvg {...p}><path d="M12 3l1.9 5.6L19.5 10l-5.6 1.9L12 17.5l-1.9-5.6L4.5 10l5.6-1.4z"/></CdSvg>; }
function CrownIcon(p)     { return <CdSvg {...p}><path d="M4 18h16l1-10-5 3.5L12 5 8 11.5 3 8z"/></CdSvg>; }
function WalletIcon(p)    { return <CdSvg {...p}><rect x="3" y="6" width="18" height="13" rx="2.5"/><path d="M3 10h18"/></CdSvg>; }
function TrendUpIcon(p)   { return <CdSvg {...p}><path d="m4 16 6-6 3 3 7-7"/><path d="M20 11V6h-5"/></CdSvg>; }
function TrendDownIcon(p) { return <CdSvg {...p}><path d="m4 8 6 6 3-3 7 7"/><path d="M20 13v5h-5"/></CdSvg>; }

// ---- SuperBadge ----
const CD_SUPER_COLORS = {
  continente:  { bg:'oklch(95% 0.035 30)',  text:'oklch(40% 0.13 30)'  },
  pingodoce:   { bg:'oklch(95% 0.04 150)', text:'oklch(34% 0.13 150)' },
  lidl:        { bg:'oklch(94% 0.04 262)', text:'oklch(38% 0.13 262)' },
  aldi:        { bg:'oklch(94% 0.035 230)', text:'oklch(38% 0.12 230)' },
  mercadona:   { bg:'oklch(95% 0.04 175)', text:'oklch(35% 0.1 175)'  },
  intermarche: { bg:'oklch(95% 0.035 20)', text:'oklch(40% 0.12 20)'  },
};
function SuperBadge({ id, name, size=38 }) {
  const c = CD_SUPER_COLORS[id] || { bg:CD.lineSoft, text:CD.ink2 };
  return <div aria-hidden="true" style={{ width:size, height:size, borderRadius:'32%', background:c.bg, color:c.text, display:'flex', alignItems:'center', justifyContent:'center', fontSize:size*.42, fontWeight:800, flexShrink:0, letterSpacing:'-0.02em' }}>{(name||'?')[0]}</div>;
}

// ---- Sparkline (smooth bezier + gradient fill) ----
let _sparklineCounter = 0;
function Sparkline({ values, color, width=72, height=34 }) {
  const gid = React.useRef('sg-' + (++_sparklineCounter)).current;
  if (!values || values.length < 2) return null;
  const min = Math.min(...values), max = Math.max(...values);
  const rng = max - min || 1;
  const pad = 4;
  const h = height - pad * 2;
  const pts = values.map((v, i) => [
    (i / (values.length - 1)) * width,
    pad + h - ((v - min) / rng) * h,
  ]);
  const line = pts.map((p, i) => {
    if (i === 0) return `M${p[0]},${p[1]}`;
    const prev = pts[i - 1];
    const mx = (prev[0] + p[0]) / 2;
    return `C${mx},${prev[1]} ${mx},${p[1]} ${p[0]},${p[1]}`;
  }).join(' ');
  const fill = line + ` L${pts[pts.length-1][0]},${height} L${pts[0][0]},${height} Z`;
  return (
    <svg width={width} height={height} viewBox={`0 0 ${width} ${height}`} style={{ flexShrink:0 }} aria-hidden="true">
      <defs>
        <linearGradient id={gid} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.22"/>
          <stop offset="100%" stopColor={color} stopOpacity="0"/>
        </linearGradient>
      </defs>
      <path d={fill} fill={`url(#${gid})`}/>
      <path d={line} fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      <circle cx={pts[pts.length-1][0]} cy={pts[pts.length-1][1]} r="2.5" fill={color}/>
    </svg>
  );
}

// ---- Shared primitives ----
function euro(n) { return Number(n).toFixed(2).replace('.', ',') + '\u00a0€'; }
function Card({ children, style={}, onClick }) {
  return <div onClick={onClick} style={{ background:CD.surface, borderRadius:18, padding:16, boxShadow:CD.shadow, cursor:onClick?'pointer':'default', ...style }}>{children}</div>;
}
function Pill({ children, bg, color, style={} }) {
  return <span style={{ display:'inline-flex', alignItems:'center', gap:4, padding:'3px 9px', borderRadius:100, background:bg, color, fontSize:11.5, fontWeight:700, letterSpacing:'0.01em', whiteSpace:'nowrap', ...style }}>{children}</span>;
}
function PrimaryButton({ children, onClick, theme, disabled, style={} }) {
  return <button onClick={onClick} disabled={disabled} style={{ width:'100%', minHeight:52, border:'none', borderRadius:14, background:disabled?CD.line:theme.primary, color:disabled?CD.ink3:'#fff', fontSize:16, fontWeight:700, fontFamily:'inherit', cursor:disabled?'default':'pointer', display:'flex', alignItems:'center', justifyContent:'center', gap:8, transition:'transform 0.1s ease', ...style }}
    onMouseDown={e=>{ if(!disabled) e.currentTarget.style.transform='scale(0.985)'; }}
    onMouseUp={e=>{ e.currentTarget.style.transform='scale(1)'; }}
    onMouseLeave={e=>{ e.currentTarget.style.transform='scale(1)'; }}
  >{children}</button>;
}
function GhostButton({ children, onClick, style={} }) {
  return <button onClick={onClick} style={{ width:'100%', minHeight:48, borderRadius:14, border:`1.5px solid ${CD.line}`, background:'transparent', color:CD.ink, fontSize:15, fontWeight:600, fontFamily:'inherit', cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center', gap:8, ...style }}>{children}</button>;
}
function QtyStepper({ qty, onChange, theme }) {
  return (
    <div style={{ display:'flex', alignItems:'center', gap:0, background:CD.lineSoft, borderRadius:100 }}>
      <button onClick={()=>onChange(-1)} style={{ width:34, height:34, border:'none', background:'transparent', cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center', color:CD.ink2, borderRadius:100 }}><MinusIcon size={16}/></button>
      <span style={{ minWidth:22, textAlign:'center', fontSize:14.5, fontWeight:700, color:CD.ink, fontVariantNumeric:'tabular-nums' }}>{qty}</span>
      <button onClick={()=>onChange(1)} style={{ width:34, height:34, border:'none', background:'transparent', cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center', color:theme.primary, borderRadius:100 }}><PlusIcon size={16}/></button>
    </div>
  );
}
function TabBar({ current, onChange, cartCount, theme }) {
  const tabs = [
    { id:'home',    Icon:HomeIcon,    label:'Início' },
    { id:'cart',    Icon:BasketIcon,  label:'Carrinho', badge:cartCount },
    { id:'analysis',Icon:CompassIcon, label:'Análise' },
    { id:'profile', Icon:PersonIcon,  label:'Perfil' },
  ];
  return (
    <nav style={{ position:'absolute', bottom:0, left:0, right:0, background:'rgba(255,255,255,0.94)', backdropFilter:'blur(16px)', WebkitBackdropFilter:'blur(16px)', borderTop:`1px solid ${CD.lineSoft}`, display:'flex', zIndex:60, paddingBottom:'max(env(safe-area-inset-bottom),6px)', paddingTop:6 }}>
      {tabs.map(({ id, Icon, label, badge }) => {
        const active = current===id || (id==='cart' && current==='analyzing');
        return (
          <button key={id} onClick={()=>onChange(id)} style={{ flex:1, minHeight:50, border:'none', background:'none', cursor:'pointer', display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', gap:3, color:active?theme.primary:CD.ink3, position:'relative', fontFamily:'inherit' }}>
            <span style={{ position:'relative', display:'inline-flex' }}>
              <Icon size={23} color={active?theme.primary:CD.ink3}/>
              {badge>0 && <span style={{ position:'absolute', top:-4, right:-8, minWidth:16, height:16, borderRadius:100, background:theme.primary, color:'#fff', fontSize:9.5, fontWeight:800, display:'flex', alignItems:'center', justifyContent:'center', padding:'0 4px' }}>{badge}</span>}
            </span>
            <span style={{ fontSize:10.5, fontWeight:active?700:500, letterSpacing:'0.01em' }}>{label}</span>
          </button>
        );
      })}
    </nav>
  );
}
function ScreenHeader({ title, subtitle, onBack, right }) {
  return (
    <header style={{ display:'flex', alignItems:'center', gap:12, padding:'18px 20px 8px' }}>
      {onBack && <button onClick={onBack} style={{ width:38, height:38, borderRadius:12, border:`1px solid ${CD.line}`, background:CD.surface, cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center', color:CD.ink, flexShrink:0 }}><ArrowLeftIcon size={18}/></button>}
      <div style={{ flex:1, minWidth:0 }}>
        <h1 style={{ margin:0, fontSize:21, fontWeight:800, color:CD.ink, letterSpacing:'-0.02em' }}>{title}</h1>
        {subtitle && <p style={{ margin:'2px 0 0', fontSize:13, color:CD.ink2 }}>{subtitle}</p>}
      </div>
      {right}
    </header>
  );
}

// ---- PhoneFrame ----
function PhoneFrame({ children }) {
  const [scale, setScale] = useUIV2(1);
  useLV2(() => {
    const fit = () => {
      const sx = (window.innerWidth  - 32) / 390;
      const sy = (window.innerHeight - 32) / 844;
      setScale(Math.min(1.06, Math.max(0.38, Math.min(sx, sy))));
    };
    fit();
    window.addEventListener('resize', fit);
    return () => window.removeEventListener('resize', fit);
  }, []);
  return (
    <div style={{ position:'fixed', inset:0, display:'flex', alignItems:'center', justifyContent:'center',
      background:'radial-gradient(900px at 15% -5%, oklch(94% 0.018 148), transparent 55%), radial-gradient(700px at 115% 110%, oklch(93% 0.014 152), transparent 52%), oklch(91% 0.016 148)' }}>
      <div style={{ transformOrigin:'center', transform:`scale(${scale})` }}>
        <div style={{ width:390, height:844, background:'#111518', borderRadius:54, padding:11,
          boxShadow:'0 52px 90px -28px rgba(8,22,14,0.62), 0 0 0 1px rgba(255,255,255,0.08) inset' }}>
          <div style={{ position:'relative', width:'100%', height:'100%', background:CD.bg, borderRadius:44, overflow:'hidden' }}>
            <div style={{ position:'absolute', top:13, left:'50%', transform:'translateX(-50%)', width:100, height:28, background:'#111518', borderRadius:16, zIndex:50, pointerEvents:'none' }}/>
            <CDStatusBar/>
            {children}
            <div style={{ position:'absolute', bottom:8, left:'50%', transform:'translateX(-50%)', width:130, height:5, borderRadius:3, background:CD.ink, opacity:0.2, zIndex:50, pointerEvents:'none' }}/>
          </div>
        </div>
      </div>
    </div>
  );
}

// ---- Status bar ----
function CDStatusBar() {
  const now = new Date();
  const time = `${String(now.getHours()).padStart(2,'0')}:${String(now.getMinutes()).padStart(2,'0')}`;
  return (
    <div style={{ position:'absolute', top:0, left:0, right:0, height:50, display:'flex', alignItems:'center', justifyContent:'space-between', padding:'0 26px', zIndex:45, pointerEvents:'none', fontFamily:"'DM Sans',sans-serif", fontWeight:800, fontSize:14, color:CD.ink }}>
      <span>{time}</span>
      <div style={{ display:'flex', alignItems:'center', gap:5 }}>
        <span style={{ fontSize:11, fontWeight:800 }}>5G</span>
        <svg width="24" height="11" viewBox="0 0 24 11" aria-hidden="true">
          {[0,1,2,3].map(i => <rect key={i} x={i*6} y={10-(i*2.5)} width="5" height={i*2.5+3} rx="1.2" fill={CD.ink} opacity={i>1?0.85:0.35}/>)}
        </svg>
        <div style={{ width:23, height:12, border:`1.5px solid ${CD.ink}`, borderRadius:3, position:'relative', opacity:0.85 }}>
          <div style={{ position:'absolute', top:2, left:2, width:'70%', height:'calc(100% - 4px)', background:CD.ink, borderRadius:1 }}/>
          <div style={{ position:'absolute', top:'50%', right:-4, transform:'translateY(-50%)', width:3, height:6, background:CD.ink, borderRadius:'0 1.5px 1.5px 0' }}/>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, {
  CD_THEMES, CD, CD_SUPER_COLORS,
  HomeIcon, BasketIcon, CompassIcon, PersonIcon, SearchIcon, PlusIcon, MinusIcon,
  CheckIcon, ArrowLeftIcon, TagIcon, SparkIcon, CrownIcon, WalletIcon, TrendUpIcon, TrendDownIcon,
  SuperBadge, Sparkline, euro, Card, Pill, PrimaryButton, GhostButton, QtyStepper,
  TabBar, ScreenHeader, PhoneFrame, CDStatusBar,
});
