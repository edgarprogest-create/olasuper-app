// CestoDoce — Ecrãs: Início, Carrinho, Análise, Perfil + Paywall
(function () {
const { useState, useEffect, useMemo, useRef } = React;
const D = window.CestoDoceData;

// ============ INÍCIO ============
function HomeScreen({ theme, onNewCart, cartCount }) {
  const rankings = useMemo(() => D.getWeeklyRanking(), []);
  // vencedor global da semana: loja com mais 1.ºs lugares
  const winCounts = {};
  rankings.forEach(r => {
    const w = r.ranking[0].supermarket.id;
    winCounts[w] = (winCounts[w] || 0) + 1;
  });
  const overallId = Object.keys(winCounts).sort((a, b) => winCounts[b] - winCounts[a])[0];
  const overall = D.SUPERMARKETS.find(s => s.id === overallId);
  const promoCat = rankings.find(r => r.ranking[0].promoCount > 0);

  return (
    <div data-screen-label="Início — ranking semanal">
      <header style={{ padding: '22px 20px 4px' }}>
        <p style={{ margin: 0, fontSize: 13, fontWeight: 600, color: CD.ink3, textTransform: 'uppercase', letterSpacing: '0.08em' }}>Semana de 8–14 junho</p>
        <h1 style={{ margin: '4px 0 0', fontSize: 26, fontWeight: 800, color: CD.ink, letterSpacing: '-0.025em' }}>Onde poupar esta semana</h1>
      </header>

      {/* Hero: vencedor da semana */}
      <section style={{ padding: '14px 20px 0' }}>
        <Card style={{ background: theme.primaryDark, color: '#fff', padding: 20, position: 'relative', overflow: 'hidden' }}>
          <div style={{ position: 'absolute', right: -30, top: -30, width: 140, height: 140, borderRadius: '50%', background: 'rgba(255,255,255,0.06)' }}></div>
          <div style={{ position: 'absolute', right: 10, bottom: -50, width: 110, height: 110, borderRadius: '50%', background: 'rgba(255,255,255,0.05)' }}></div>
          <Pill bg="rgba(255,255,255,0.16)" color="#fff" style={{ marginBottom: 12 }}>
            <CrownIcon size={13} color="#fff" /> Cesto da semana
          </Pill>
          <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
            <SuperBadge id={overall.id} name={overall.name} size={48} />
            <div>
              <div style={{ fontSize: 22, fontWeight: 800, letterSpacing: '-0.02em' }}>{overall.name}</div>
              <div style={{ fontSize: 13, opacity: 0.85, marginTop: 2 }}>Mais barato em {winCounts[overallId]} de {rankings.length} categorias</div>
            </div>
          </div>
          {promoCat && (
            <div style={{ marginTop: 14, paddingTop: 14, borderTop: '1px solid rgba(255,255,255,0.15)', fontSize: 13.5, lineHeight: 1.45, opacity: 0.92 }}>
              <strong>{promoCat.ranking[0].supermarket.name}</strong> tem {promoCat.ranking[0].promoCount} promoções em {promoCat.category.name} — vale a pena dividir o cesto.
            </div>
          )}
        </Card>
      </section>

      {/* CTA novo carrinho */}
      <section style={{ padding: '16px 20px 0' }}>
        <PrimaryButton theme={theme} onClick={onNewCart}>
          <BasketIcon size={19} color="#fff" />
          {cartCount > 0 ? `Continuar carrinho (${cartCount})` : 'Criar carrinho de compras'}
        </PrimaryButton>
      </section>

      {/* Rankings por categoria */}
      <section style={{ padding: '26px 20px 16px' }}>
        <h2 style={{ margin: '0 0 12px', fontSize: 16.5, fontWeight: 800, color: CD.ink, letterSpacing: '-0.01em' }}>Ranking por categoria</h2>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {rankings.map(({ category, ranking }) => (
            <Card key={category.id} style={{ padding: '14px 16px' }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
                <span style={{ fontSize: 14.5, fontWeight: 700, color: CD.ink }}>{category.name}</span>
                <span style={{ fontSize: 11.5, color: CD.ink3, fontWeight: 500 }}>preço médio</span>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                {ranking.slice(0, 3).map((r, i) => (
                  <div key={r.supermarket.id} style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                    <span style={{
                      width: 22, height: 22, borderRadius: '50%', flexShrink: 0,
                      background: i === 0 ? CD.goldBg : CD.lineSoft,
                      color: i === 0 ? CD.goldInk : CD.ink3,
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                      fontSize: 11, fontWeight: 800,
                    }}>{i + 1}</span>
                    <SuperBadge id={r.supermarket.id} name={r.supermarket.name} size={28} />
                    <span style={{ flex: 1, fontSize: 14, fontWeight: i === 0 ? 700 : 500, color: i === 0 ? CD.ink : CD.ink2, display: 'flex', alignItems: 'center', gap: 6 }}>
                      {r.supermarket.name}
                      {r.promoCount > 0 && <Pill bg={CD.promoBg} color={CD.promo}><TagIcon size={11} color={CD.promo} />{r.promoCount} promo{r.promoCount > 1 ? 's' : ''}</Pill>}
                    </span>
                    {r.trend !== 0 && (
                      r.trend < 0
                        ? <TrendDownIcon size={15} color={theme.savings} />
                        : <TrendUpIcon size={15} color={CD.promo} />
                    )}
                    <span style={{ fontSize: 13.5, fontWeight: 600, color: CD.ink2, fontVariantNumeric: 'tabular-nums' }}>{euro(r.avg)}</span>
                  </div>
                ))}
              </div>
            </Card>
          ))}
        </div>
        <p style={{ margin: '14px 4px 0', fontSize: 11.5, color: CD.ink3, lineHeight: 1.5 }}>
          Preços médios do cabaz CestoDoce, atualizados semanalmente. Dados de demonstração.
        </p>
      </section>
    </div>
  );
}

// ============ CARRINHO ============
function CartScreen({ theme, cart, onChangeQty, onAdd, onAnalyse, plan, usageLeft }) {
  const [query, setQuery] = useState('');
  const results = useMemo(() => {
    if (!query.trim()) return [];
    const q = query.trim().toLowerCase();
    return D.PRODUCTS.filter(p => p.name.toLowerCase().includes(q)).slice(0, 6);
  }, [query]);

  const cartProducts = cart.map(it => ({ ...it, product: D.PRODUCTS.find(p => p.id === it.productId) })).filter(x => x.product);
  const bestTotal = useMemo(() => {
    if (cart.length === 0) return 0;
    const r = D.compareCart(cart);
    return r ? r.splitTotal : 0;
  }, [cart]);
  const inCart = id => cart.find(i => i.productId === id);

  return (
    <div data-screen-label="Carrinho — criação e pesquisa">
      <ScreenHeader title="O teu carrinho" subtitle={cart.length ? `${cartProducts.reduce((s, i) => s + i.qty, 0)} artigos · melhor total ${euro(bestTotal)}` : 'Adiciona produtos para comparar preços'} />

      {/* Pesquisa */}
      <div style={{ padding: '8px 20px 0', position: 'relative', zIndex: 30 }}>
        <div style={{
          display: 'flex', alignItems: 'center', gap: 10, background: CD.surface,
          border: `1.5px solid ${query ? theme.primary : CD.line}`, borderRadius: 14, padding: '0 14px',
          transition: 'border-color 0.15s ease',
        }}>
          <SearchIcon size={18} color={CD.ink3} />
          <input
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder="Pesquisar produto… ex: leite, frango"
            style={{
              flex: 1, border: 'none', outline: 'none', background: 'transparent',
              fontSize: 15, fontFamily: 'inherit', color: CD.ink, height: 48,
            }}
          />
          {query && (
            <button onClick={() => setQuery('')} aria-label="Limpar" style={{ border: 'none', background: 'none', cursor: 'pointer', color: CD.ink3, fontSize: 13, fontWeight: 600, fontFamily: 'inherit' }}>Limpar</button>
          )}
        </div>

        {results.length > 0 && (
          <div style={{
            position: 'absolute', left: 20, right: 20, top: 56,
            background: CD.surface, borderRadius: 14, boxShadow: CD.shadowLift,
            overflow: 'hidden', border: `1px solid ${CD.lineSoft}`,
          }}>
            {results.map(p => {
              const cheapest = D.SUPERMARKETS.reduce((b, s) => p.prices[s.id] < p.prices[b.id] ? s : b);
              const added = inCart(p.id);
              return (
                <button key={p.id} onClick={() => { onAdd(p.id); setQuery(''); }} style={{
                  display: 'flex', alignItems: 'center', gap: 12, width: '100%',
                  padding: '11px 14px', border: 'none', background: 'none', cursor: 'pointer',
                  borderBottom: `1px solid ${CD.lineSoft}`, fontFamily: 'inherit', textAlign: 'left',
                }}>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: 14.5, fontWeight: 600, color: CD.ink }}>{p.name}</div>
                    <div style={{ fontSize: 12, color: CD.ink2, marginTop: 1 }}>
                      desde {euro(p.prices[cheapest.id])} · {cheapest.name}
                      {p.promo && p.promo[cheapest.id] && <span style={{ color: CD.promo, fontWeight: 700 }}> · promo</span>}
                    </div>
                  </div>
                  <span style={{
                    width: 30, height: 30, borderRadius: 100, flexShrink: 0,
                    background: added ? theme.primarySoft : theme.primary,
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                  }}>
                    {added ? <CheckIcon size={15} color={theme.primary} /> : <PlusIcon size={15} color="#fff" />}
                  </span>
                </button>
              );
            })}
          </div>
        )}
      </div>

      {/* Lista do carrinho */}
      <div style={{ padding: '18px 20px 130px' }}>
        {cartProducts.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '48px 24px', color: CD.ink3 }}>
            <BasketIcon size={44} color={CD.line} />
            <p style={{ fontSize: 14.5, lineHeight: 1.5, margin: '14px 0 0' }}>O carrinho está vazio.<br />Pesquisa produtos acima para começar.</p>
          </div>
        ) : (
          <Card style={{ padding: '4px 16px' }}>
            {cartProducts.map((it, idx) => {
              const cheapest = D.SUPERMARKETS.reduce((b, s) => it.product.prices[s.id] < it.product.prices[b.id] ? s : b);
              const isPromo = it.product.promo && it.product.promo[cheapest.id];
              return (
                <div key={it.productId} style={{
                  display: 'flex', alignItems: 'center', gap: 12, padding: '13px 0',
                  borderBottom: idx < cartProducts.length - 1 ? `1px solid ${CD.lineSoft}` : 'none',
                }}>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: 14.5, fontWeight: 600, color: CD.ink, display: 'flex', alignItems: 'center', gap: 6, flexWrap: 'wrap' }}>
                      {it.product.name}
                      {isPromo && <Pill bg={CD.promoBg} color={CD.promo}>promo</Pill>}
                    </div>
                    <div style={{ fontSize: 12.5, color: CD.ink2, marginTop: 2 }}>
                      melhor: {euro(it.product.prices[cheapest.id])} · {cheapest.name}
                    </div>
                  </div>
                  <QtyStepper qty={it.qty} theme={theme} onChange={d => onChangeQty(it.productId, d)} />
                </div>
              );
            })}
          </Card>
        )}
      </div>

      {/* CTA fixo */}
      {cartProducts.length > 0 && (
        <div style={{
          position: 'absolute', left: 0, right: 0, bottom: 62, padding: '12px 20px 14px',
          background: 'linear-gradient(to top, rgba(250,251,250,1) 65%, rgba(250,251,250,0))', zIndex: 50,
        }}>
          <PrimaryButton theme={theme} onClick={onAnalyse}>
            <SparkIcon size={18} color="#fff" />
            Analisar carrinho
          </PrimaryButton>
          <p style={{ textAlign: 'center', fontSize: 12, color: CD.ink3, margin: '8px 0 0' }}>
            {plan === 'member' ? 'Análises ilimitadas · CestoDoce Member' : usageLeft > 0 ? `${usageLeft} análise gratuita disponível este mês` : 'Limite mensal gratuito atingido'}
          </p>
        </div>
      )}
    </div>
  );
}

// ============ ANÁLISE ============
function AnalysisScreen({ theme, result, onBack, onGoCart }) {
  if (!result) {
    return (
      <div data-screen-label="Análise — vazio">
        <ScreenHeader title="Análise" />
        <div style={{ textAlign: 'center', padding: '64px 32px', color: CD.ink3 }}>
          <CompassIcon size={44} color={CD.line} />
          <p style={{ fontSize: 14.5, lineHeight: 1.55, margin: '14px 0 18px' }}>Ainda não fizeste nenhuma análise.<br />Cria um carrinho e descobre onde poupar.</p>
          <GhostButton onClick={onGoCart} style={{ maxWidth: 240, margin: '0 auto' }}>Ir para o carrinho</GhostButton>
        </div>
      </div>
    );
  }

  const r = result;
  const split = r.shouldSplit;

  return (
    <div data-screen-label="Análise — resultado da comparação">
      <ScreenHeader title="Resultado da análise" subtitle={`${r.totalItems} artigos comparados em ${D.SUPERMARKETS.length} supermercados`} onBack={onBack} />

      {/* Hero de poupança */}
      <section style={{ padding: '10px 20px 0' }}>
        <Card style={{ textAlign: 'center', padding: '26px 20px 22px', background: theme.primarySoft, boxShadow: 'none', border: `1.5px solid ${CD.lineSoft}` }}>
          {split ? (
            <div>
              <Pill bg={theme.primary} color="#fff" style={{ marginBottom: 14 }}>
                <SparkIcon size={13} color="#fff" /> Divisão inteligente recomendada
              </Pill>
              <div style={{ fontSize: 14, fontWeight: 600, color: CD.ink2 }}>Dividindo em {r.splitGroups.length} lojas, poupas</div>
              <div style={{ fontSize: 52, fontWeight: 800, color: theme.savings, letterSpacing: '-0.04em', lineHeight: 1.15, margin: '4px 0 2px', fontVariantNumeric: 'tabular-nums' }}>
                <AnimatedEuro value={r.savings} />
              </div>
              <div style={{ fontSize: 13.5, color: CD.ink2 }}>
                −{String(r.savingsPct).replace('.', ',')}% vs comprar tudo no {r.bestSingle.name} ({euro(r.singleTotal)})
              </div>
            </div>
          ) : (
            <div>
              <Pill bg={theme.primary} color="#fff" style={{ marginBottom: 14 }}>
                <CheckIcon size={13} color="#fff" /> Uma loja chega
              </Pill>
              <div style={{ fontSize: 14, fontWeight: 600, color: CD.ink2 }}>Compra tudo no</div>
              <div style={{ fontSize: 34, fontWeight: 800, color: CD.ink, letterSpacing: '-0.03em', margin: '4px 0 2px' }}>{r.bestSingle.name}</div>
              <div style={{ fontSize: 14, color: CD.ink2 }}>Total: <strong>{euro(r.singleTotal)}</strong> · dividir pouparia só {euro(Math.max(r.savings, 0))}</div>
            </div>
          )}
        </Card>
      </section>

      {/* Listas por loja */}
      <section style={{ padding: '16px 20px 0', display: 'flex', flexDirection: 'column', gap: 12 }}>
        {(split ? r.splitGroups : [{ supermarket: r.bestSingle, items: null, subtotal: r.singleTotal }]).map(group => (
          <Card key={group.supermarket.id} style={{ padding: 0, overflow: 'hidden' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '14px 16px', borderBottom: `1px solid ${CD.lineSoft}` }}>
              <SuperBadge id={group.supermarket.id} name={group.supermarket.name} size={36} />
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 15.5, fontWeight: 800, color: CD.ink }}>{group.supermarket.name}</div>
                {group.items && <div style={{ fontSize: 12, color: CD.ink2 }}>{group.items.reduce((s, i) => s + i.qty, 0)} artigos</div>}
              </div>
              <div style={{ fontSize: 17, fontWeight: 800, color: CD.ink, fontVariantNumeric: 'tabular-nums' }}>{euro(group.subtotal)}</div>
            </div>
            {group.items && (
              <div style={{ padding: '6px 16px 10px' }}>
                {group.items.map(it => (
                  <div key={it.productId} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '7px 0', fontSize: 13.5 }}>
                    <span style={{ color: CD.ink, flex: 1, display: 'flex', gap: 6, alignItems: 'center', flexWrap: 'wrap' }}>
                      {it.product.name}{it.qty > 1 ? ` ×${it.qty}` : ''}
                      {it.isPromo && <Pill bg={CD.promoBg} color={CD.promo}>promo</Pill>}
                    </span>
                    <span style={{ color: CD.ink2, fontWeight: 600, fontVariantNumeric: 'tabular-nums' }}>{euro(it.unitPrice * it.qty)}</span>
                  </div>
                ))}
              </div>
            )}
          </Card>
        ))}
      </section>

      {/* Contexto extra */}
      <section style={{ padding: '16px 20px 110px' }}>
        <Card style={{ padding: '14px 16px', boxShadow: 'none', border: `1.5px solid ${CD.lineSoft}`, background: 'transparent' }}>
          <div style={{ fontSize: 12.5, fontWeight: 700, color: CD.ink3, textTransform: 'uppercase', letterSpacing: '0.07em', marginBottom: 10 }}>Se comprasses tudo numa só loja</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {r.allTotals.map((t, i) => (
              <div key={t.supermarket.id} style={{ display: 'flex', alignItems: 'center', gap: 10, fontSize: 13.5 }}>
                <SuperBadge id={t.supermarket.id} name={t.supermarket.name} size={24} />
                <span style={{ flex: 1, color: i === 0 ? CD.ink : CD.ink2, fontWeight: i === 0 ? 700 : 500 }}>{t.supermarket.name}</span>
                {i === 0 && <Pill bg={CD.goldBg} color={CD.goldInk}>mais barato</Pill>}
                <span style={{ fontWeight: 600, color: i === 0 ? CD.ink : CD.ink2, fontVariantNumeric: 'tabular-nums' }}>{euro(t.total)}</span>
              </div>
            ))}
          </div>
          {split && (
            <div style={{ marginTop: 12, paddingTop: 12, borderTop: `1px solid ${CD.lineSoft}`, fontSize: 13, color: CD.ink2, lineHeight: 1.5 }}>
              A tua divisão fica em <strong style={{ color: theme.savings }}>{euro(r.splitTotal)}</strong> — menos {euro(r.worstSingleTotal - r.splitTotal)} do que no {r.worstSingle.name}.
            </div>
          )}
        </Card>
      </section>
    </div>
  );
}

// ============ PERFIL ============
function ProfileScreen({ theme, plan, usageUsed, usageLimit, lastSavings, onUpgrade }) {
  const isMember = plan === 'member';
  return (
    <div data-screen-label="Perfil — conta e plano">
      <ScreenHeader title="Perfil" />
      <div style={{ padding: '8px 20px 110px', display: 'flex', flexDirection: 'column', gap: 12 }}>
        <Card style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
          <div style={{
            width: 52, height: 52, borderRadius: '50%', background: theme.primarySoft,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 20, fontWeight: 800, color: theme.primary,
          }}>M</div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 16.5, fontWeight: 800, color: CD.ink }}>Maria Santos</div>
            <div style={{ fontSize: 13, color: CD.ink2 }}>maria.santos@email.pt</div>
          </div>
          {isMember
            ? <Pill bg={CD.memberBg} color={CD.member}><CrownIcon size={12} color={CD.member} /> Member</Pill>
            : <Pill bg={CD.lineSoft} color={CD.ink2}>Gratuito</Pill>}
        </Card>

        {/* Uso mensal */}
        <Card>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
            <span style={{ fontSize: 14.5, fontWeight: 700, color: CD.ink }}>Análises este mês</span>
            <span style={{ fontSize: 13.5, fontWeight: 700, color: CD.ink2, fontVariantNumeric: 'tabular-nums' }}>
              {isMember ? `${usageUsed} · ilimitadas` : `${usageUsed} / ${usageLimit}`}
            </span>
          </div>
          <div style={{ height: 8, borderRadius: 100, background: CD.lineSoft, overflow: 'hidden' }}>
            <div style={{
              height: '100%', borderRadius: 100, background: theme.primary,
              width: isMember ? '100%' : `${Math.min(usageUsed / usageLimit, 1) * 100}%`,
              opacity: isMember ? 0.35 : 1, transition: 'width 0.4s ease',
            }}></div>
          </div>
          <p style={{ margin: '10px 0 0', fontSize: 12.5, color: CD.ink3 }}>
            {isMember ? 'Sem limites — analisa sempre que quiseres.' : 'O plano gratuito renova a 1 de julho.'}
          </p>
        </Card>

        {lastSavings != null && lastSavings > 0 && (
          <Card style={{ background: theme.primarySoft, boxShadow: 'none', border: `1.5px solid ${CD.lineSoft}` }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <WalletIcon size={26} color={theme.savings} />
              <div>
                <div style={{ fontSize: 14, color: CD.ink2 }}>Poupança na última análise</div>
                <div style={{ fontSize: 22, fontWeight: 800, color: theme.savings, letterSpacing: '-0.02em' }}>{euro(lastSavings)}</div>
              </div>
            </div>
          </Card>
        )}

        {!isMember && (
          <Card style={{ padding: 18 }}>
            <Pill bg={CD.memberBg} color={CD.member} style={{ marginBottom: 12 }}>
              <CrownIcon size={12} color={CD.member} /> CestoDoce Member
            </Pill>
            <h3 style={{ margin: '0 0 10px', fontSize: 17, fontWeight: 800, color: CD.ink, letterSpacing: '-0.015em' }}>Poupa em todas as compras, não só uma vez por mês</h3>
            <ul style={{ margin: '0 0 16px', padding: 0, listStyle: 'none', display: 'flex', flexDirection: 'column', gap: 8 }}>
              {['Análises ilimitadas', 'Alertas de promoções da semana', 'Histórico de poupanças'].map(b => (
                <li key={b} style={{ display: 'flex', alignItems: 'center', gap: 9, fontSize: 14, color: CD.ink2 }}>
                  <CheckIcon size={15} color={theme.savings} /> {b}
                </li>
              ))}
            </ul>
            <PrimaryButton theme={theme} onClick={onUpgrade}>Tornar-me Member · 1 €/mês</PrimaryButton>
          </Card>
        )}

        <p style={{ margin: '4px 4px 0', fontSize: 11.5, color: CD.ink3, lineHeight: 1.5 }}>
          Protótipo de demonstração — conta e pagamentos simulados.
        </p>
      </div>
    </div>
  );
}

// ============ PAYWALL (folha modal) ============
function PaywallSheet({ theme, lastSavings, onSubscribe, onClose }) {
  const [step, setStep] = useState('offer'); // offer | paying | success
  const [method, setMethod] = useState(null);

  function pay(m) {
    setMethod(m);
    setStep('paying');
    setTimeout(() => setStep('success'), 1400);
  }

  useEffect(() => {
    if (step === 'success') {
      const t = setTimeout(onSubscribe, 1200);
      return () => clearTimeout(t);
    }
  }, [step]);

  return (
    <div style={{
      position: 'absolute', inset: 0, zIndex: 200,
      background: 'rgba(15,25,18,0.45)', display: 'flex', alignItems: 'flex-end',
      animation: 'cdFadeIn 0.2s ease',
    }} onClick={step === 'offer' ? onClose : undefined}>
      <div onClick={e => e.stopPropagation()} style={{
        width: '100%', background: CD.surface, borderRadius: '24px 24px 0 0',
        padding: '12px 22px calc(max(env(safe-area-inset-bottom), 10px) + 14px)',
        animation: 'cdSlideUp 0.32s cubic-bezier(0.32, 0.72, 0, 1)', maxHeight: '88%', overflowY: 'auto',
      }} data-screen-label="Paywall — CestoDoce Member">
        <div style={{ width: 40, height: 4, borderRadius: 100, background: CD.line, margin: '0 auto 18px' }}></div>

        {step === 'offer' && (
          <div>
            <Pill bg={CD.memberBg} color={CD.member} style={{ marginBottom: 12 }}>
              <CrownIcon size={12} color={CD.member} /> CestoDoce Member
            </Pill>
            <h2 style={{ margin: '0 0 6px', fontSize: 23, fontWeight: 800, color: CD.ink, letterSpacing: '-0.025em', lineHeight: 1.2 }}>
              Usaste a tua análise gratuita deste mês
            </h2>
            <p style={{ margin: '0 0 16px', fontSize: 14.5, color: CD.ink2, lineHeight: 1.5 }}>
              Continua a poupar com análises ilimitadas — por menos do que um café por mês.
            </p>

            {lastSavings != null && lastSavings > 0 && (
              <div style={{
                background: theme.primarySoft, borderRadius: 14, padding: '13px 16px',
                display: 'flex', alignItems: 'center', gap: 12, marginBottom: 16,
              }}>
                <WalletIcon size={24} color={theme.savings} />
                <div style={{ fontSize: 13.5, color: CD.ink2, lineHeight: 1.45 }}>
                  Na tua última análise poupaste <strong style={{ color: theme.savings }}>{euro(lastSavings)}</strong> — a subscrição paga-se numa só compra.
                </div>
              </div>
            )}

            <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 18 }}>
              {['Análises ilimitadas todos os meses', 'Alertas de promoções da semana', 'Histórico de poupanças', 'Cancela a qualquer momento'].map(b => (
                <div key={b} style={{ display: 'flex', alignItems: 'center', gap: 9, fontSize: 14, color: CD.ink2 }}>
                  <CheckIcon size={15} color={theme.savings} /> {b}
                </div>
              ))}
            </div>

            <div style={{ textAlign: 'center', marginBottom: 14 }}>
              <span style={{ fontSize: 34, fontWeight: 800, color: CD.ink, letterSpacing: '-0.03em' }}>1 €</span>
              <span style={{ fontSize: 15, color: CD.ink2, fontWeight: 600 }}> / mês</span>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: 9 }}>
              <button onClick={() => pay('applepay')} style={{
                minHeight: 52, borderRadius: 14, border: 'none', background: '#000', color: '#fff',
                fontSize: 16, fontWeight: 700, fontFamily: 'inherit', cursor: 'pointer',
                display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 7,
              }}>
                <svg width="17" height="20" viewBox="0 0 17 20" fill="#fff" aria-hidden="true"><path d="M13.9 10.6c0-2.4 2-3.6 2.1-3.6-1.1-1.7-2.9-1.9-3.5-1.9-1.5-.2-2.9.9-3.7.9-.8 0-1.9-.9-3.2-.8C4 5.2 2.5 6.1 1.7 7.6c-1.7 3-.4 7.4 1.2 9.8.8 1.2 1.7 2.5 3 2.4 1.2 0 1.7-.8 3.1-.8 1.5 0 1.9.8 3.2.8 1.3 0 2.1-1.2 2.9-2.4.9-1.4 1.3-2.7 1.3-2.8 0 0-2.5-1-2.5-4zM11.5 3.4c.7-.8 1.1-1.9 1-3.1-1 0-2.2.7-2.9 1.5-.6.7-1.2 1.9-1 3 1.1.1 2.2-.6 2.9-1.4z"></path></svg>
                Pay
              </button>
              <button onClick={() => pay('googlepay')} style={{
                minHeight: 52, borderRadius: 14, border: `1.5px solid ${CD.line}`, background: '#fff',
                color: CD.ink, fontSize: 15.5, fontWeight: 700, fontFamily: 'inherit', cursor: 'pointer',
                display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
              }}>
                <span aria-hidden="true" style={{ display: 'inline-flex', gap: 1, fontWeight: 800, fontSize: 16 }}>
                  <span style={{ color: '#4285F4' }}>G</span><span style={{ color: '#EA4335' }}>o</span><span style={{ color: '#FBBC04' }}>o</span><span style={{ color: '#4285F4' }}>g</span><span style={{ color: '#34A853' }}>l</span><span style={{ color: '#EA4335' }}>e</span>
                </span>
                Pay
              </button>
              <button onClick={() => pay('card')} style={{
                minHeight: 48, borderRadius: 14, border: 'none', background: 'transparent',
                color: CD.ink2, fontSize: 14.5, fontWeight: 600, fontFamily: 'inherit', cursor: 'pointer',
                display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 7,
              }}>
                <WalletIcon size={17} color={CD.ink2} /> Pagar com cartão
              </button>
            </div>

            <p style={{ textAlign: 'center', fontSize: 11.5, color: CD.ink3, margin: '12px 0 0', lineHeight: 1.5 }}>
              Pagamento dentro da app. Renovação automática mensal, cancela quando quiseres.
            </p>
          </div>
        )}

        {step === 'paying' && (
          <div style={{ textAlign: 'center', padding: '36px 0 44px' }}>
            <div style={{
              width: 52, height: 52, margin: '0 auto 18px', borderRadius: '50%',
              border: `4px solid ${CD.lineSoft}`, borderTopColor: theme.primary,
              animation: 'cdSpin 0.8s linear infinite',
            }}></div>
            <div style={{ fontSize: 16, fontWeight: 700, color: CD.ink }}>
              {method === 'applepay' ? 'A confirmar com Apple Pay…' : method === 'googlepay' ? 'A confirmar com Google Pay…' : 'A processar pagamento…'}
            </div>
            <div style={{ fontSize: 13, color: CD.ink3, marginTop: 6 }}>1,00 € · CestoDoce Member</div>
          </div>
        )}

        {step === 'success' && (
          <div style={{ textAlign: 'center', padding: '36px 0 44px' }}>
            <div style={{
              width: 60, height: 60, margin: '0 auto 16px', borderRadius: '50%',
              background: theme.primarySoft, display: 'flex', alignItems: 'center', justifyContent: 'center',
              animation: 'cdPop 0.4s cubic-bezier(0.34, 1.56, 0.64, 1)',
            }}><CheckIcon size={30} color={theme.savings} /></div>
            <div style={{ fontSize: 19, fontWeight: 800, color: CD.ink, letterSpacing: '-0.02em' }}>Bem-vinda, Member!</div>
            <div style={{ fontSize: 13.5, color: CD.ink2, marginTop: 6 }}>Análises ilimitadas ativadas.</div>
          </div>
        )}
      </div>
    </div>
  );
}

Object.assign(window, { HomeScreen, CartScreen, AnalysisScreen, ProfileScreen, PaywallSheet });
})();
