// catalog.jsx — product catalog with per-store prices, comparison engine, and
// the cart/compare/receipt/paywall strings (merged into CESTO_STRINGS).

const CESTO_STORE_KEYS = ["lidl", "continente", "pingo", "intermarche"];

// Each product: id, pt/en name, unit, glyph, and a price at every store.
const CESTO_PRODUCTS = [
  { id: "leite",     pt: "Leite meio-gordo",   en: "Semi-skimmed milk", unit: "1L",       glyph: "🥛", prices: { lidl: 0.75, continente: 0.79, pingo: 0.55, intermarche: 0.78 } },
  { id: "pao",       pt: "Pão de forma",        en: "Sliced bread",      unit: "500g",     glyph: "🍞", prices: { lidl: 1.15, continente: 1.29, pingo: 1.25, intermarche: 1.09 } },
  { id: "ovos",      pt: "Ovos M",              en: "Eggs M",            unit: "12un",     glyph: "🥚", prices: { lidl: 1.99, continente: 2.15, pingo: 2.09, intermarche: 1.79 } },
  { id: "arroz",     pt: "Arroz agulha",        en: "Long-grain rice",   unit: "1kg",      glyph: "🍚", prices: { lidl: 0.95, continente: 1.15, pingo: 1.09, intermarche: 1.05 } },
  { id: "massa",     pt: "Esparguete",          en: "Spaghetti",         unit: "500g",     glyph: "🍝", prices: { lidl: 0.65, continente: 0.85, pingo: 0.79, intermarche: 0.75 } },
  { id: "azeite",    pt: "Azeite virgem",       en: "Virgin olive oil",  unit: "1L",       glyph: "🫒", prices: { lidl: 5.99, continente: 6.99, pingo: 6.79, intermarche: 6.49 } },
  { id: "frango",    pt: "Frango inteiro",      en: "Whole chicken",     unit: "kg",       glyph: "🍗", prices: { lidl: 3.49, continente: 3.69, pingo: 3.39, intermarche: 2.49 } },
  { id: "cafe",      pt: "Café moído",          en: "Ground coffee",     unit: "250g",     glyph: "☕", prices: { lidl: 2.99, continente: 1.99, pingo: 2.59, intermarche: 2.79 } },
  { id: "iogurte",   pt: "Iogurte natural",     en: "Plain yogurt",      unit: "4un",      glyph: "🥣", prices: { lidl: 1.29, continente: 1.19, pingo: 0.69, intermarche: 1.25 } },
  { id: "queijo",    pt: "Queijo flamengo",     en: "Flemish cheese",    unit: "250g",     glyph: "🧀", prices: { lidl: 2.29, continente: 2.19, pingo: 1.89, intermarche: 2.25 } },
  { id: "detergente",pt: "Detergente roupa",    en: "Laundry detergent", unit: "2L",       glyph: "🧴", prices: { lidl: 4.99, continente: 2.99, pingo: 4.49, intermarche: 4.79 } },
  { id: "papel",     pt: "Papel higiénico",     en: "Toilet paper",      unit: "12un",     glyph: "🧻", prices: { lidl: 3.49, continente: 2.79, pingo: 3.69, intermarche: 3.59 } },
  { id: "atum",      pt: "Atum em lata",        en: "Canned tuna",       unit: "3un",      glyph: "🐟", prices: { lidl: 2.49, continente: 2.59, pingo: 2.45, intermarche: 1.79 } },
  { id: "banana",    pt: "Banana",              en: "Banana",            unit: "kg",       glyph: "🍌", prices: { lidl: 0.89, continente: 1.19, pingo: 1.09, intermarche: 1.05 } },
  { id: "maca",      pt: "Maçã",                en: "Apple",             unit: "kg",       glyph: "🍎", prices: { lidl: 1.19, continente: 1.49, pingo: 1.39, intermarche: 1.35 } },
  { id: "cerveja",   pt: "Cerveja",             en: "Beer",              unit: "6×33cl",   glyph: "🍺", prices: { lidl: 2.79, continente: 2.99, pingo: 2.69, intermarche: 2.89 } },
  { id: "bolachas",  pt: "Bolachas Maria",      en: "Maria biscuits",    unit: "200g",     glyph: "🍪", prices: { lidl: 0.79, continente: 0.99, pingo: 0.95, intermarche: 0.92 } },
  { id: "gel",       pt: "Gel de banho",        en: "Shower gel",        unit: "750ml",    glyph: "🧼", prices: { lidl: 2.19, continente: 1.69, pingo: 2.09, intermarche: 2.29 } },
];

const CESTO_PRODUCT_BY_ID = Object.fromEntries(CESTO_PRODUCTS.map((p) => [p.id, p]));

// a sensible starter cart so the demo has something to compare
const CESTO_DEFAULT_CART = [
  { id: "leite", qty: 2 }, { id: "pao", qty: 1 }, { id: "ovos", qty: 1 },
  { id: "frango", qty: 1 }, { id: "cafe", qty: 1 }, { id: "iogurte", qty: 2 },
  { id: "detergente", qty: 1 }, { id: "banana", qty: 1 }, { id: "atum", qty: 1 },
  { id: "azeite", qty: 1 },
];

// ---- comparison engine ----
function cestoCompare(cart) {
  const totals = {};
  CESTO_STORE_KEYS.forEach((s) => { totals[s] = 0; });
  cart.forEach((line) => {
    const p = CESTO_PRODUCT_BY_ID[line.id];
    if (!p) return;
    CESTO_STORE_KEYS.forEach((s) => { totals[s] += p.prices[s] * line.qty; });
  });
  const ranking = CESTO_STORE_KEYS.map((s) => ({ store: s, total: totals[s] }))
    .sort((a, b) => a.total - b.total);
  const cheapest = ranking[0];
  const expensive = ranking[ranking.length - 1];
  return { totals, ranking, cheapest, expensive, savings: expensive.total - cheapest.total };
}

// ---- per-product analysis at the winning store ----
function cestoAnalyze(cart, winner, worst) {
  const rows = cart.map((line) => {
    const p = CESTO_PRODUCT_BY_ID[line.id];
    const atWinner = p.prices[winner] * line.qty;
    const atWorst = p.prices[worst] * line.qty;
    // cheapest store for THIS product
    const minStore = CESTO_STORE_KEYS.reduce((m, s) => (p.prices[s] < p.prices[m] ? s : m), CESTO_STORE_KEYS[0]);
    const overpay = (p.prices[winner] - p.prices[minStore]) * line.qty; // > 0 if winner not cheapest here
    return {
      id: line.id, qty: line.qty, p,
      atWinner, atWorst,
      saved: atWorst - atWinner,       // savings vs the priciest store
      minStore, overpay,
    };
  });

  const savers = [...rows].filter((r) => r.saved > 0).sort((a, b) => b.saved - a.saved);
  const overpays = rows.filter((r) => r.overpay > 0.005).sort((a, b) => b.overpay - a.overpay);

  const totalSaved = rows.reduce((a, r) => a + r.saved, 0);
  // how many products make up ~70% of the savings
  let cum = 0, n = 0;
  for (const r of savers) { cum += r.saved; n++; if (cum >= 0.7 * totalSaved) break; }
  const pct = totalSaved > 0 ? Math.round((cum / totalSaved) * 100) : 0;

  return { rows, savers, overpays, totalSaved, summaryN: n, summaryPct: pct, totalOverpay: overpays.reduce((a, r) => a + r.overpay, 0) };
}

Object.assign(window, {
  CESTO_STORE_KEYS, CESTO_PRODUCTS, CESTO_PRODUCT_BY_ID, CESTO_DEFAULT_CART,
  cestoCompare, cestoAnalyze,
});

// ---- strings (merged into the existing CESTO_STRINGS) ----
Object.assign(CESTO_STRINGS.pt, {
  home_cta_cart: "Criar o meu carrinho",

  cart_title: "O meu carrinho",
  cart_day: "Dia de compras",
  cart_day_optional: "opcional",
  cart_search_ph: "Procurar produto…",
  cart_popular: "Adicionar rápido",
  cart_empty: "Carrinho vazio — procura e adiciona produtos para comparar.",
  cart_count: (n) => `${n} ${n === 1 ? "produto" : "produtos"}`,
  cart_from: "desde",
  cart_cta: "Comparar preços",
  cart_add: "Adicionar",

  compare_title: "Comparação",
  compare_kicker: "Carrinho comparado em 4 supermercados",
  compare_cheapest: "Mais barato para si",
  compare_vs: "vs. o mais caro",
  compare_ranking: "Ranking de preços",
  compare_diff: "+",
  compare_cta: "Ver recibo inteligente",
  compare_edit: "Editar carrinho",

  receipt_title: "Recibo inteligente",
  receipt_subtitle: "O teu carrinho ao melhor preço",
  receipt_at: "em",
  receipt_qty: "Qt",
  receipt_total: "Total",
  receipt_worst: "No mais caro",
  receipt_savings: "Poupança total",
  receipt_share: "Partilhar recibo",

  analysis_title: "Análise do carrinho",
  analysis_save_title: "Onde mais poupas",
  analysis_save_sub: "Produtos que mais contribuem para a poupança",
  analysis_over_title: "Onde pagas a mais",
  analysis_over_sub: "Mais baratos noutro supermercado",
  analysis_cheaper_at: (s) => `Mais barato no ${s}`,
  analysis_summary: (store, pct, n) => `O teu carrinho está mais barato no ${store} — ${pct}% da poupança vem de apenas ${n} ${n === 1 ? "produto" : "produtos"}.`,
  analysis_per_unit: "/un",

  free_plan: "Plano grátis",
  free_used: "1 análise/mês usada",
  free_left: "1 análise grátis este mês",
  locked_title: "Análise completa",
  locked_body: "Vê onde pagas a mais, o histórico e a otimização automática do carrinho.",
  locked_cta: "Desbloquear",

  paywall_kicker: "Cesto Premium",
  paywall_title: "Poupa mais,\ntodos os meses.",
  paywall_price: "2,69 €",
  paywall_period: "/mês",
  paywall_benefits: [
    "Análises de recibo ilimitadas",
    "Histórico de poupança mensal",
    "Comparação mês a mês",
    "Otimização automática do carrinho",
    "Alertas de descida de preços",
  ],
  paywall_cta: "Subscrever Premium",
  paywall_later: "Talvez mais tarde",
  paywall_trust: "Cancela quando quiseres",
  premium_active: "Premium ativo",
});

Object.assign(CESTO_STRINGS.en, {
  home_cta_cart: "Build my basket",

  cart_title: "My basket",
  cart_day: "Shopping day",
  cart_day_optional: "optional",
  cart_search_ph: "Search product…",
  cart_popular: "Quick add",
  cart_empty: "Empty basket — search and add products to compare.",
  cart_count: (n) => `${n} ${n === 1 ? "product" : "products"}`,
  cart_from: "from",
  cart_cta: "Compare prices",
  cart_add: "Add",

  compare_title: "Comparison",
  compare_kicker: "Basket compared across 4 supermarkets",
  compare_cheapest: "Cheapest for you",
  compare_vs: "vs. the priciest",
  compare_ranking: "Price ranking",
  compare_diff: "+",
  compare_cta: "See smart receipt",
  compare_edit: "Edit basket",

  receipt_title: "Smart receipt",
  receipt_subtitle: "Your basket at its best price",
  receipt_at: "at",
  receipt_qty: "Qty",
  receipt_total: "Total",
  receipt_worst: "At the priciest",
  receipt_savings: "Total savings",
  receipt_share: "Share receipt",

  analysis_title: "Basket analysis",
  analysis_save_title: "Where you save most",
  analysis_save_sub: "Products driving most of your savings",
  analysis_over_title: "Where you overpay",
  analysis_over_sub: "Cheaper at another supermarket",
  analysis_cheaper_at: (s) => `Cheaper at ${s}`,
  analysis_summary: (store, pct, n) => `Your basket is cheapest at ${store} — ${pct}% of the savings come from just ${n} ${n === 1 ? "product" : "products"}.`,
  analysis_per_unit: "/ea",

  free_plan: "Free plan",
  free_used: "1 analysis/mo used",
  free_left: "1 free analysis this month",
  locked_title: "Full analysis",
  locked_body: "See where you overpay, your history and automatic basket optimization.",
  locked_cta: "Unlock",

  paywall_kicker: "Cesto Premium",
  paywall_title: "Save more,\nevery month.",
  paywall_price: "€2.69",
  paywall_period: "/mo",
  paywall_benefits: [
    "Unlimited receipt analyses",
    "Monthly savings history",
    "Month-over-month comparison",
    "Automatic basket optimization",
    "Price-drop alerts",
  ],
  paywall_cta: "Subscribe to Premium",
  paywall_later: "Maybe later",
  paywall_trust: "Cancel anytime",
  premium_active: "Premium active",
});
