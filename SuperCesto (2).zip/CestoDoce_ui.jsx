// CestoDoce — UI partilhada: tokens, ícones, componentes base
const { useState, useEffect, useRef, useMemo } = React;

// ---------- Tokens de tema ----------
const CD_THEMES = {
  verde: {
    primary: 'oklch(40% 0.13 150)',
    primaryDark: 'oklch(30% 0.11 150)',
    primarySoft: 'oklch(96% 0.025 150)',
    savings: 'oklch(46% 0.17 150)',
  },
  azul: {
    primary: 'oklch(40% 0.13 250)',
    primaryDark: 'oklch(30% 0.11 250)',
    primarySoft: 'oklch(96% 0.02 250)',
    savings: 'oklch(46% 0.17 250)',
  },
  laranja: {
    primary: 'oklch(48% 0.14 55)',
    primaryDark: 'oklch(36% 0.12 55)',
    primarySoft: 'oklch(96.5% 0.025 70)',
    savings: 'oklch(50% 0.16 55)',
  },
};

const CD = {
  bg: 'oklch(98% 0.006 150)',
  surface: '#FFFFFF',
  ink: 'oklch(20% 0.012 150)',
  ink2: 'oklch(45% 0.012 150)',
  ink3: 'oklch(62% 0.01 150)',
  line: 'oklch(93% 0.008 150)',
  lineSoft: 'oklch(95.5% 0.006 150)',
  promo: 'oklch(56% 0.16 45)',
  promoBg: 'oklch(96.5% 0.03 70)',
  gold: 'oklch(75% 0.13 85)',
  goldBg: 'oklch(96% 0.045 90)',
  goldInk: 'oklch(42% 0.1 75)',
  member: 'oklch(42% 0.12 300)',
  memberBg: 'oklch(96% 0.025 300)',
  shadow: '0 1px 3px rgba(20,40,25,0.05), 0 4px 16px rgba(20,40,25,0.05)',
  shadowLift: '0 4px 12px rgba(20,40,25,0.08), 0 12px 32px rgba(20,40,25,0.10)',
};

// Cores dos badges das lojas (representativas, não oficiais)
const CD_SUPER_COLORS = {
  continente: { bg: 'oklch(95% 0.035 30)', text: 'oklch(40% 0.13 30)' },
  pingodoce:  { bg: 'oklch(95% 0.04 150)', text: 'oklch(34% 0.13 150)' },
  lidl:       { bg: 'oklch(94% 0.04 262)', text: 'oklch(38% 0.13 262)' },
  aldi:       { bg: 'oklch(94% 0.035 230)', text: 'oklch(38% 0.12 230)' },
  mercadona:  { bg: 'oklch(95% 0.04 175)', text: 'oklch(35% 0.1 175)' },
  intermarche:{ bg: 'oklch(95% 0.035 20)', text: 'oklch(40% 0.12 20)' },
};

// ---------- Ícones (SVG simples) ----------
function CdIcon({ d, size = 22, color = 'currentColor', filled = false, children }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill={filled ? color : 'none'}
      stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      {children || <path d={d}></path>}
    </svg>
  );
}
function HomeIcon(p) {
  return <CdIcon {...p}><path d="M3 10.5 12 3l9 7.5"></path><path d="M5 9.5V21h14V9.5"></path><path d="M9.5 21v-6h5v6"></path></CdIcon>;
}
function BasketIcon(p) {
  return <CdIcon {...p}><path d="M4 9h16l-1.5 11h-13z"></path><path d="M8 9l4-6 4 6"></path><path d="M9.5 13v3.5"></path><path d="M14.5 13v3.5"></path></CdIcon>;
}
function CompassIcon(p) {
  return <CdIcon {...p}><circle cx="12" cy="12" r="9"></circle><path d="M15.5 8.5 13.8 13.8 8.5 15.5l1.7-5.3z"></path></CdIcon>;
}
function PersonIcon(p) {
  return <CdIcon {...p}><circle cx="12" cy="7.5" r="3.5"></circle><path d="M4.5 20.5c0-4 3.4-6.5 7.5-6.5s7.5 2.5 7.5 6.5"></path></CdIcon>;
}
function SearchIcon(p) {
  return <CdIcon {...p}><circle cx="11" cy="11" r="7"></circle><path d="m20 20-3.8-3.8"></path></CdIcon>;
}
function PlusIcon(p) {
  return <CdIcon {...p}><path d="M12 5v14"></path><path d="M5 12h14"></path></CdIcon>;
}
function MinusIcon(p) {
  return <CdIcon {...p}><path d="M5 12h14"></path></CdIcon>;
}
function CheckIcon(p) {
  return <CdIcon {...p}><path d="m4.5 12.5 5 5L19.5 7"></path></CdIcon>;
}
function ChevronRight(p) {
  return <CdIcon {...p}><path d="m9 5 7 7-7 7"></path></CdIcon>;
}
function ArrowLeftIcon(p) {
  return <CdIcon {...p}><path d="M19 12H5"></path><path d="m11 6-6 6 6 6"></path></CdIcon>;
}
function TagIcon(p) {
  return <CdIcon {...p}><path d="M3 11V4a1 1 0 0 1 1-1h7l10 10-8 8z"></path><circle cx="8" cy="8" r="1.4"></circle></CdIcon>;
}
function SparkIcon(p) {
  return <CdIcon {...p}><path d="M12 3l1.9 5.6L19.5 10l-5.6 1.9L12 17.5l-1.9-5.6L4.5 10l5.6-1.4z"></path></CdIcon>;
}
function LockIcon(p) {
  return <CdIcon {...p}><rect x="5" y="11" width="14" height="9" rx="2"></rect><path d="M8 11V8a4 4 0 0 1 8 0v3"></path></CdIcon>;
}
function TrendDownIcon(p) {
  return <CdIcon {...p}><path d="m4 8 6 6 3-3 7 7"></path><path d="M20 13v5h-5"></path></CdIcon>;
}
function TrendUpIcon(p) {
  return <CdIcon {...p}><path d="m4 16 6-6 3 3 7-7"></path><path d="M20 11V6h-5"></path></CdIcon>;
}
function CrownIcon(p) {
  return <CdIcon {...p}><path d="M4 18h16l1-10-5 3.5L12 5 8 11.5 3 8z"></path></CdIcon>;
}
function WalletIcon(p) {
  return <CdIcon {...p}><rect x="3" y="6" width="18" height="13" rx="2.5"></rect><path d="M3 10h18"></path></CdIcon>;
}

// ---------- Componentes base ----------
function SuperBadge({ id, name, size = 38 }) {
  const c = CD_SUPER_COLORS[id] || { bg: CD.lineSoft, text: CD.ink2 };
  return (
    <div aria-hidden="true" style={{
      width: size, height: size, borderRadius: '32%',
      background: c.bg, color: c.text,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      fontSize: size * 0.42, fontWeight: 800, flexShrink: 0, letterSpacing: '-0.02em',
    }}>{(name || '?')[0]}</div>
  );
}

function AnimatedEuro({ value, duration = 1100, style = {} }) {
  const [display, setDisplay] = useState(0);
  const raf = useRef(null);
  useEffect(() => {
    const t0 = performance.now();
    function tick(now) {
      const p = Math.min((now - t0) / duration, 1);
      const eased = 1 - Math.pow(1 - p, 3);
      setDisplay(value * eased);
      if (p < 1) raf.current = requestAnimationFrame(tick);
    }
    raf.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf.current);
  }, [value, duration]);
  return <span style={style}>{display.toFixed(2).replace('.', ',')} €</span>;
}

function euro(n) {
  return n.toFixed(2).replace('.', ',') + ' €';
}

function Card({ children, style = {}, onClick }) {
  return (
    <div onClick={onClick} style={{
      background: CD.surface, borderRadius: 18, padding: 16,
      boxShadow: CD.shadow, cursor: onClick ? 'pointer' : 'default', ...style,
    }}>{children}</div>
  );
}

function Pill({ children, bg, color, style = {} }) {
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 4,
      padding: '3px 9px', borderRadius: 100, background: bg, color,
      fontSize: 11.5, fontWeight: 700, letterSpacing: '0.01em', whiteSpace: 'nowrap', ...style,
    }}>{children}</span>
  );
}

function PrimaryButton({ children, onClick, theme, disabled, style = {} }) {
  return (
    <button onClick={onClick} disabled={disabled} style={{
      width: '100%', minHeight: 52, border: 'none', borderRadius: 14,
      background: disabled ? CD.line : theme.primary, color: disabled ? CD.ink3 : '#fff',
      fontSize: 16, fontWeight: 700, fontFamily: 'inherit', cursor: disabled ? 'default' : 'pointer',
      display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
      transition: 'transform 0.1s ease, background 0.15s ease',
      ...style,
    }}
    onMouseDown={e => { if (!disabled) e.currentTarget.style.transform = 'scale(0.985)'; }}
    onMouseUp={e => { e.currentTarget.style.transform = 'scale(1)'; }}
    onMouseLeave={e => { e.currentTarget.style.transform = 'scale(1)'; }}
    >{children}</button>
  );
}

function GhostButton({ children, onClick, style = {} }) {
  return (
    <button onClick={onClick} style={{
      width: '100%', minHeight: 48, borderRadius: 14, border: `1.5px solid ${CD.line}`,
      background: 'transparent', color: CD.ink, fontSize: 15, fontWeight: 600,
      fontFamily: 'inherit', cursor: 'pointer',
      display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, ...style,
    }}>{children}</button>
  );
}

function QtyStepper({ qty, onChange, theme }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 0, background: CD.lineSoft, borderRadius: 100 }}>
      <button onClick={() => onChange(-1)} aria-label="Menos um" style={{
        width: 34, height: 34, border: 'none', background: 'transparent', cursor: 'pointer',
        display: 'flex', alignItems: 'center', justifyContent: 'center', color: CD.ink2, borderRadius: 100,
      }}><MinusIcon size={16} /></button>
      <span style={{ minWidth: 22, textAlign: 'center', fontSize: 14.5, fontWeight: 700, color: CD.ink, fontVariantNumeric: 'tabular-nums' }}>{qty}</span>
      <button onClick={() => onChange(1)} aria-label="Mais um" style={{
        width: 34, height: 34, border: 'none', background: 'transparent', cursor: 'pointer',
        display: 'flex', alignItems: 'center', justifyContent: 'center', color: theme.primary, borderRadius: 100,
      }}><PlusIcon size={16} /></button>
    </div>
  );
}

function TabBar({ current, onChange, cartCount, theme }) {
  const tabs = [
    { id: 'home', Icon: HomeIcon, label: 'Início' },
    { id: 'cart', Icon: BasketIcon, label: 'Carrinho', badge: cartCount },
    { id: 'analysis', Icon: CompassIcon, label: 'Análise' },
    { id: 'profile', Icon: PersonIcon, label: 'Perfil' },
  ];
  return (
    <nav style={{
      position: 'absolute', bottom: 0, left: 0, right: 0,
      background: 'rgba(255,255,255,0.94)', backdropFilter: 'blur(16px)', WebkitBackdropFilter: 'blur(16px)',
      borderTop: `1px solid ${CD.lineSoft}`, display: 'flex', zIndex: 60,
      paddingBottom: 'max(env(safe-area-inset-bottom), 6px)', paddingTop: 6,
    }}>
      {tabs.map(({ id, Icon, label, badge }) => {
        const active = current === id;
        return (
          <button key={id} onClick={() => onChange(id)} style={{
            flex: 1, minHeight: 50, border: 'none', background: 'none', cursor: 'pointer',
            display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 3,
            color: active ? theme.primary : CD.ink3, position: 'relative', fontFamily: 'inherit',
          }}>
            <span style={{ position: 'relative', display: 'inline-flex' }}>
              <Icon size={23} color={active ? theme.primary : CD.ink3} />
              {badge > 0 && (
                <span style={{
                  position: 'absolute', top: -4, right: -8, minWidth: 16, height: 16,
                  borderRadius: 100, background: theme.primary, color: '#fff',
                  fontSize: 9.5, fontWeight: 800, display: 'flex', alignItems: 'center',
                  justifyContent: 'center', padding: '0 4px',
                }}>{badge}</span>
              )}
            </span>
            <span style={{ fontSize: 10.5, fontWeight: active ? 700 : 500, letterSpacing: '0.01em' }}>{label}</span>
          </button>
        );
      })}
    </nav>
  );
}

function ScreenHeader({ title, subtitle, onBack, right }) {
  return (
    <header style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '18px 20px 8px' }}>
      {onBack && (
        <button onClick={onBack} aria-label="Voltar" style={{
          width: 38, height: 38, borderRadius: 12, border: `1px solid ${CD.line}`,
          background: CD.surface, cursor: 'pointer', display: 'flex',
          alignItems: 'center', justifyContent: 'center', color: CD.ink, flexShrink: 0,
        }}><ArrowLeftIcon size={18} /></button>
      )}
      <div style={{ flex: 1, minWidth: 0 }}>
        <h1 style={{ margin: 0, fontSize: 21, fontWeight: 800, color: CD.ink, letterSpacing: '-0.02em' }}>{title}</h1>
        {subtitle && <p style={{ margin: '2px 0 0', fontSize: 13, color: CD.ink2 }}>{subtitle}</p>}
      </div>
      {right}
    </header>
  );
}

Object.assign(window, {
  CD, CD_THEMES, CD_SUPER_COLORS,
  HomeIcon, BasketIcon, CompassIcon, PersonIcon, SearchIcon, PlusIcon, MinusIcon,
  CheckIcon, ChevronRight, ArrowLeftIcon, TagIcon, SparkIcon, LockIcon,
  TrendDownIcon, TrendUpIcon, CrownIcon, WalletIcon,
  SuperBadge, AnimatedEuro, euro, Card, Pill, PrimaryButton, GhostButton,
  QtyStepper, TabBar, ScreenHeader,
});
