// CestoDoce_ui_v3.jsx — Tokens dark premium (XTB-style) + componentes compartilhados
const { useState: useV3S, useEffect: useV3E, useRef: useV3R, useMemo: useV3M, useLayoutEffect: useV3L } = React;

// ---- Dark premium tokens ----
const V3 = {
  // backgrounds
  base:       '#0B0E13',
  surface:    '#12161D',
  surface2:   '#181D27',
  surface3:   '#1E2435',
  border:     'rgba(255,255,255,0.07)',
  borderBright:'rgba(255,255,255,0.13)',

  // text
  ink:        '#F0F4FF',
  ink2:       'rgba(240,244,255,0.65)',
  ink3:       'rgba(240,244,255,0.38)',

  // accents — XTB green
  mint:       '#00C875',
  mintDim:    'rgba(0,200,117,0.12)',
  mintGlow:   'rgba(0,200,117,0.22)',
  mintText:   '#00E885',

  // red/down
  red:        '#FF4D4D',
  redDim:     'rgba(255,77,77,0.12)',

  // amber/mid
  amber:      '#FFB830',
  amberDim:   'rgba(255,184,48,0.12)',

  // member purple
  member:     '#A78BFA',
  memberDim:  'rgba(167,139,250,0.12)',

  // promo
  promo:      '#FF8A3D',
  promoDim:   'rgba(255,138,61,0.12)',

  // shadows
  shadow:     '0 2px 8px rgba(0,0,0,0.4)',
  shadowLift: '0 8px 32px rgba(0,0,0,0.56)',
  glow:       '0 0 24px rgba(0,200,117,0.18)',
};

// Temas: verde é o default premium
const V3_THEMES = {
  verde:   { primary:V3.mint, primaryDim:V3.mintDim, primaryGlow:V3.mintGlow, primaryText:V3.mintText, savings:V3.mint },
  azul:    { primary:'#3D9EFF', primaryDim:'rgba(61,158,255,0.12)', primaryGlow:'rgba(61,158,255,0.22)', primaryText:'#5BB3FF', savings:'#3D9EFF' },
  laranja: { primary:V3.promo, primaryDim:V3.promoDim, primaryGlow:'rgba(255,138,61,0.22)', primaryText:'#FFA060', savings:V3.promo },
};

// store accent colors (dark-friendly)
const V3_SUPER = {
  continente:  { accent:'#FF6B35', letter:'C' },
  pingodoce:   { accent:'#00C875', letter:'P' },
  lidl:        { accent:'#3D9EFF', letter:'L' },
  aldi:        { accent:'#A78BFA', letter:'A' },
  mercadona:   { accent:'#00C875', letter:'M' },
  intermarche: { accent:'#FF4D4D', letter:'I' },
};

// ---- Icons ----
function V3Icon({ size=22, color='currentColor', children, filled=false }) {
  return <svg width={size} height={size} viewBox="0 0 24 24" fill={filled?color:'none'} stroke={color} strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">{children}</svg>;
}
function HomeIco(p)      { return <V3Icon {...p}><path d="M3 10.5 12 3l9 7.5"/><path d="M5 9.5V21h14V9.5"/><path d="M9.5 21v-6h5v6"/></V3Icon>; }
function BasketIco(p)    { return <V3Icon {...p}><path d="M4 9h16l-1.5 11h-13z"/><path d="M8 9l4-6 4 6"/></V3Icon>; }
function ScanIco(p)      { return <V3Icon {...p}><path d="M3 7V5a2 2 0 0 1 2-2h2"/><path d="M17 3h2a2 2 0 0 1 2 2v2"/><path d="M21 17v2a2 2 0 0 1-2 2h-2"/><path d="M7 21H5a2 2 0 0 1-2-2v-2"/><line x1="7" y1="12" x2="17" y2="12"/></V3Icon>; }
function PersonIco(p)    { return <V3Icon {...p}><circle cx="12" cy="7.5" r="3.5"/><path d="M4.5 20.5c0-4 3.4-6.5 7.5-6.5s7.5 2.5 7.5 6.5"/></V3Icon>; }
function SearchIco(p)    { return <V3Icon {...p}><circle cx="11" cy="11" r="7"/><path d="m20 20-3.8-3.8"/></V3Icon>; }
function PlusIco(p)      { return <V3Icon {...p}><path d="M12 5v14M5 12h14"/></V3Icon>; }
function MinusIco(p)     { return <V3Icon {...p}><path d="M5 12h14"/></V3Icon>; }
function CheckIco(p)     { return <V3Icon {...p}><path d="m4.5 12.5 5 5L19.5 7"/></V3Icon>; }
function BackIco(p)      { return <V3Icon {...p}><path d="M19 12H5"/><path d="m11 6-6 6 6 6"/></V3Icon>; }
function SparkIco(p)     { return <V3Icon {...p}><path d="M12 3l1.9 5.6L19.5 10l-5.6 1.9L12 17.5l-1.9-5.6L4.5 10l5.6-1.4z"/></V3Icon>; }
function CrownIco(p)     { return <V3Icon {...p}><path d="M4 18h16l1-10-5 3.5L12 5 8 11.5 3 8z"/></V3Icon>; }
function WalletIco(p)    { return <V3Icon {...p}><rect x="3" y="6" width="18" height="13" rx="2.5"/><path d="M3 10h18"/></V3Icon>; }
function TrendUpIco(p)   { return <V3Icon {...p}><path d="m4 16 6-6 3 3 7-7"/><path d="M20 11V6h-5"/></V3Icon>; }
function TrendDownIco(p) { return <V3Icon {...p}><path d="m4 8 6 6 3-3 7 7"/><path d="M20 13v5h-5"/></V3Icon>; }
function TagIco(p)       { return <V3Icon {...p}><path d="M3 11V4a1 1 0 0 1 1-1h7l10 10-8 8z"/><circle cx="8" cy="8" r="1.4"/></V3Icon>; }
function AlertIco(p)     { return <V3Icon {...p}><path d="M10.3 3.3 2 20h20L13.7 3.3a2 2 0 0 0-3.4 0z"/><path d="M12 9v5"/><circle cx="12" cy="17" r=".8" fill="currentColor"/></V3Icon>; }
function CameraIco(p)    { return <V3Icon {...p}><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/></V3Icon>; }
function FlashIco(p)     { return <V3Icon {...p}><path d="M13 2 3 14h9l-1 8 10-12h-9z"/></V3Icon>; }

// ---- SuperBadge dark ----
function V3Badge({ id, size=38 }) {
  const s = V3_SUPER[id] || { accent:'#555', letter:'?' };
  return (
    <div style={{
      width: size, height: size, borderRadius: '28%', flexShrink: 0,
      background: `linear-gradient(145deg, ${s.accent}22, ${s.accent}11)`,
      border: `1px solid ${s.accent}44`,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      fontSize: size * 0.4, fontWeight: 800, color: s.accent, letterSpacing: '-0.01em',
    }}>{s.letter}</div>
  );
}

// ---- Sparkline ----
let _v3SparkId = 0;
function V3Spark({ values, color, width=72, height=34 }) {
  const gid = useV3R('v3sp-' + (++_v3SparkId)).current;
  if (!values || values.length < 2) return null;
  const min = Math.min(...values), max = Math.max(...values);
  const rng = max - min || 1;
  const pad = 3;
  const h = height - pad * 2;
  const pts = values.map((v, i) => [
    (i / (values.length - 1)) * width,
    pad + h - ((v - min) / rng) * h,
  ]);
  const line = pts.map((p, i) => {
    if (i === 0) return `M${p[0]},${p[1]}`;
    const pr = pts[i-1], mx = (pr[0]+p[0])/2;
    return `C${mx},${pr[1]} ${mx},${p[1]} ${p[0]},${p[1]}`;
  }).join(' ');
  const fill = line + ` L${pts[pts.length-1][0]},${height} L${pts[0][0]},${height} Z`;
  return (
    <svg width={width} height={height} viewBox={`0 0 ${width} ${height}`} style={{ flexShrink:0 }} aria-hidden="true">
      <defs>
        <linearGradient id={gid} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.25"/>
          <stop offset="100%" stopColor={color} stopOpacity="0"/>
        </linearGradient>
      </defs>
      <path d={fill} fill={`url(#${gid})`}/>
      <path d={line} fill="none" stroke={color} strokeWidth="1.8" strokeLinecap="round"/>
      <circle cx={pts[pts.length-1][0]} cy={pts[pts.length-1][1]} r="2.5" fill={color}/>
    </svg>
  );
}

// ---- Primitives ----
function euro(n) { return Number(n).toFixed(2).replace('.', ',') + '\u00a0€'; }

function V3Card({ children, style={}, onClick, glow }) {
  return (
    <div onClick={onClick} style={{
      background: V3.surface, borderRadius: 16,
      border: `1px solid ${glow ? V3.borderBright : V3.border}`,
      boxShadow: glow ? V3.glow : V3.shadow,
      cursor: onClick ? 'pointer' : 'default', ...style,
    }}>{children}</div>
  );
}

function V3Pill({ children, color, dim, style={} }) {
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 4,
      padding: '3px 8px', borderRadius: 100,
      background: dim, color, fontSize: 11, fontWeight: 700,
      letterSpacing: '0.02em', whiteSpace: 'nowrap', ...style,
    }}>{children}</span>
  );
}

function V3Btn({ children, onClick, theme, disabled, style={} }) {
  return (
    <button onClick={onClick} disabled={disabled} style={{
      width: '100%', minHeight: 52, border: 'none', borderRadius: 14,
      background: disabled ? V3.surface3 : theme.primary,
      color: disabled ? V3.ink3 : '#000',
      fontSize: 15.5, fontWeight: 800, fontFamily: 'inherit',
      cursor: disabled ? 'default' : 'pointer',
      display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
      letterSpacing: '-0.01em',
      boxShadow: disabled ? 'none' : `0 4px 20px ${theme.primaryGlow}`,
      transition: 'transform 0.1s, box-shadow 0.15s', ...style,
    }}
    onMouseDown={e => { if (!disabled) e.currentTarget.style.transform='scale(0.985)'; }}
    onMouseUp={e => { e.currentTarget.style.transform='scale(1)'; }}
    onMouseLeave={e => { e.currentTarget.style.transform='scale(1)'; }}
    >{children}</button>
  );
}

function V3GhostBtn({ children, onClick, style={} }) {
  return (
    <button onClick={onClick} style={{
      width: '100%', minHeight: 48, borderRadius: 14,
      border: `1px solid ${V3.borderBright}`,
      background: 'transparent', color: V3.ink2,
      fontSize: 15, fontWeight: 700, fontFamily: 'inherit', cursor: 'pointer',
      display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, ...style,
    }}>{children}</button>
  );
}

function V3Stepper({ qty, onChange, theme }) {
  return (
    <div style={{ display:'flex', alignItems:'center', gap:0, background:V3.surface3, borderRadius:100, border:`1px solid ${V3.border}` }}>
      <button onClick={()=>onChange(-1)} style={{ width:34, height:34, border:'none', background:'transparent', cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center', color:V3.ink3, borderRadius:100 }}><MinusIco size={15}/></button>
      <span style={{ minWidth:22, textAlign:'center', fontSize:14, fontWeight:800, color:V3.ink, fontVariantNumeric:'tabular-nums' }}>{qty}</span>
      <button onClick={()=>onChange(1)} style={{ width:34, height:34, border:'none', background:'transparent', cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center', color:theme.primary, borderRadius:100 }}><PlusIco size={15}/></button>
    </div>
  );
}

function V3TabBar({ current, onChange, cartCount, theme }) {
  const tabs = [
    { id:'home',    Icon:HomeIco,   label:'Início' },
    { id:'cart',    Icon:BasketIco, label:'Carrinho', badge:cartCount },
    { id:'scanner', Icon:ScanIco,   label:'Scanner' },
    { id:'profile', Icon:PersonIco, label:'Perfil' },
  ];
  return (
    <nav style={{
      position:'absolute', bottom:0, left:0, right:0,
      background:'rgba(18,22,29,0.96)', backdropFilter:'blur(20px)', WebkitBackdropFilter:'blur(20px)',
      borderTop:`1px solid ${V3.border}`, display:'flex', zIndex:60,
      paddingBottom:'max(env(safe-area-inset-bottom),6px)', paddingTop:6,
    }}>
      {tabs.map(({ id, Icon, label, badge }) => {
        const active = current===id || (id==='cart' && current==='analyzing');
        return (
          <button key={id} onClick={()=>onChange(id)} style={{ flex:1, minHeight:50, border:'none', background:'none', cursor:'pointer', display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', gap:3, color:active?theme.primary:V3.ink3, position:'relative', fontFamily:'inherit' }}>
            <span style={{ position:'relative', display:'inline-flex' }}>
              <Icon size={22} color={active?theme.primary:V3.ink3}/>
              {badge>0 && <span style={{ position:'absolute', top:-4, right:-7, minWidth:15, height:15, borderRadius:100, background:theme.primary, color:'#000', fontSize:9, fontWeight:800, display:'flex', alignItems:'center', justifyContent:'center', padding:'0 3px' }}>{badge}</span>}
            </span>
            <span style={{ fontSize:10, fontWeight:active?700:500, letterSpacing:'0.01em' }}>{label}</span>
          </button>
        );
      })}
    </nav>
  );
}

function V3Header({ title, subtitle, onBack, right }) {
  return (
    <header style={{ display:'flex', alignItems:'center', gap:12, padding:'16px 20px 8px' }}>
      {onBack && (
        <button onClick={onBack} style={{ width:36, height:36, borderRadius:10, border:`1px solid ${V3.border}`, background:V3.surface2, cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center', color:V3.ink2, flexShrink:0 }}>
          <BackIco size={17}/>
        </button>
      )}
      <div style={{ flex:1, minWidth:0 }}>
        <h1 style={{ margin:0, fontSize:20, fontWeight:800, color:V3.ink, letterSpacing:'-0.025em', lineHeight:1.1 }}>{title}</h1>
        {subtitle && <p style={{ margin:'2px 0 0', fontSize:12.5, color:V3.ink3 }}>{subtitle}</p>}
      </div>
      {right}
    </header>
  );
}

// ---- PhoneFrame dark ----
function V3Phone({ children }) {
  const [scale, setScale] = useV3S(1);
  useV3L(() => {
    const fit = () => {
      const sx = (window.innerWidth  - 24) / 390;
      const sy = (window.innerHeight - 24) / 844;
      setScale(Math.min(1.05, Math.max(0.36, Math.min(sx, sy))));
    };
    fit();
    window.addEventListener('resize', fit);
    return () => window.removeEventListener('resize', fit);
  }, []);
  return (
    <div style={{ position:'fixed', inset:0, display:'flex', alignItems:'center', justifyContent:'center', background:`radial-gradient(800px at 20% -10%, #0d1f16, transparent 55%), radial-gradient(600px at 110% 120%, #0a1520, transparent 52%), #050709` }}>
      <div style={{ transformOrigin:'center', transform:`scale(${scale})` }}>
        <div style={{ width:390, height:844, background:'#080B0F', borderRadius:54, padding:10, boxShadow:'0 60px 100px -30px rgba(0,0,0,0.9), 0 0 0 1px rgba(255,255,255,0.06) inset, 0 0 60px rgba(0,200,117,0.04)' }}>
          <div style={{ position:'relative', width:'100%', height:'100%', background:V3.base, borderRadius:45, overflow:'hidden' }}>
            <div style={{ position:'absolute', top:12, left:'50%', transform:'translateX(-50%)', width:110, height:30, background:'#080B0F', borderRadius:18, zIndex:50, pointerEvents:'none' }}/>
            <V3Status/>
            {children}
            <div style={{ position:'absolute', bottom:8, left:'50%', transform:'translateX(-50%)', width:130, height:5, borderRadius:3, background:V3.ink, opacity:0.15, zIndex:50, pointerEvents:'none' }}/>
          </div>
        </div>
      </div>
    </div>
  );
}

function V3Status() {
  const now = new Date();
  const time = `${String(now.getHours()).padStart(2,'0')}:${String(now.getMinutes()).padStart(2,'0')}`;
  return (
    <div style={{ position:'absolute', top:0, left:0, right:0, height:50, display:'flex', alignItems:'center', justifyContent:'space-between', padding:'0 26px', zIndex:45, pointerEvents:'none', fontFamily:"'DM Sans',sans-serif", fontWeight:800, fontSize:13.5, color:V3.ink }}>
      <span>{time}</span>
      <div style={{ display:'flex', alignItems:'center', gap:5 }}>
        <span style={{ fontSize:10.5, fontWeight:800 }}>5G</span>
        <svg width="22" height="11" viewBox="0 0 24 11" aria-hidden="true">
          {[0,1,2,3].map(i=><rect key={i} x={i*6} y={10-(i*2.5)} width="5" height={i*2.5+3} rx="1" fill={V3.ink} opacity={i>1?0.9:0.3}/>)}
        </svg>
        <div style={{ width:22, height:11, border:`1.5px solid ${V3.ink}`, borderRadius:3, position:'relative', opacity:0.8 }}>
          <div style={{ position:'absolute', top:1.5, left:1.5, width:'68%', height:'calc(100% - 3px)', background:V3.ink, borderRadius:1 }}/>
          <div style={{ position:'absolute', top:'50%', right:-3.5, transform:'translateY(-50%)', width:2.5, height:5.5, background:V3.ink, borderRadius:'0 1.5px 1.5px 0' }}/>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, {
  V3, V3_THEMES, V3_SUPER,
  HomeIco, BasketIco, ScanIco, PersonIco, SearchIco, PlusIco, MinusIco,
  CheckIco, BackIco, SparkIco, CrownIco, WalletIco, TrendUpIco, TrendDownIco,
  TagIco, AlertIco, CameraIco, FlashIco,
  V3Badge, V3Spark, euro, V3Card, V3Pill, V3Btn, V3GhostBtn, V3Stepper,
  V3TabBar, V3Header, V3Phone, V3Status,
});
